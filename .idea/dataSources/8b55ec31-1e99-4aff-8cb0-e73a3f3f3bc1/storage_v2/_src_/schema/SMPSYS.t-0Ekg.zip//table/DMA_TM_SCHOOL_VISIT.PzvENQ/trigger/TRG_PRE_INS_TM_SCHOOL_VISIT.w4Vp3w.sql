create trigger TRG_PRE_INS_TM_SCHOOL_VISIT
  before insert
  on DMA_TM_SCHOOL_VISIT
  for each row
  begin
 SELECT SQ_DMA_TM_SCHOOL_VISIT.NEXTVAL INTO :NEW.DTV_ID FROM DUAL;
 end;
/

