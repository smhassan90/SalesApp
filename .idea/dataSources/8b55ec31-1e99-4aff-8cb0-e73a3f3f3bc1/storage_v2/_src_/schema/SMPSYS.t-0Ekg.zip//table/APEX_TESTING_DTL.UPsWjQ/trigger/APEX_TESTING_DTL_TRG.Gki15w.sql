create trigger APEX_TESTING_DTL_TRG
  before insert
  on APEX_TESTING_DTL
  for each row
  begin
  IF :NEW.DTL_ID IS NULL THEN
    SELECT APEX_TESTING_DTL_SEQ.NEXTVAL INTO :NEW.DTL_ID FROM DUAL;
  END IF;
end;
/

