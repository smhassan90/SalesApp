create view OUTLET_GSTYPE_LOCATION as
  select og.outlet_code, om.otl_desc, og.gs_type, sh.town_code, sh.town_name,
       sh.spo_code, sh.spo_name, sh.city_code, sh.city_name,
       sh.zone_code, sh.zone_name, sh.region_code, sh.region_name
from   outlet_open_gstype og, sales_hierarchy sh, sal_so_outlet om
where  substr(og.outlet_code,1,5) = sh.town_code
and    om.otl_code = og.outlet_code
/

