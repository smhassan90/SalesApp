create trigger TRG_PRE_INS_MEDIA_COVERAGE
  before insert
  on PR_MEDIA_COVERAGE
  for each row
  begin
  SELECT SQ_PR_MEDIA_COVERAGE.NEXTVAL INTO :NEW.PMC_ID FROM DUAL;
end;
/

