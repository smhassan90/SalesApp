create trigger TRG_PRE_INS_ITEM_AC_DTL
  before insert
  on ITEM_AVAILABILITY_CHECK_DTL
  for each row
  declare
  V_dac_CODE number(12);
begin
SELECT SQ_Item_avail_check_dtl.NEXTVAL INTO V_dac_CODE FROM DUAL;
:NEW.dac_id := lpad(V_dac_CODE,10,0);
end;
/

