create trigger TRG_PRE_INS_TD_SCHOOL_VISIT
  before insert
  on DMA_TD_SCHOOL_VISIT
  for each row
  begin
 SELECT SQ_DMA_TD_VIST_SCHOOL.NEXTVAL INTO :NEW.DTD_ID FROM DUAL;
 end;
/

