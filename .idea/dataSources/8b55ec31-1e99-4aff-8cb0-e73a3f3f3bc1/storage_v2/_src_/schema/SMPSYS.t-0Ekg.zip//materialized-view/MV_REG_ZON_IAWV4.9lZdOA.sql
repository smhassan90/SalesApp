create materialized view MV_REG_ZON_IAWV4
refresh force on demand
  as
    SELECT SUBSTR(GET_LEVEL('01','R',SYSDATE,ZONE,'Z'),1,4) REGION,
       SUBSTR(GET_LEVEL_NAME('01',GET_LEVEL('01','R',SYSDATE,ZONE,'Z')),1,50) REGIONNAME,
       ZONE, ZONENAME, WEEKNO, IAWFOR,  MAR_PRD_FM, 
       MAR_DIST_CODE, MAR_TOWN_CODE, MAR_PRJ_CODE,
       MAR_ID, DAR_MAC_ID, MAC_DESC ACTIVITY_NAME,
       SUM(ACL1) "No. of Meetings",
       SUM(ACL2) "No. of Participants",
       SUM(ACL3) "Tokens Given",
       SUM(ACL4) "Brochure Given",
       SUM(ACL5) "Gifts Given",
       SUM(ACL6) "Total",
       SUM(ACL8) "Influencers talked to",
       SUM(ACL9) "Cost",
       SUM(ACL10) "Women Ref - FP",
       SUM(ACL11) "Women Ref - Pregnant",
       SUM(ACL12) "Women Ref - Other Complain",
       SUM(ACL13) "Child Age less 1 month",
       SUM(ACL14) "Child Age 1 m and 5 yrs",
       SUM(ACL22) "Clinic Flyer",
       SUM(ACL23) "Sathi Sample",
       null "Token for FP",
       null "Token for MCH"
FROM (
select MAR_ID, DECODE(MAR_IPC_GS,'Y','GS','GL') IAWFOR,
       MAR_ZONE_CODE ZONE, GET_LEVEL_NAME('01',MAR_ZONE_CODE) ZONENAME,
       MCB_MSL_CODE TERRITORY,
       GET_LEVEL_NAME('01',MCB_MSL_CODE) TERRITORYNAME,
       TO_CHAR(MAR_PRD_FM,'YYYY-ww') WEEKNO,
       MAR_PRD_FM, MAR_DIST_CODE, MAR_TOWN_CODE, MAR_PRJ_CODE,
       DAR_MAC_ID, DAR_ID,
       DECODE(DAR_ACL_ID,1, DAR_AC_VAL) ACL1,
       DECODE(DAR_ACL_ID,2, DAR_AC_VAL) ACL2,
       DECODE(DAR_ACL_ID,3, DAR_AC_VAL) ACL3,
       DECODE(DAR_ACL_ID,4, DAR_AC_VAL) ACL4,
       DECODE(DAR_ACL_ID,5, DAR_AC_VAL) ACL5,
       DECODE(DAR_ACL_ID,6, DAR_AC_VAL) ACL6,
       DECODE(DAR_ACL_ID,8, DAR_AC_VAL) ACL8,
       DECODE(DAR_ACL_ID,9, DAR_AC_VAL) ACL9,
       DECODE(DAR_ACL_ID,10,DAR_AC_VAL) ACL10,
       DECODE(DAR_ACL_ID,11,DAR_AC_VAL) ACL11,
       DECODE(DAR_ACL_ID,12,DAR_AC_VAL) ACL12,
       DECODE(DAR_ACL_ID,13,DAR_AC_VAL) ACL13,
       DECODE(DAR_ACL_ID,14,DAR_AC_VAL) ACL14,
       DECODE(DAR_ACL_ID,22,DAR_AC_VAL) ACL22,
       DECODE(DAR_ACL_ID,23,DAR_AC_VAL) ACL23,
       NULL, NULL
from IPC_TD_AR, IPC_TM_AR, IPC_SM_CBA
WHERE DAR_MAR_ID  = MAR_ID
AND   MAR_MCB_ID  = MCB_ID (+)
AND   MAR_TR_TYPE = 'IAW'
AND   DAR_ACL_ID BETWEEN 1 AND 23
AND   DAR_AC_VAL IS NOT NULL
) A, IPC_SO_ACTIVITY	B
WHERE B.MAC_ID = A.DAR_MAC_ID
GROUP BY ZONE, ZONENAME, DAR_MAC_ID, MAC_DESC, WEEKNO, MAR_ID, IAWFOR,
         MAR_PRD_FM, MAR_DIST_CODE, MAR_TOWN_CODE, MAR_PRJ_CODE
UNION ALL
SELECT MAR_REG_CODE REGION,
       SUBSTR(GET_LEVEL_NAME('01',MAR_REG_CODE),1,50) REGIONNAME,
       MAR_ZONE_CODE ZONE, GET_LEVEL_NAME('01',MAR_ZONE_CODE) ZONENAME,
       null WEEKNO, DECODE(MAR_IPC_GS,'Y','GS','GL') IAWFOR, MAR_PRD_FM,
       MAR_DIST_CODE, MAR_TOWN_CODE, MAR_PRJ_CODE,
       MAR_ID, DAR_MAC_ID, 
       DECODE( ipcm.mar_tr_type||ipcm.mar_meeting_type,'HHV'   ,'Household Visits',
                                                       'NHMNMM','Neighbourhood Meeting (Men)',
                                                       'NHMNMW','Neighbourhood Meeting (Women)',
                                                       'ORMOMM','Orientation Meeting (Men)',
                                                       'ORMOMW','Orientation Meeting (Women)') ACTIVITY_NAME,

       DECODE( ipcm.mar_tr_type||ipcm.mar_meeting_type, 'HHV',
               sum(decode(ipcd.dar_acl_id,2,NVL(ipcd.dar_ac_val,0))),
               count(distinct ipcm.mar_id) ) "No. of Meetings",

       sum(decode(ipcd.dar_acl_id,2,NVL(ipcd.dar_ac_val,0)))  "No. of Participants",

       sum(decode(ipcd.dar_acl_id,3,NVL(ipcd.dar_ac_val,0)))  "Tokens Given",
       sum(decode(ipcd.dar_acl_id,4,NVL(ipcd.dar_ac_val,0)))  "Brochure Given",
       sum(decode(ipcd.dar_acl_id,5,NVL(ipcd.dar_ac_val,0)))  "Gifts Given",
       null "Total",
       null "Influencers talked to",
       sum(decode(ipcd.dar_acl_id,9,NVL(ipcd.dar_ac_val,0)))  "Cost",
       null "Women Ref - FP",
       null "Women Ref - Pregnant",
       null "Women Ref - Other Complain",
       null "Child Age less 1 month",
       null "Child Age 1 m and 5 yrs",
       null "Clinic Flyer",
       null "Sathi Sample",
       sum(decode(ipcd.dar_acl_id,24,NVL(ipcd.dar_ac_val,0))) "Token for FP",
       sum(decode(ipcd.dar_acl_id,25,NVL(ipcd.dar_ac_val,0))) "Token for MCH"
from ipc_tm_ar ipcm, ipc_td_ar ipcd
where ipcd.dar_mar_id  = ipcm.mar_id
  and ipcm.mar_tr_type in ('HHV','NHM','ORM')
  and ipcd.dar_acl_id  in (2,3,24,25,4,5,9)
  and ipcd.dar_ac_val is not null
GROUP BY MAR_REG_CODE, MAR_ZONE_CODE, MAR_IPC_GS, MAR_PRD_FM,
         MAR_DIST_CODE, MAR_TOWN_CODE, MAR_PRJ_CODE, MAR_ID,
         DAR_MAC_ID, mar_tr_type, mar_meeting_type









/

