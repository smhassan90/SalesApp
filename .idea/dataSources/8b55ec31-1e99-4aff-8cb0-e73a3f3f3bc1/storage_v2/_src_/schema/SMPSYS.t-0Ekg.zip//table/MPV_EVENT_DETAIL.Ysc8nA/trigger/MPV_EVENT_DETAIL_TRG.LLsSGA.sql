create trigger MPV_EVENT_DETAIL_TRG
  before insert
  on MPV_EVENT_DETAIL
  for each row
  begin
  SELECT MPV_EVENT_DETAIL_SEQ.NEXTVAL INTO :NEW.DT_ID FROM DUAL;
end;
/

