create trigger BI_EPBM_TM_TCAT_INFO
  before insert
  on EPBM_TM_TCAT_INFO
  for each row
  BEGIN
    SELECT epbm_tm_tcat_info_seq.NEXTVAL INTO :NEW.etm_id
    FROM DUAL;
END;
/

