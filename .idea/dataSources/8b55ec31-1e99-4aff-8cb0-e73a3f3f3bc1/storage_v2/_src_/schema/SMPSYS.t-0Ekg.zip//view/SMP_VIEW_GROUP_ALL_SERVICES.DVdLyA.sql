create view SMP_VIEW_GROUP_ALL_SERVICES as
  SELECT gl1.name "GROUP_NAME", gl2.name "MEMBER_NAME", tl.name "TARGET_NAME", ttd.name "TARGET_TYPE", NVL(rtd.type_label,ttd.name) "TARGET_NLS_TYPE"
  FROM   SMP_VDN_GROUP_LIST gl1, SMP_VDN_GROUP_LIST gl2, SMP_VDN_GROUP_TARGET gt, SMP_VDN_TARGET_LIST tl, SMP_VDN_TARGET_TYPE_DEFN ttd, SMP_VBO_REPORTS_TYPE_DEFN rtd
  WHERE  gl2.id IN
         (
             SELECT gg.membergroupid FROM SMP_VDN_GROUP_GROUP gg START WITH gg.groupid = gl1.id CONNECT BY PRIOR gg.membergroupid = gg.groupid
           UNION ALL
             SELECT gl3.id FROM SMP_VDN_GROUP_LIST gl3 WHERE gl3.id = gl1.id
         )
     AND gl2.id = gt.groupid
     AND gt.targetid = tl.id
     AND tl.typeid = ttd.id
     AND UPPER(ttd.name) = rtd.type (+)
/

comment on table SMP_VIEW_GROUP_ALL_SERVICES
is 'List of all services put in a group, including services of member groups'
/

