create trigger EPBM_TM_TCAT_LAD3_TRG
  before insert
  on EPBM_TM_TCAT_LAD3
  for each row
  begin
  SELECT EPBM_TM_TCAT_LAD3_SEQ.NEXTVAL INTO :NEW.ETM_ID FROM DUAL;
end;
/

