create trigger EBA_SB_RESPONSES_BIU
  before insert or update
  on EBA_SB_RESPONSES
  for each row
  begin
    if :new.started_date is not null and 
       :new.completed_date is not null 
    then
       if :new.started_date != :old.started_date or 
          :old.started_date is null or
          :new.completed_date != :old.completed_date or 
          :old.completed_date is null 
       then
          :new.duration_mins := (to_date(to_char(:new.completed_date,'DD-MON-YYYY HH24:MI:SS'),'DD-MON-YYYY HH24:MI:SS') - 
                                 to_date(to_char(:new.started_date,'DD-MON-YYYY HH24:MI:SS'),'DD-MON-YYYY HH24:MI:SS'))*24*60;
       end if;
    else
        if :new.duration_mins is not null 
        then
           :new.duration_mins := null;
        end if;
    end if;
end;
/

