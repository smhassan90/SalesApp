create trigger BI_ADC_TD_SMS
  before insert
  on ADC_TD_SMS
  for each row
  begin
 SELECT SQ_ADC_TD_SMS.NEXTVAL INTO :NEW.ADS_ID FROM DUAL;
 end;
/

