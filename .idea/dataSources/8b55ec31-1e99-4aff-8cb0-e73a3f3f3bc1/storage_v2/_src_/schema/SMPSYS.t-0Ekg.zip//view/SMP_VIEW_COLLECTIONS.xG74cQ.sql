create view SMP_VIEW_COLLECTIONS as
  SELECT dgl.dg_node "DG_NAME", nl.name "NODE_NAME", tl.name "TARGET_NAME", ttd.name "TARGET_TYPE", NVL(rtd.type_label,ttd.name) "TARGET_NLS_TYPE", principal_name "ADMINISTRATOR_NAME", dgl.collection_active "ACTIVE", dgh.is_repository "LOCAL"
  FROM   SMP_VTD_DG_LOCATION dgl, SMP_VTD_HISTORICAL_LOCATION dgh, SMP_VDU_PRINCIPALS_TABLE u, SMP_VDN_NODE_LIST nl, SMP_VDN_TARGET_LIST tl, SMP_VDN_TARGET_TYPE_DEFN ttd, SMP_VBO_REPORTS_TYPE_DEFN rtd
  WHERE  dgl.target_id = dgh.target_id
  AND    dgl.target_id = tl.id
  AND    tl.nodeid = nl.id
  AND    ttd.id = tl.typeid
  AND    dgl.principal_id = u.principal_id
  AND    UPPER(ttd.name) = rtd.type (+)
/

comment on table SMP_VIEW_COLLECTIONS
is 'List of all Data Gatherer collections defined in the repository'
/

