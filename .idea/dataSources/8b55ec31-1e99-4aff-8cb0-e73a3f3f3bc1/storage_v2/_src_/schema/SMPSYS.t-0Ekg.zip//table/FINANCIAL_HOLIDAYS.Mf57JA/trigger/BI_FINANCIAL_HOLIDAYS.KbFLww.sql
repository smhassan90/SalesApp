create trigger BI_FINANCIAL_HOLIDAYS
  before insert
  on FINANCIAL_HOLIDAYS
  for each row
  begin
    select SQ_FINANCIAL_HOLIDAYS.nextval INTO :new.HD_ID
    from dual;
end;
/

