create trigger BD_PROJ_STATUS_MS
  before delete
  on EBA_PROJ_STATUS_MS
  for each row
  begin
    eba_proj_fw.tag_sync(
        p_new_tags      => null,
        p_old_tags      => :old.tags,
        p_content_type  => 'MILESTONE',
        p_content_id    => :old.id );
end;
/

