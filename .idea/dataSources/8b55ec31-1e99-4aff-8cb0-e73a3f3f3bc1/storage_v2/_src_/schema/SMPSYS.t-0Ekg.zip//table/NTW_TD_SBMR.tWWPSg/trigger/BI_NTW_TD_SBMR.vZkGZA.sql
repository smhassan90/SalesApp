create trigger BI_NTW_TD_SBMR
  before insert
  on NTW_TD_SBMR
  for each row
  begin
  SELECT SQ_NTW_TD_SBMR.NEXTVAL INTO :NEW.SBMRD_ID FROM DUAL;
end;
/

