create view SSN_UNLOCKED_VOUCHERS as
  select 
 SSD.SSN_ID,
 SSD.BARCODE,
 SSD.ID as Client_ID,
 SSD.Name as Client_Name,
 SUBSTR(SSD.BARCODE,0,9) || '-' || SAC.account_title as Provider, -- call SP to get detailed column
 --SAC.account_title,
 TO_DATE(SSD.DATED||'-'||DECODE(SSD.MONTH,1,'January',
                 2,'Feb',
                 3,'Mar',
                 4,'Apr',
                 5,'May',
                 6,'Jun',
                 7,'Jul',
                 8,'Aug',
                 9,'Sep',
                 10,'Oct',
                 11,'Nov',
                 12,'Dec',SSD.MONTH)||'-'||SSD.YEAR) DATED,
 SUBSTR(SSD.BARCODE,10,LENGTH(SSD.BARCODE)) as Voucher_No,
 SSD.LOCKED

 from SSN_DATA SSD
 join SSN_MPV_ATMCARD SAC on (SUBSTR(SSD.BARCODE,0,9) = SAC.Provider_code)
 where SSD.LOCKED = 0
/

