create trigger TRG_PREINS_DD_MASTER
  before insert
  on DD_MASTER
  for each row
  declare
  V_ddm_id number(10);
begin
SELECT SQ_DD_MASTER.NEXTVAL INTO V_ddm_id FROM DUAL;
:NEW.ddm_id := lpad(V_ddm_id,10,0);
end;
/

