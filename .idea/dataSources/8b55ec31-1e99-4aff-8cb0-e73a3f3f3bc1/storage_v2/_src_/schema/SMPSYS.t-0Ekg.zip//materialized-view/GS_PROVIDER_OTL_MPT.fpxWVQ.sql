create materialized view GS_PROVIDER_OTL_MPT
refresh force on demand
  as
    SELECT a.*,
  dpo_otl_code,
  dpt_mpt_code,
  dpt_eff_date
FROM sal_sm_provider a,
  sal_sd_prv_outlet b,
  sal_sd_prv_training c
WHERE a.mpv_cp_code = b.dpo_cp_code (+)
AND a.mpv_code      = b.dpo_mpv_code (+)
AND a.mpv_cp_code   = c.dpt_cp_code (+)
AND a.mpv_code      = c.dpt_mpv_code (+)
AND a.mpv_flag      = 'Y'
AND b.dpo_lft_date IS NULL
AND c.dpt_eff_date  =
  (SELECT MAX(z.dpt_eff_date)
  FROM sal_sd_prv_training z
  WHERE z.dpt_mpv_code = c.dpt_mpv_code
  AND z.dpt_cp_code    = c.dpt_cp_code
  )







/

