create trigger BI_KPI_TRANS_ASSESMENT_MASTER
  before insert
  on KPI_TRANS_ASSESMENT_MASTER
  for each row
  begin
    select KPI_TRANS_ASSESMENT_MASTER_SEQ.nextval into :NEW.KAM_ID from dual;
end;
/

