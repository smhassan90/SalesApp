create view PS_MONTHLY_MEGESTRON as
  select to_char(m.msl_date,'YYMM'),to_char(m.msl_date,'MON-YYYY'), t.dsl_dit_code, 'C', sum(t.dsl_qty)
from   sal_tm_sales m , sal_td_sales t
where  m.msl_num = t.dsl_msl_num
and    m.msl_type = 'DS'
and    m.msl_status = 'P'
and    t.dsl_dit_code ='MEG001'
and    m.msl_date > '01-AUG-03'
group by to_char(m.msl_date,'YYMM'),to_char(m.msl_date,'MON-YYYY'), t.dsl_dit_code
union
select to_char(m.msl_date,'YYMM'),to_char(m.msl_date,'MON-YYYY'), t.dsl_dit_bns, 'B', sum(t.dsl_bns_qty)
from   sal_tm_sales m , sal_td_sales t
where  m.msl_num = t.dsl_msl_num
and    m.msl_type = 'DS'
and    m.msl_status = 'P'
and    t.dsl_dit_code ='MEG001'
and    m.msl_date > '01-AUG-03'
group by to_char(m.msl_date,'YYMM'),to_char(m.msl_date,'MON-YYYY'), t.dsl_dit_bns
union
select to_char(m.msl_date,'YYMM'),to_char(m.msl_date,'MON-YYYY'), t.dsl_dit_code, 'I', sum(t.dsl_qty)
from   sal_tm_sales m , sal_td_sales t
where  m.msl_num = t.dsl_msl_num
and    m.msl_type = 'SI'
and    t.dsl_dit_code ='MEG001'
and    m.msl_date > '01-AUG-03'
group by to_char(m.msl_date,'YYMM'),to_char(m.msl_date,'MON-YYYY'), t.dsl_dit_code
order by 1
/

