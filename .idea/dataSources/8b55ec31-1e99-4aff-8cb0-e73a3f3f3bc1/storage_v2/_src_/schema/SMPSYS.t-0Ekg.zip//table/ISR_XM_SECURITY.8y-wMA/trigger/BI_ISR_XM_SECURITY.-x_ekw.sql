create trigger BI_ISR_XM_SECURITY
  before insert
  on ISR_XM_SECURITY
  for each row
  begin
    select SQ_ISR_Xm_SECURITY.nextval INTO :new.SEC_ID
    from dual;
end;
/

