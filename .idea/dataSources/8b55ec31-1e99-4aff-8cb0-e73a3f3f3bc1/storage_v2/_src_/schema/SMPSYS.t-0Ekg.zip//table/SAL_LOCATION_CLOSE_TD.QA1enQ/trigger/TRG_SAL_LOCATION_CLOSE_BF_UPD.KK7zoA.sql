create trigger TRG_SAL_LOCATION_CLOSE_BF_UPD
  before update of SLT_DIT_CODE, SLT_STK_TYPE, SLT_BATCH_NO, SLT_EXP_DATE
  on SAL_LOCATION_CLOSE_TD
  for each row
  BEGIN
IF :OLD.SLT_DIT_CODE != :NEW.SLT_DIT_CODE 
OR :OLD.SLT_STK_TYPE != :NEW.SLT_STK_TYPE
OR :OLD.SLT_BATCH_NO != :NEW.SLT_BATCH_NO
OR :OLD.SLT_EXP_DATE != :NEW.SLT_EXP_DATE THEN

 IF :OLD.SLT_DIT_CODE != :NEW.SLT_DIT_CODE THEN
    raise_application_error(-20101,'<br><br><b><font color="RED">error detail:&nbsp;ITEMCODE CAN NOT BE CHANGE</font></b><br><br>');
 ELSIF :OLD.SLT_STK_TYPE != :NEW.SLT_STK_TYPE THEN
    raise_application_error(-20101,'<br><br><b><font color="RED">error detail:&nbsp;STOCK TYPE CAN NOT BE CHANGE</font></b><br><br>'); 
 ELSIF :OLD.SLT_BATCH_NO != :NEW.SLT_BATCH_NO THEN
     raise_application_error(-20101,'<br><br><b><font color="RED">error detail:&nbsp;BATCH NO CAN NOT BE CHANGE</font></b><br><br>'); 
 ELSE   
     raise_application_error(-20101,'<br><br><b><font color="RED">error detail:&nbsp;EXPIRY DATE CAN NOT BE CHANGE</font></b><br><br>'); 
 END IF;
    
END IF;
END;
/

