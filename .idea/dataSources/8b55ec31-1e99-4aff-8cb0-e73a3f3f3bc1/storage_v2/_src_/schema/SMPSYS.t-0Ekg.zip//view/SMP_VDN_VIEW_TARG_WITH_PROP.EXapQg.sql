create view SMP_VDN_VIEW_TARG_WITH_PROP as
  select unique
      target.id,
      target.name,
      type.name,
      node.name,
      targetprop.name,
      targetprop.value,
      '',
      ''
   from smp_vdn_target_list target,
      smp_vdn_target_type_defn type,
      smp_vdn_node_list node,
      smp_vdn_target_properties targetprop
   where (type.id = target.typeid AND
      target.nodeid = node.id AND
      target.id = targetprop.targetid)
   union select unique
      target.id,
      target.name,
      type.name,
      node.name,
      '',
      '',
      nodeprop.name,
      nodeprop.value
   from smp_vdn_target_list target,
      smp_vdn_target_type_defn type,
      smp_vdn_node_list node,
      smp_vdn_target_properties nodeprop
   where (type.id = target.typeid AND
      target.nodeid = node.id AND
      node.id = nodeprop.targetid )
   union select
      target.id,
      target.name,
      type.name,
      node.name,
      '',
      '',
      '',
      ''
   from smp_vdn_target_list target,
      smp_vdn_node_list node,
      smp_vdn_target_type_defn type
   where type.id = target.typeid AND
      target.nodeid = node.id AND
      target.id not in (select targetid from smp_vdn_target_properties) AND
      node.id not in (select targetid from smp_vdn_target_properties
)
/

