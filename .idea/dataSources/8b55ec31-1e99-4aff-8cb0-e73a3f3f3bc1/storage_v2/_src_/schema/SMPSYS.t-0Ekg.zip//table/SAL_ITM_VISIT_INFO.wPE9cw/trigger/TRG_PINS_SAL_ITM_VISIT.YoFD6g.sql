create trigger TRG_PINS_SAL_ITM_VISIT
  before insert
  on SAL_ITM_VISIT_INFO
  for each row
  begin
  SELECT SQ_SAL_ITM_VISIT_INFO.NEXTVAL INTO :NEW.ITM_VI_CODE FROM DUAL;
end;
/

