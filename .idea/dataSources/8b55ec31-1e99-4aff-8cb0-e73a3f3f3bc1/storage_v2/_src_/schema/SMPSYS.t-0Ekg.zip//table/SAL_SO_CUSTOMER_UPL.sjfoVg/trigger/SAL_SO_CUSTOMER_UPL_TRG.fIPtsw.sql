create trigger SAL_SO_CUSTOMER_UPL_TRG
  before insert
  on SAL_SO_CUSTOMER_UPL
  for each row
  begin
  SELECT SAL_SO_CUSTOMER_UPL_SEQ.NEXTVAL INTO :NEW.NUM FROM DUAL;
END;
/

