create view SMP_VIEW_EVENTS as
  SELECT e.id "EVENT_ID", e.name "EVENT_NAME", e.owner "ADMINISTRATOR_NAME",
         e.description "DESCRIPTION", e.target_type "TARGET_TYPE", NVL(rtd.type_label,e.target_type) "TARGET_NLS_TYPE",
         DECODE(e.is_library,'Y',1,0) "LIBRARY_EVENT", e.fixit_job_id "FIXIT_JOB_ID",
         DECODE(e.is_unsolicited,'Y',1,0) "UNSOLICITED",
         DECODE(e.snmp_trap_attribute,'Y',1,0) "SNMP_TRAP"
  FROM   SMP_VDE_EVENT e, SMP_VBO_REPORTS_TYPE_DEFN rtd
  WHERE  UPPER(e.target_type) = rtd.type (+)
/

comment on table SMP_VIEW_EVENTS
is 'List of all events known in the repository'
/

