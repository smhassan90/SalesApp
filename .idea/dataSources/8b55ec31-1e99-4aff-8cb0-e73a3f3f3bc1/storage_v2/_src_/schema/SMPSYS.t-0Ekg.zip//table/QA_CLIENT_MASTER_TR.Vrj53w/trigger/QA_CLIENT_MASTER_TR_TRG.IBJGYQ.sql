create trigger QA_CLIENT_MASTER_TR_TRG
  before insert
  on QA_CLIENT_MASTER_TR
  for each row
  begin
 SELECT QA_CLIENT_MASTER_TR_SEQ.NEXTVAL INTO :NEW.client_id FROM DUAL;
 end;
/

