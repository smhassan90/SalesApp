create trigger AIU_EBA_PROJ_STATUS_AIS
  after insert or update
  on EBA_PROJ_STATUS_AIS
  for each row
  begin
    --
    -- cascade update to project
    --
    update EBA_PROJ_STATUS set updated = localtimestamp
    where  id = :new.project_id;
end;
/

