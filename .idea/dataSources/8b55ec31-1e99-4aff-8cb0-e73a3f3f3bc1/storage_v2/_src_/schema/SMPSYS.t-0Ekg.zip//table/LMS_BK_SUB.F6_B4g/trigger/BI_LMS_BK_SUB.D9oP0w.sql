create trigger BI_LMS_BK_SUB
  before insert
  on LMS_BK_SUB
  for each row
  begin  
    select "LMS_BK_SUB_SEQ".nextval into :NEW.BK_SUB_ID from dual;
end;
/

