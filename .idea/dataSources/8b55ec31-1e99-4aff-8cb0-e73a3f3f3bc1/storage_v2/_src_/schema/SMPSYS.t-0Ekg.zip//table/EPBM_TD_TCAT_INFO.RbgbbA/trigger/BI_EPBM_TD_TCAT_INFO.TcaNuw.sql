create trigger BI_EPBM_TD_TCAT_INFO
  before insert
  on EPBM_TD_TCAT_INFO
  for each row
  BEGIN
    SELECT epbm_td_tcat_info_seq.NEXTVAL INTO :NEW.etd_id
    FROM DUAL;
END;
/

