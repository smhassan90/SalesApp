create trigger GSM_POSTED_HS_DT03_TRG
  before insert
  on GSM_POSTED_HS_DT03
  for each row
  begin
  IF :NEW.DT_ID IS NULL THEN
    SELECT GSM_POSTED_HS_DT03_SEQ.NEXTVAL INTO :NEW.DT_ID FROM DUAL;
  END IF;
end;
/

