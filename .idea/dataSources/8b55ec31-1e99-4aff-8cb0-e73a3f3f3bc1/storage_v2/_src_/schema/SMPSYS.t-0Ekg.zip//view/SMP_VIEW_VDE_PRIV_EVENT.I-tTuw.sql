create view SMP_VIEW_VDE_PRIV_EVENT as
  select id, name, Event.owner, description, target_type, 
     is_library, fixit_job_id, fixit_job_name, fixit_job_owner, 
     is_unsolicited, incomplete, snmp_trap_attribute,
     principal_name, privilege_string FROM
   SMP_VDE_EVENT Event, SMP_VDU_PRINCIPALS_TABLE Users,
        SMP_VDU_OBJECTS_TABLE Objects,
        SMP_VDU_PRIVILEGE_TABLE Privilege where
      Objects.type='EVENT' AND 
      to_char(Event.id)=to_char(Objects.object_name) AND 
      Objects.object_id=Privilege.object_oid AND 
      Privilege.principal_oid=Users.principal_id
/

