create trigger TRG_PINS_SAL_TEC_VISIT
  before insert
  on SAL_TEC_VISIT_INFO
  for each row
  begin
  SELECT SQ_SAL_TEC_VISIT_INFO.NEXTVAL INTO :NEW.TVI_CODE FROM DUAL;
end;
/

