create view SMP_VIEW_VDE_ACTIVE_EVENT_INFO as
  select i.event_id, i.target_name, i.target_type, i.node_name, i.agent_status, 
        i.timestamp, i.timezone, i.error_code, i.error_message, 
        decode(i.target_type, 'oracle_sysman_group', 'Unknown', NVL(p.value, 'Unknown')) from
(select targetid, name, value from smp_vdn_target_properties where lower(name)='agentversion') p,
smp_vde_event_target_info i, smp_vdn_node_list nl
where
        i.agent_status != 208 and 
        i.node_name = nl.name and
        nl.id=p.targetid (+)
/

