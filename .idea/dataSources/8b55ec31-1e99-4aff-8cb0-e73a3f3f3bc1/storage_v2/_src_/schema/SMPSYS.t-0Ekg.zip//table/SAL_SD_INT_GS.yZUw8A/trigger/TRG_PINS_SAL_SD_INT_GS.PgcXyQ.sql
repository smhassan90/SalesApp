create trigger TRG_PINS_SAL_SD_INT_GS
  before insert
  on SAL_SD_INT_GS
  for each row
  begin
IF :NEW.DIG_ID IS NULL THEN
   :NEW.DIG_ID := :NEW.DIG_MPV_CODE||'-'||:NEW.DIG_TRA_CODE;
END IF;
END;
/

