create view SMP_VIEW_EVENT_TESTS as
  SELECT e.id "EVENT_ID", e.name "EVENT_NAME", ed.company||'/'||ed.organization||'/'||ed.product||'/'||ed.filename "EVENT_TEST"
  FROM   smp_vde_event e, smp_vde_event_details ed
  WHERE  e.id = ed.event_id
/

comment on table SMP_VIEW_EVENT_TESTS
is 'List of all events known in the repository'
/

