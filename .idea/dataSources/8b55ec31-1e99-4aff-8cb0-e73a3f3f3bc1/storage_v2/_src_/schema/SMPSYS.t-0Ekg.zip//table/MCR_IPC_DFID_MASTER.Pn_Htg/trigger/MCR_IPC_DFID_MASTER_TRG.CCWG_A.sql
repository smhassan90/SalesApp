create trigger MCR_IPC_DFID_MASTER_TRG
  before insert
  on MCR_IPC_DFID_MASTER
  for each row
  begin
 SELECT MCR_IPC_DFID_MASTER_SEQ.NEXTVAL INTO :NEW.MCR_ID FROM DUAL;
 end;
/

