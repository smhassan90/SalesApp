create trigger TRG_PRE_DTB_TDT_BATCH
  before insert
  on DTB_TDT_BATCH
  for each row
  begin
 SELECT SQ_DTB_TDT_BATCH.NEXTVAL INTO :NEW.DTD_ID FROM DUAL;
 end;
/

