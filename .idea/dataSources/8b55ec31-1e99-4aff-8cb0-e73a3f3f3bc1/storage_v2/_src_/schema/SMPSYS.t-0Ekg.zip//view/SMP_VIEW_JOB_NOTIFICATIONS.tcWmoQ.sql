create view SMP_VIEW_JOB_NOTIFICATIONS as
  SELECT j.job_id "JOB_ID", j.job_name "JOB_NAME", ion.username "ADMINISTRATOR_NAME", jpt.target_name "TARGET_NAME", jpt.target_type "TARGET_TYPE", NVL(rtd.type_label,jpt.target_type) "TARGET_NLS_TYPE"
  FROM   SMP_VDI_AOBJECT_NOTIFICATION ion, SMP_VDI_OBJECT_TABLE iot, SMP_VDJ_JOB j, SMP_VDJ_JOB_PER_TARGET jpt, SMP_VBO_REPORTS_TYPE_DEFN rtd
  WHERE  ion.notify = 1
    AND  iot.object_id = ion.object_id
    AND  iot.TYPE = 'JOB'
    AND  iot.object_name = j.job_id
    AND  j.is_lib = 0
    AND  j.job_id = jpt.job_id
    AND  UPPER(jpt.target_type) = rtd.type (+)
/

comment on table SMP_VIEW_JOB_NOTIFICATIONS
is 'List of all administrators who will get notified about job conditions'
/

