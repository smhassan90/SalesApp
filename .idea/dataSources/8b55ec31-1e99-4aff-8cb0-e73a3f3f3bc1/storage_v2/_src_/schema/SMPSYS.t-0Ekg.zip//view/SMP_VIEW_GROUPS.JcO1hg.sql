create view SMP_VIEW_GROUPS as
  SELECT gl.name "GROUP_NAME", gl.owner "GROUP_OWNER", gl.description "DESCRIPTION",
         gl.backgroundfileurl "BACKGROUND_IMAGE",
         gl.iconsize "ICON_SIZE"
  FROM   smp_vdn_group_list gl
/

comment on table SMP_VIEW_GROUPS
is 'List of all groups defined in the navigator'
/

