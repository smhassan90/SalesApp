create view ITM_MON_WISE_SALES as
  (
SELECT ITEMCODE,ITEMNAME,ITEMCODE||' - '||ITEMNAME Product,to_char(MONTH,'MON-YY') Month,COMPANY,
       SUM(DS) Staff,
       SUM(SD) SelfDistribution,
       SUM(SEC) SalesByDistributor,
       SUM(SEC_SALES) TotalSales        
FROM REGION_ITEM_MONTH_SEC_SALES, INV_SM_ITEM,
     INV_SD_ITEM, INV_SO_ITEM_CATEGORY
WHERE company      = Dit_cp_code
  AND itemcode     = Dit_code
  AND DIT_CP_CODE  = CTG_CP_CODE 
  AND DIT_CTG_CODE = CTG_CODE
  AND MIT_CP_CODE  = DIT_CP_CODE 
  AND MIT_CODE     = DIT_MIT_CODE
 -- AND COMPANY      = :G_CP_CODE
--  AND INSTR(':'||:P5151_ITM||':',':'||CTG_CODE||':') > 0 
 -- AND MONTH  BETWEEN :P5151_DATE AND :P5151_DATE2
GROUP BY ITEMCODE,ITEMNAME,to_char(MONTH,'MON-YY'),COMPANY
)
/

