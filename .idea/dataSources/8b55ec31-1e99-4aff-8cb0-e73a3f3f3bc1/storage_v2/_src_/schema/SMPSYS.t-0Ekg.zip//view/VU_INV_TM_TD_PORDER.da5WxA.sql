create view VU_INV_TM_TD_PORDER as
  select mpo_cp_code, mpo_num, mpo_date, mpo_p_code, mpo_acc_no,
       mpo_sup_code,
       dpo_dit_code, dpo_qty, dpo_rate, dpo_amt, DPO_DLV_DATE
from inv_tm_porder, inv_td_porder
where inv_tm_porder.mpo_cp_code = inv_td_porder.dpo_cp_code
  and inv_tm_porder.mpo_num     = inv_td_porder.dpo_mpo_num
  and inv_tm_porder.mpo_status <> 'C'
/

