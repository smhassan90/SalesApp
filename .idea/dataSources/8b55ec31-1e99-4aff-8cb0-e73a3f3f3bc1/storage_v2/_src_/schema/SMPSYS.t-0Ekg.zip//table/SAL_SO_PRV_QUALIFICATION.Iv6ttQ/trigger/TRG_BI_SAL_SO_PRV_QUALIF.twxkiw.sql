create trigger TRG_BI_SAL_SO_PRV_QUALIF
  before insert
  on SAL_SO_PRV_QUALIFICATION
  for each row
  begin
  SELECT SQ_SAL_SO_PRV_QUALIF.NEXTVAL INTO :NEW.PQL_ID FROM DUAL;
end;
/

