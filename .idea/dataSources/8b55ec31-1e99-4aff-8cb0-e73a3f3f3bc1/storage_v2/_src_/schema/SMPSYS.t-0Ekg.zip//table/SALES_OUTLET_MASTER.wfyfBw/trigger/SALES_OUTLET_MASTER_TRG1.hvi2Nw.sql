create trigger SALES_OUTLET_MASTER_TRG1
  before insert or update
  on SALES_OUTLET_MASTER
  for each row
  BEGIN
  
  :NEW.TRANS_DATE := TO_DATE(SYSDATE);
  
END;
/

