create trigger BI_ISR_XD_SECURITY
  before insert
  on ISR_XD_SECURITY
  for each row
  begin
    select SQ_ISR_XD_SECURITY.nextval INTO :new.DSC_ID
    from dual;
end;
/

