create view SMP_VIEW_EVENT_TEST_HISTORY as
  SELECT e.id "EVENT_ID", e.name "EVENT_NAME", el.event_test_id "TEST_ID", ed.company||'/'||ed.organization||'/'||ed.product||'/'||ed.filename "EVENT_TEST", ed.test_name "TEST_NAME",
         el.event_occurrence_id "OCCURRENCE_ID", eo.node_name "NODE_NAME", eo.target_name "TARGET_NAME", eo.target_type "TARGET_TYPE", NVL(rtd.type_label,eo.target_type) "TARGET_NLS_TYPE",
         eo.assignee "OWNER", el.timestamp+el.timezone/86400000 "TIMESTAMP", el.ENTRY "MESSAGE", el.severity "EVENT_SEVERITY", el.event_test_severity "TEST_SEVERITY", eo.status "ACTIVE"
  FROM   SMP_VDE_EVENT e, SMP_VDE_EVENT_OCCURRENCE eo, SMP_VDE_EVENT_LOG el, SMP_VDE_EVENT_OCCUR_DETAILS ed, SMP_VBO_REPORTS_TYPE_DEFN rtd
  WHERE  e.id = eo.event_id
    AND  eo.event_occurrence_id = ed.event_occurrence_id
    AND  el.event_test_id = ed.event_test_id
    AND  eo.event_occurrence_id = el.event_occurrence_id
    AND  UPPER(eo.target_type) = rtd.type (+)
/

comment on table SMP_VIEW_EVENT_TEST_HISTORY
is 'List of all occurrences per event in the repository'
/

