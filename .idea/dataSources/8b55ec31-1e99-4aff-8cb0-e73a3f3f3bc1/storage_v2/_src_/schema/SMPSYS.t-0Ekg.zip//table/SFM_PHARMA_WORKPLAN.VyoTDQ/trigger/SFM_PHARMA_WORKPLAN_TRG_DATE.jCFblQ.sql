create trigger SFM_PHARMA_WORKPLAN_TRG_DATE
  before insert or update
  on SFM_PHARMA_WORKPLAN
  for each row
  BEGIN
  
  :NEW.TRANS_DATE := TO_DATE(SYSDATE);
  
END;
/

