create trigger TRG_PRE_INS_QAF_SO_SUBJECT
  before insert
  on QAF_SO_SUBJECT
  for each row
  begin
 SELECT SQ_QAF_SO_SUBJECT.NEXTVAL INTO :NEW.QSS_ID FROM DUAL;
 end;
/

