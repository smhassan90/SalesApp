create trigger PRE_UPD_SAL_SD_VSC
  before update of DVSC_COL_VALUE
  on SAL_SD_VSC
  for each row
  DECLARE
MSG VARCHAR2(100);
BEGIN
 SELECT CI_DID_CODE||' -'||CI_DID_DESC INTO MSG
 FROM SAL_SO_DID WHERE CI_DID_ID = :NEW.DVSC_CI_DID_ID;

 IF ( :NEW.DVSC_CI_DID_ID = 34 OR :NEW.DVSC_CI_DID_ID = 35 OR :NEW.DVSC_CI_DID_ID = 36 OR :NEW.DVSC_CI_DID_ID = 38 OR
     :NEW.DVSC_CI_DID_ID = 39 OR :NEW.DVSC_CI_DID_ID = 44 OR :NEW.DVSC_CI_DID_ID = 46 OR :NEW.DVSC_CI_DID_ID = 48 OR
     :NEW.DVSC_CI_DID_ID = 50 OR :NEW.DVSC_CI_DID_ID = 51 OR :NEW.DVSC_CI_DID_ID = 52 ) THEN
    IF ( :NEW.DVSC_COL_VALUE = 'Y' OR :NEW.DVSC_COL_VALUE = 'N' ) THEN
          null;
    ELSE
    raise_application_error(-20101,'<br><br><b><font color="BLUE">'||MSG||'</font><font color="RED">  ==>  Value Should be Y or N.</font></b><br><br>');
    END IF;

 ELSIF ( :NEW.DVSC_CI_DID_ID = 43 OR :NEW.DVSC_CI_DID_ID = 45 OR :NEW.DVSC_CI_DID_ID = 49 ) THEN

  declare
   A   number;
  begin
 	select :NEW.DVSC_COL_VALUE INTO A FROM DUAL;
 	Exception	when others then
    raise_application_error(-20101,'<br><br><b><font color="BLUE">'||MSG||'</font><font color="RED">  ==>  Value Should be Number.</font></b><br><br>');
  end;

 ELSIF :NEW.DVSC_CI_DID_ID = 40  THEN

		declare
    	B DATE;
    begin
		    SELECT TO_DATE(:NEW.DVSC_COL_VALUE,'DD/MM/YYYY') INTO B from dual;
    Exception when no_data_found then
    raise_application_error(-20101,'<br><br><b><font color="BLUE">'||MSG||'</font><font color="RED">  ==>  Value Should be Date with format DD/MM/YYYY.</font></b><br><br>');
             when  others then
    raise_application_error(-20101,'<br><br><b><font color="BLUE">'||MSG||'</font><font color="RED">  ==>  Value Should be Date with format DD/MM/YYYY.</font></b><br><br>');
    end;
 END IF;

END;
/

