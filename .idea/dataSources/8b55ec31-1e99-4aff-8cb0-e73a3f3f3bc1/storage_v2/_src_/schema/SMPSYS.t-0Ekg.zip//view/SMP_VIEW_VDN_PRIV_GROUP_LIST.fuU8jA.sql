create view SMP_VIEW_VDN_PRIV_GROUP_LIST as
  SELECT id, name, Grp.owner, 
      description, BackgroundFileURL, IconSize, principal_name, 
      privilege_string FROM
        SMP_VDN_GROUP_LIST Grp, SMP_VDU_PRINCIPALS_TABLE Users,
        SMP_VDU_OBJECTS_TABLE Objects,
        SMP_VDU_PRIVILEGE_TABLE Privilege where
      Objects.type='GROUP' AND 
      Grp.Name=Objects.object_name AND 
      Grp.owner=Objects.owner AND
      Objects.object_id=Privilege.object_oid AND 
      Privilege.principal_oid=Users.principal_id
/

