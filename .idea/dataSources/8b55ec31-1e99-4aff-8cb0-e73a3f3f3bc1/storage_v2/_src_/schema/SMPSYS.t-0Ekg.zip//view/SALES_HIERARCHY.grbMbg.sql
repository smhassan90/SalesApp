create view SALES_HIERARCHY as
  select  s.dsl_cp_code CP_CODE,
        s.dsl_msl_code Spo_Code,  upper(sn.mlc_desc) Spo_Name,
        s.dsl_sub_code Town_Code, upper(tn.msl_desc) Town_Name,
        get_level(s.dsl_cp_code,'A',sysdate, s.dsl_sub_code,'T') Territory_Code,
        upper(get_level_name(s.dsl_cp_code, get_level(s.dsl_cp_code,'A',sysdate, s.dsl_sub_code,'T'))) Territory_Name,
        get_level(s.dsl_cp_code,'Z',sysdate,
                  get_level(s.dsl_cp_code,'A',sysdate, s.dsl_sub_code,'T'),'A') Zone_Code,
        upper(get_level_name(s.dsl_cp_code,
                      get_level(s.dsl_cp_code,'Z',sysdate,
                                get_level(s.dsl_cp_code,'A',sysdate, s.dsl_sub_code,'T'),
                                'A')
                      )) Zone_Name,
        get_level(s.dsl_cp_code,'R',sysdate,
                  get_level(s.dsl_cp_code,'Z',sysdate,
                            get_level(s.dsl_cp_code,'A',sysdate, s.dsl_sub_code,'T'),
                            'A'),
                 'Z' ) Region_Code,
        upper(get_level_name(s.dsl_cp_code,
                       get_level(s.dsl_cp_code,'R',sysdate,
                                 get_level(s.dsl_cp_code,'Z',sysdate,
                                           get_level(s.dsl_cp_code,'A',sysdate, s.dsl_sub_code,'T'),
                                          'A'),
                                 'Z' )
                      )) Region_Name,
        get_level(s.dsl_cp_code,'C',sysdate, s.dsl_sub_code,'T') City_Code,
        upper(get_level_name(s.dsl_cp_code, get_level(s.dsl_cp_code,'C',sysdate, s.dsl_sub_code,'T'))) City_Name,
        get_level(s.dsl_cp_code,'D',sysdate,
                  get_level(s.dsl_cp_code,'C',sysdate, s.dsl_sub_code,'T'),
                 'C') District_Code,
        upper(get_level_name(s.dsl_cp_code,
                       get_level(s.dsl_cp_code,'D',sysdate,
                                 get_level(s.dsl_cp_code,'C',sysdate, s.dsl_sub_code,'T'),
                       'C')
                      )) District_Name,
        get_level(s.dsl_cp_code,'P',sysdate,
                  get_level(s.dsl_cp_code,'D',sysdate,
                            get_level(s.dsl_cp_code,'C',sysdate, s.dsl_sub_code,'T'),
                            'C'),
                  'D'
                  ) Province_Code,
        upper(get_level_name(s.dsl_cp_code,
                       get_level(s.dsl_cp_code,'P',sysdate,
                                 get_level(s.dsl_cp_code,'D',sysdate,
                                           get_level(s.dsl_cp_code,'C',sysdate, s.dsl_sub_code,'T'),
                                 'C'),
                       'D')
                      )) Province_Name
from    sal_sd_sales_level s, inv_sm_location sn,
        sal_sm_sales_level tn
where   s.dsl_msl_code = sn.mlc_code
  and   s.dsl_cp_code  = sn.mlc_cp_code
  and   s.dsl_sub_code = tn.msl_code
  and   s.dsl_cp_code  = tn.msl_cp_code
  and   s.dsl_eff_date = (select max(sd.dsl_eff_date)
                          from sal_sd_sales_level sd
			  where sd.dsl_sub_code = s.dsl_sub_code
			    and substr(dsl_msl_code,1,1) = 'S'
			    and sd.dsl_cp_Code = s.dsl_Cp_Code
                          )
/

