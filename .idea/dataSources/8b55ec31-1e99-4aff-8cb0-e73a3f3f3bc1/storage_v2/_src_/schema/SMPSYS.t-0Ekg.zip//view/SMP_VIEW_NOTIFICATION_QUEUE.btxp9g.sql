create view SMP_VIEW_NOTIFICATION_QUEUE as
  SELECT n.sequence_num "SEQUENCE_NUM", n.notification_type "SUBSYSTEM", n.subtype "NOTIFICATION_TYPE", n.node_name "NODE_NAME", n.service_name "TARGET_NAME", service_type "TARGET_TYPE", NVL(rtd.type_label,service_type) "TARGET_NLS_TYPE", na.username "ADMINISTRATOR_NAME", n.time_stamp+n.time_zone/86400000 "TIMESTAMP"
 FROM   SMP_VDM_NOTIFICATION n, SMP_VDM_ADDRESS na, SMP_VBO_REPORTS_TYPE_DEFN rtd
 WHERE  n.sequence_num = na.sequence_num
   AND  UPPER(service_type) = rtd.type (+)
/

comment on table SMP_VIEW_NOTIFICATION_QUEUE
is 'List of all pending notifications in the queue'
/

