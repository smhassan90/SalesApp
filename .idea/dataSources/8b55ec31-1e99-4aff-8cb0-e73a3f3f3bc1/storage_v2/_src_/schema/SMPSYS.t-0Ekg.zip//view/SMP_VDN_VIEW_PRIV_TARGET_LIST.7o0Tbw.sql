create view SMP_VDN_VIEW_PRIV_TARGET_LIST as
  SELECT target.Id, 
		  target.Name, 
		  target.Description, 
		  type.Name, 
		  type.Id, 
		  node.Name, 
		  node.Id, 
		  target.TNSAddr, 
		  target.UserData, 
		  node.Agent, 
		  target.WithAgent, 
		  target.TotalBlackout,
          principals.PRINCIPAL_NAME
        FROM SMP_VDN_TARGET_LIST target,
			 SMP_VDN_NODE_LIST node,
			 SMP_VDN_TARGET_TYPE_defn type,
             SMP_VDU_OBJECTS_TABLE    objects,
             SMP_VDU_PRINCIPALS_TABLE principals,
             SMP_VDU_PRIVILEGE_TABLE  privilege
        WHERE
            (
			target.nodeid = node.id AND
			target.typeid = type.id AND 
			objects.OBJECT_NAME = TO_CHAR(target.Id) AND
            objects.OBJECT_ID = privilege.OBJECT_OID AND
            objects.type='TARGET' AND
            principals.PRINCIPAL_ID = privilege.PRINCIPAL_OID AND
            privilege.PRIVILEGE_STRING = 'VIEW'
			)
        OR 
            (
			target.nodeid = node.id AND
			target.typeid = type.id AND 
            objects.OWNER = 'OEM' AND
            objects.type  = 'OEM_SUBSYSTEM' AND
            objects.OBJECT_NAME  = 'OEM_SUPERUSER' AND
            objects.OBJECT_ID = privilege.OBJECT_OID AND
            principals.type = 'OEM_USER' AND
            principals.PRINCIPAL_ID = privilege.PRINCIPAL_OID AND
            privilege.PRIVILEGE_STRING = 'IS' 
			)
/

