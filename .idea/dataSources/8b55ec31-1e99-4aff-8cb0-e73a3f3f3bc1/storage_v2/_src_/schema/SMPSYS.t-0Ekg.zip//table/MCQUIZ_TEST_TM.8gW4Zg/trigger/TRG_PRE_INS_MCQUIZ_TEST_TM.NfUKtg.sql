create trigger TRG_PRE_INS_MCQUIZ_TEST_TM
  before insert
  on MCQUIZ_TEST_TM
  for each row
  begin
 SELECT SQ_MCQUIZ_TEST_TM.NEXTVAL INTO :NEW.MTT_ID FROM DUAL;
 end;
/

