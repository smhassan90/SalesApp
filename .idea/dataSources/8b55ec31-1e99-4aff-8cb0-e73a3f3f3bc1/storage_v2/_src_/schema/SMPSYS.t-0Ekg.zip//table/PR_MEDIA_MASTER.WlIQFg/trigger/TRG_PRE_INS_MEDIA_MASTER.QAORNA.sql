create trigger TRG_PRE_INS_MEDIA_MASTER
  before insert
  on PR_MEDIA_MASTER
  for each row
  begin
  SELECT SQ_PR_MEDIA_MASTER.NEXTVAL INTO :NEW.PMM_ID FROM DUAL;
end;
/

