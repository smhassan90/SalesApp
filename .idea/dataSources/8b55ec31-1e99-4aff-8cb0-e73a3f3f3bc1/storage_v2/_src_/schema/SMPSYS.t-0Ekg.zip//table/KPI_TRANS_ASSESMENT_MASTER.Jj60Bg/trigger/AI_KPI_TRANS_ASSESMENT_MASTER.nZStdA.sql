create trigger AI_KPI_TRANS_ASSESMENT_MASTER
  after insert
  on KPI_TRANS_ASSESMENT_MASTER
  for each row
  DECLARE
 V_TGT_DAYS NUMBER :=0;
 V_TGT_TYPE CHAR := NULL;
BEGIN
    FOR KPIS IN (
                SELECT KPI_ID, KPI_NO, KPI_DESC, KPI_PARENT_ID,
                       KPI_STD_PTS
                 FROM KPI_SETUP_MASTER,INV_SM_LOCATION
                 WHERE :NEW.KAM_MST_LOC = MLC_CODE
                 AND   MLC_CP_CODE = '01'
                 AND ((KPI_LOC_TYPE = DECODE(SUBSTR(:NEW.KAM_MST_LOC,1,1),'W','D', SUBSTR(:NEW.KAM_MST_LOC,1,1)) AND SUBSTR(:NEW.KAM_MST_LOC,1,1) NOT IN ('S','P','U','M')) OR 
                      (KPI_LOC_TYPE = 'S' AND SUBSTR(:NEW.KAM_MST_LOC,1,1) = 'S' AND MLC_DESC NOT LIKE '%Tso%') OR 
                      (KPI_LOC_TYPE = 'D' AND SUBSTR(:NEW.KAM_MST_LOC,1,1) = 'S' AND MLC_DESC LIKE '%Tso%') OR
                      (KPI_LOC_TYPE = 'B' AND SUBSTR(:NEW.KAM_MST_LOC,1,1) = 'P' AND MLC_DESC LIKE '%Thse%') OR
                      (KPI_LOC_TYPE = 'C' AND SUBSTR(:NEW.KAM_MST_LOC,1,1) = 'P' AND MLC_DESC LIKE '%Chse%') OR
                      (KPI_LOC_TYPE = 'F' AND SUBSTR(:NEW.KAM_MST_LOC,1,1) = 'P' AND MLC_DESC LIKE '%Fho%') OR
                      (KPI_LOC_TYPE = 'U' AND SUBSTR(:NEW.KAM_MST_LOC,1,1) = 'U' AND MLC_DESC NOT LIKE '%Glmr%') OR
                      (KPI_LOC_TYPE = 'G' AND SUBSTR(:NEW.KAM_MST_LOC,1,1) = 'U' AND MLC_DESC LIKE '%Glmr%') OR
                      (KPI_LOC_TYPE = 'A' AND SUBSTR(:NEW.KAM_MST_LOC,1,1) = 'M' AND MLC_DESC LIKE '%ASMM%') OR
                      (KPI_LOC_TYPE = 'O' AND SUBSTR(:NEW.KAM_MST_LOC,1,1) = 'M' AND MLC_DESC LIKE '%Amo%') OR
                      (KPI_LOC_TYPE = 'M' AND SUBSTR(:NEW.KAM_MST_LOC,1,1) = 'M') /*--AND MLC_DESC LIKE '%Mo%' */ OR
                      (KPI_LOC_TYPE = 'H' AND SUBSTR(:NEW.KAM_MST_LOC,1,1) = 'M' AND UPPER(MLC_DESC) LIKE '%MHS%') OR
                      (KPI_LOC_TYPE = 'E' AND SUBSTR(:NEW.KAM_MST_LOC,1,1) = 'M' AND UPPER(MLC_DESC) LIKE '%MIPC%') OR
                      (KPI_LOC_TYPE = 'J' AND SUBSTR(:NEW.KAM_MST_LOC,1,1) = 'M' AND UPPER(MLC_DESC) LIKE '%MMR%')
                     )
--                 AND KPI_TGT_TYPE = V_TGT_TYPE
                 AND KPI_ACTIVE    = 'Y'
                 AND KPI_NO LIKE 'Q%' AND KPI_PARENT_ID IS NOT NULL
                 ORDER BY KPI_LOC_TYPE, KPI_ID ASC
                     ) LOOP
         INSERT INTO KPI_TRANS_ASSESMENT_DETAIL
           (KAD_KAM_ID,  KAD_KPI_ID,  KAD_KPI_NO,
            KAD_KPI_DESC, KAD_KPI_PARENT_ID, KAD_PTS_TOT)
         VALUES
           (:NEW.KAM_ID, KPIS.KPI_ID, KPIS.KPI_NO, KPIS.KPI_DESC,
            KPIS.KPI_PARENT_ID, KPIS.KPI_STD_PTS);
    END LOOP;
END;
/

