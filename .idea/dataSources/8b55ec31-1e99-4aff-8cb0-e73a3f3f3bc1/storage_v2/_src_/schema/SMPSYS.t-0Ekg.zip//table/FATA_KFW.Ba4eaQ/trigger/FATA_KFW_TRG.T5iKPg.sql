create trigger FATA_KFW_TRG
  before insert
  on FATA_KFW
  for each row
  BEGIN
    IF :NEW.SID IS NULL THEN
    SELECT FATA_KFW_SEQ.NEXTVAL INTO :NEW.SID FROM DUAL;
 END IF;
end;
/

