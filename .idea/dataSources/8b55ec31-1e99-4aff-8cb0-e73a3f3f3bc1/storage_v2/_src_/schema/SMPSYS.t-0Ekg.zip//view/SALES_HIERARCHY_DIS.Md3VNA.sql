create view SALES_HIERARCHY_DIS as
  select t.dsl_sub_code "Town_Code", tn.msl_desc "Town_Name",
       s.dsl_msl_code "Spo_Code", spn.mlc_desc "Spo_Name",
       c.dsl_sub_code "City_Code", cn.msl_desc "City_Name",
       r.dsl_sub_code "Zone_Code", zn.msl_desc "Zone_Name",
       r.dsl_msl_code "Region_Code", i.mlc_desc "Region_Name",
       t.dsl_dis_twn "Dis_Town_Code"
from   sal_sd_sales_level r,
            inv_sm_location i,
            sal_sd_sales_level c,
            sal_sd_sales_level t,
            sal_sm_sales_level tn,
            sal_sm_sales_level zn,
            sal_sm_sales_level cn,
            sal_sd_sales_level s,
            inv_sm_location spn
where  r.dsl_msl_code = i.mlc_code
and    r.dsl_sub_code = c.dsl_msl_code
and    c.dsl_sub_code = t.dsl_msl_code
and    substr(t.dsl_msl_code,1,1) = 'C'
and    t.dsl_sub_code = tn.msl_code
and    r.dsl_sub_code = zn.msl_code
and    c.dsl_sub_code = cn.msl_code
and    s.dsl_sub_code = t.dsl_sub_code
and    substr(s.dsl_msl_code,1,1) = 'S'
and    s.dsl_msl_code = spn.mlc_code
and    s.dsl_eff_date = (select max(sd.dsl_eff_date) from sal_sd_sales_level sd
    where sd.dsl_sub_code = s.dsl_sub_code
    and substr(dsl_msl_code,1,1) = 'S')
/

