create trigger MIO_DCR_MASTER_TRG
  before insert
  on MIO_DCR_MASTER
  for each row
  begin
  SELECT MIO_DCR_MASTER_SEQ.NEXTVAL INTO :NEW.DCR_ID FROM DUAL;
end;
/

