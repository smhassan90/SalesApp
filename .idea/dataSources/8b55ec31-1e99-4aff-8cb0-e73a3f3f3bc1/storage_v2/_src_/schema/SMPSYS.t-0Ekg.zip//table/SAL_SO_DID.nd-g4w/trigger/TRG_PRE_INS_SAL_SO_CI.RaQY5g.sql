create trigger TRG_PRE_INS_SAL_SO_CI
  before insert
  on SAL_SO_DID
  for each row
  begin
SELECT SQ_SAL_SO_CI.NEXTVAL INTO :NEW.CI_DID_ID FROM DUAL;
end;
/

