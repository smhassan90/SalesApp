create trigger AU_EBA_PROJ_STATUS_AIS
  after update
  on EBA_PROJ_STATUS_AIS
  for each row
  declare
    ov varchar2(4000) := null;
    nv varchar2(4000) := null;
begin
    -- PROJECT_ID (foreign key)
    if nvl(:old.project_id,-999) != nvl(:new.project_id,-999) then
        ov := null; nv := null;
        for c1 in (select row_key val from eba_proj_status t where t.id = :old.project_id) loop
            ov := c1.val;
        end loop;
        for c1 in (select row_key val from eba_proj_status t where t.id = :new.project_id) loop
            nv := c1.val;
        end loop;
        insert into eba_proj_history (table_name, component_rowkey, component_id, column_name, old_value, new_value) values
            ('STATUS_AIS', :new.row_key, :new.id, 'PROJECT_ID', ov, nv);
    end if;
    -- ACTION_OWNER_01 (default)
    if nvl(:old.action_owner_01, '0') != nvl(:new.action_owner_01,'0') then 
        insert into eba_proj_history (table_name, component_rowkey, component_id, column_name, old_value, new_value) values 
            ('STATUS_AIS', :new.row_key, :new.id, 'ACTION_OWNER_01', substr(:old.action_owner_01,0,4000), substr(:new.action_owner_01,0,4000) ); 
    end if;
    -- ACTION_OWNER_02 (default)
    if nvl(:old.action_owner_02, '0') != nvl(:new.action_owner_02,'0') then 
        insert into eba_proj_history (table_name, component_rowkey, component_id, column_name, old_value, new_value) values 
            ('STATUS_AIS', :new.row_key, :new.id, 'ACTION_OWNER_02', substr(:old.action_owner_02,0,4000), substr(:new.action_owner_02,0,4000) ); 
    end if;
    -- ACTION_OWNER_03 (default)
    if nvl(:old.action_owner_03, '0') != nvl(:new.action_owner_03,'0') then 
        insert into eba_proj_history (table_name, component_rowkey, component_id, column_name, old_value, new_value) values 
            ('STATUS_AIS', :new.row_key, :new.id, 'ACTION_OWNER_03', substr(:old.action_owner_03,0,4000), substr(:new.action_owner_03,0,4000) ); 
    end if;
    -- ACTION_OWNER_04 (default)
    if nvl(:old.action_owner_04, '0') != nvl(:new.action_owner_04,'0') then 
        insert into eba_proj_history (table_name, component_rowkey, component_id, column_name, old_value, new_value) values 
            ('STATUS_AIS', :new.row_key, :new.id, 'ACTION_OWNER_04', substr(:old.action_owner_04,0,4000), substr(:new.action_owner_04,0,4000) ); 
    end if;
    -- ACTION (default)
    if nvl(:old.action, '0') != nvl(:new.action,'0') then 
        insert into eba_proj_history (table_name, component_rowkey, component_id, column_name, old_value, new_value) values 
            ('STATUS_AIS', :new.row_key, :new.id, 'ACTION', substr(:old.action,0,4000), substr(:new.action,0,4000) ); 
    end if;
    -- ACTION_DESCRIPTION (default)
    if nvl(:old.action_description, '0') != nvl(:new.action_description,'0') then 
        insert into eba_proj_history (table_name, component_rowkey, component_id, column_name, old_value, new_value) values 
            ('STATUS_AIS', :new.row_key, :new.id, 'ACTION_DESCRIPTION', substr(:old.action_description,0,4000), substr(:new.action_description,0,4000) ); 
    end if;
    -- DUE_DATE (date/timestamp)
    if (:old.due_date is null and :new.due_date is not null) or 
        (:old.due_date is not null and :new.due_date is null) or 
        (:old.due_date != :new.due_date) then 
        insert into eba_proj_history (table_name, component_rowkey, component_id, column_name, old_value, new_value) values 
            ('STATUS_AIS', :new.row_key, :new.id, 'DUE_DATE', to_char(:old.due_date, 'DD-MON-YYYY'), to_char(:new.due_date, 'DD-MON-YYYY') );
    end if;
    -- ACTION_STATUS (default)
    if nvl(:old.action_status, '0') != nvl(:new.action_status,'0') then 
        insert into eba_proj_history (table_name, component_rowkey, component_id, column_name, old_value, new_value) values 
            ('STATUS_AIS', :new.row_key, :new.id, 'ACTION_STATUS', substr(:old.action_status,0,4000), substr(:new.action_status,0,4000) ); 
    end if;
    -- IS_DELIVERABLE_YN (default)
    if nvl(:old.is_deliverable_yn, '0') != nvl(:new.is_deliverable_yn,'0') then 
        insert into eba_proj_history (table_name, component_rowkey, component_id, column_name, old_value, new_value) values 
            ('STATUS_AIS', :new.row_key, :new.id, 'IS_DELIVERABLE_YN', substr(:old.is_deliverable_yn,0,4000), substr(:new.is_deliverable_yn,0,4000) ); 
    end if;
    -- TYPE_ID (foreign key)
    if nvl(:old.type_id,-999) != nvl(:new.type_id,-999) then
        ov := null; nv := null;
        for c1 in (select ai_type val from eba_proj_status_ais_types t where t.id = :old.type_id) loop
            ov := c1.val;
        end loop;
        for c1 in (select ai_type val from eba_proj_status_ais_types t where t.id = :new.type_id) loop
            nv := c1.val;
        end loop;
        insert into eba_proj_history (table_name, component_rowkey, component_id, column_name, old_value, new_value) values
            ('STATUS_AIS', :new.row_key, :new.id, 'TYPE_ID', ov, nv);
    end if;
end au_eba_proj_status_ais;
/

