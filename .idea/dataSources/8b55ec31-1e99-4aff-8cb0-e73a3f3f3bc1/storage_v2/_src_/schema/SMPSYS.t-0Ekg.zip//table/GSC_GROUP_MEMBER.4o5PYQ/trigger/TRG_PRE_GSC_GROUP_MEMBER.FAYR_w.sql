create trigger TRG_PRE_GSC_GROUP_MEMBER
  before insert
  on GSC_GROUP_MEMBER
  for each row
  begin
 SELECT SQ_GSC_GROUP_MEMBER.NEXTVAL INTO :NEW.GGM_ID FROM DUAL;
 end;

/

