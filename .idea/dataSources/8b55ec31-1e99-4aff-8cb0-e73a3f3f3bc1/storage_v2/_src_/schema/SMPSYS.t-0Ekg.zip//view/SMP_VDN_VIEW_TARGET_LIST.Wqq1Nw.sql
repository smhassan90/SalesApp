create view SMP_VDN_VIEW_TARGET_LIST as
  SELECT
    target.id,
    target.name,
    target.description,
    type.name,
    node.name,
    target.TNSAddr,
    target.UserData,
    node.agent,
    target.totalblackout
   FROM
    smp_vdn_target_list target,
    smp_vdn_node_list node,
    smp_vdn_target_type_defn type
   WHERE
    target.nodeid = node.id AND
    target.typeid = type.id
/

