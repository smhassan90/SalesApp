create trigger SAL_SO_BUSINESS_VOL_TRG
  before insert
  on SAL_SO_BUSINESS_VOL
  for each row
  begin
 SELECT SAL_SO_BUSINESS_VOL_SEQ.NEXTVAL INTO :NEW.SAL_ID FROM DUAL;
 end;
/

