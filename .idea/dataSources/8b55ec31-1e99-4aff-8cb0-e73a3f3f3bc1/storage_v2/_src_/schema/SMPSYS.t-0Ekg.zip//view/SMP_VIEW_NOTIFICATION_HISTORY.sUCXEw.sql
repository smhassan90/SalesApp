create view SMP_VIEW_NOTIFICATION_HISTORY as
  SELECT DECODE(type,1,'JOB',2,'EVENT','OTHER') "OBJECT_TYPE", nd.name "OBJECT_ID", nd.target "TARGET_NAME",
         nd.owner "ADMINISTRATOR_NAME", nd.method "METHOD", nd.time_stamp+nd.time_zone/86400000 "TIMESTAMP",
         nd.status "STATUS", nd.operation_status "OBJECT_STATUS"
  FROM   smp_vdm_notification_details nd
/

comment on table SMP_VIEW_NOTIFICATION_HISTORY
is 'List of all notifications send by this repository'
/

