create trigger BI_EPBM_TCAT_INFO_DETAIL
  before insert
  on EPBM_TCAT_INFO_DETAIL
  for each row
  BEGIN
    SELECT epbm_tcat_info_detail_seq.NEXTVAL INTO :NEW.edd_id
    FROM DUAL;
END;
/

