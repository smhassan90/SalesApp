create trigger OTL_CLS_DATE
  before update of OTL_FLAG
  on SAL_SO_OUTLET
  for each row
  DECLARE
BEGIN
  IF ( :OLD.OTL_FLAG <> :NEW.OTL_FLAG  ) THEN
       :NEW.OTL_CLS_DATE := SYSDATE;
  end if;
END;
/

