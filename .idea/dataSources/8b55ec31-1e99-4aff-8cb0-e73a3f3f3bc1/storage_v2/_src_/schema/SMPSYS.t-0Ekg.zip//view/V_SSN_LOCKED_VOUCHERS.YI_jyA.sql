create view V_SSN_LOCKED_VOUCHERS as
  select
SAC.Region,
District,
Tehsil,
 --GET_DISTRCT_TEHSIL(SUBSTR(SSD.BARCODE,0,9)),
 SSD.SSN_ID,
 SSD.BARCODE,
 SSD.ID as Client_ID,
 SSD.Name as Client_Name,
 SAC.CNIC,
 SUBSTR(SSD.BARCODE,0,9) PVD,
 SUBSTR(SSD.BARCODE,0,9) || '-' || SAC.account_title as Provider, -- call SP to get detailed column
 --SAC.account_title,
 TO_DATE(SSD.DATED||'-'||DECODE(SSD.MONTH,1,'January',
                 2,'Feb',
                 3,'Mar',
                 4,'Apr',
                 5,'May',
                 6,'Jun',
                 7,'Jul',
                 8,'Aug',
                 9,'Sep',
                 10,'Oct',
                 11,'Nov',
                 12,'Dec',SSD.MONTH)||'-'||SSD.YEAR) DATED,
                 get_ssn_ind_data('METHOD',SSD.METHOD) METHOD_GIVEN,
 SUBSTR(SSD.BARCODE,10,LENGTH(SSD.BARCODE)) as Voucher_No,
 SSD.LOCKED

 from SSN_DATA SSD
 join SSN_MPV_ATMCARD SAC on (SUBSTR(SSD.BARCODE,0,9) = SAC.Provider_code)
 --join VU_HIERARCHY VUH on (SUBSTR(SSD.BARCODE,0,9) = SAC.Provider_code)
 join (
       select district,tehsil,SSNMPV_Code from(
         select 
         B.DIST_CODE || ' - ' || B.DIST_NAME DISTRICT,
         B.TEHSIL_CODE || ' - ' || B.Tehsil_Name TEHSIL,
         A.MPV_Code SSNMPV_Code
         from
         vu_hierarchy           B,
         HIERARCHY_OTL_PRV_INFO A
         where A.OTL_TWN_CODE = B.TOWN_CODE
         --and A.MPV_CODE = 'Z42001096') --N06000044 - Rehana Jaben
         )
         group by district, tehsil, SSNMPV_Code) on (SUBSTR(SSD.BARCODE,0,9) = SSNMPV_Code)
 where SSD.LOCKED = 1
 order by SSD.SSN_ID
/

