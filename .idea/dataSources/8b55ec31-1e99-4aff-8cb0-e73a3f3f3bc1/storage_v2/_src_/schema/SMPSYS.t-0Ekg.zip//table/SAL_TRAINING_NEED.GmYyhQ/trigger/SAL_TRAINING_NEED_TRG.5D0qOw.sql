create trigger SAL_TRAINING_NEED_TRG
  before insert
  on SAL_TRAINING_NEED
  for each row
  begin
 SELECT SAL_TRAINING_NEED_SEQ.NEXTVAL INTO :NEW.TRN_ID FROM DUAL;
 end;
/

