create trigger TRG_PRE_INS_QAF_TM_QUESTION
  before insert
  on QAF_TM_QUESTION
  for each row
  begin
 SELECT SQ_QAF_TM_QUESTION.NEXTVAL INTO :NEW.QTQ_ID FROM DUAL;
 end;
/

