create view QA_TABULAR_IND_DATA as
  SELECT distinct initcap(stp.QST_DESCRIPTION) DESCRIPTION,
                    Q_TYPE TYPED,
                    STP.QST_CODE CODE
      FROM QA_SETUP_INDICATORS STP
    UNION ALL
    SELECT distinct initcap(STP.RSP_DESCRIPTION) DESCRIPTION,
                    R_TYPE TYPED,
                    STP.RSP_CODE CODE
      FROM QA_SETUP_INDICATORS STP
    UNION ALL
    SELECT distinct initcap(STP.RSP_CH_DESCRIPTION) DESCRIPTION,
                    C_TYPE TYPED,
                    STP.RSP_CH_CODE CODE
      FROM QA_SETUP_INDICATORS STP
/

