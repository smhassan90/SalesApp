create trigger EBA_SB_SURVEYS_BIU
  before insert or update
  on EBA_SB_SURVEYS
  for each row
  begin
    if :new.tags is not null then
        :new.tags := eba_sb_fw.tags_cleaner(:new.tags);
    end if;
    if inserting then
        if :new.id is null then
            :new.id := eba_sb.gen_id();
        end if;
        if :new.row_key is null then
            :new.row_key := eba_sb_fw.compress_int(eba_sb_seq.nextval);
        end if;
        :new.created_by := nvl(v('APP_USER'),user);
        :new.created := localtimestamp;
        :new.row_version_number := 1;
        if :new.state is null then
            :new.state := 'DESIGN';
        end if;
    elsif updating then
        :new.row_version_number := nvl(:old.row_version_number,1) + 1;
        -- valid state transitions
        -- DESIGN > TEST | ACTIVE
        -- TEST > DESIGN | ACTIVE
        -- ACTIVE > COMPLETE
        if not (:old.state = :new.state or
                :old.state = 'DESIGN' and (:new.state = 'TEST' or :new.state = 'ACTIVE') or
                :old.state = 'TEST' and(:new.state = 'DESIGN' or :new.state = 'ACTIVE') or
                :old.state = 'ACTIVE' and :new.state = 'COMPLETE') then
            raise_application_error (-20001,'Invalid state transition');
        end if;
    end if;
    :new.updated_by := nvl(v('APP_USER'),user);
    :new.updated := localtimestamp;
    eba_sb_fw.tag_sync(
        p_new_tags      => :new.tags,
        p_old_tags      => :old.tags,
        p_content_type  => 'SURVEYS',
        p_content_id    => :new.id );
end;
/

