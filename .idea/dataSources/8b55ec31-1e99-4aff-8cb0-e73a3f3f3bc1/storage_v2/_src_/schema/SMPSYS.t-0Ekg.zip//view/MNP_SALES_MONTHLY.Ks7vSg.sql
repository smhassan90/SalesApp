create view MNP_SALES_MONTHLY as
  select to_char(m.mss_date,'MON-YYYY'), t.dss_dit_code, round(sum(t.dss_qty))
from   sal_tm_sec_sales m, sal_td_sec_sales t
where  m.mss_num = t.dss_mss_num
and    mss_type in ('RS','WT')
group by to_char(m.mss_date,'MON-YYYY'), t.dss_dit_code
/

