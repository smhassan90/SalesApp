create trigger TRG_PINS_SAL_SD_PRV_SER
  before insert
  on SAL_SD_PRV_SER
  for each row
  begin
IF :NEW.DPS_ID IS NULL THEN
   :NEW.DPS_ID := :NEW.DPS_MPV_CODE||'-'||:NEW.DPS_SER_CODE;
END IF;
END;
/

