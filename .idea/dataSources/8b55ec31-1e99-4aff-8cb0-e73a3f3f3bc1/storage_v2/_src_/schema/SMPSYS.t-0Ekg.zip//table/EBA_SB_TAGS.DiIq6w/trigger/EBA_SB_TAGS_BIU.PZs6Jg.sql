create trigger EBA_SB_TAGS_BIU
  before insert or update
  on EBA_SB_TAGS
  for each row
  begin
    if inserting then
        if :new.id is null then
            :new.id := eba_sb.gen_id();
        end if;
        :new.created := localtimestamp;
        :new.created_by := nvl(v('APP_USER'),user);
    end if;
    :new.updated := localtimestamp;
    :new.updated_by := nvl(v('APP_USER'),USER);
end;
/

