create view SMP_VIEW_SESSION_NOTIF_MAP as
  SELECT
sessions.session_id, sessions.principal_name,
notification.sequence_num, notification.notification_id,
notification.notification_type, notification.subtype, 
notification.node_name,
notification.service_name, notification.service_type,
notification.time_stamp, notification.time_zone,
notification.verbose, notification.domain
FROM
smp_vdm_notification    notification,
smp_vdm_address         address,
smp_vds_sessions_table  sessions,
smp_vdm_session_notiftype_pair  notiftype_pair
WHERE
sessions.session_id = notiftype_pair.session_id
AND
notiftype_pair.notification_type = notification.notification_type
AND
notification.sequence_num > notiftype_pair.last_notif_sequence
AND
notification.sequence_num = address.sequence_num
AND
address.enhanced_notification = 0
AND
address.username = sessions.principal_name
/

