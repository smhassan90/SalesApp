create trigger SAL_DAILY_DATA_TRG_ED
  before insert or update
  on SAL_DAILY_DATA
  for each row
  BEGIN
  
  :NEW.ENTRY_DATE := TO_DATE(SYSDATE);
  
END;
/

