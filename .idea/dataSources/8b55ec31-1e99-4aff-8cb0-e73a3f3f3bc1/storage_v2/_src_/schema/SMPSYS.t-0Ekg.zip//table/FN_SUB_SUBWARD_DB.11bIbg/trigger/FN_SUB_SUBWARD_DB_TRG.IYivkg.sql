create trigger FN_SUB_SUBWARD_DB_TRG
  before insert
  on FN_SUB_SUBWARD_DB
  for each row
  BEGIN
    SELECT FN_SUB_SUBWARD_DB_SEQ.NEXTVAL INTO :NEW.FN_SUB_ID
    FROM DUAL;
END;
/

