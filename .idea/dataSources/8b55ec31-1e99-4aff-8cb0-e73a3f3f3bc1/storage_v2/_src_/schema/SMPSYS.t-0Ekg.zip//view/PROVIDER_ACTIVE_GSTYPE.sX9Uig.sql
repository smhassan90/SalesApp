create view PROVIDER_ACTIVE_GSTYPE as
  select po.dpo_mpv_code, substr(po.dpo_otl_code,1,5), pt.dpt_mpt_code,pt.dpt_cp_code
from   sal_sd_prv_outlet po, sal_sd_prv_training pt, sal_so_outlet so
where  pt.dpt_mpv_code = po.dpo_mpv_code
and    pt.dpt_cp_code = po.dpo_cp_code
and    so.otl_code = po.dpo_otl_code
and    so.otl_cp_code = po.dpo_cp_code
and    so.otl_flag = 'Y'
and    po.dpo_lft_date is null
and    pt.dpt_eff_date = (select max(prvt.dpt_eff_date) from sal_sd_prv_training prvt
			  where prvt.dpt_mpv_code = pt.dpt_mpv_code
			  and   prvt.dpt_cp_code = pt.dpt_cp_code)
/

