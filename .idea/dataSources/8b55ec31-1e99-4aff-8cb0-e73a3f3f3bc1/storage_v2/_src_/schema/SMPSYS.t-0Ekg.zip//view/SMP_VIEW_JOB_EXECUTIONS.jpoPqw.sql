create view SMP_VIEW_JOB_EXECUTIONS as
  SELECT j.job_id "JOB_ID", j.job_name "JOB_NAME", jpt.node_name "NODE_NAME", jl.target_name "TARGET_NAME", j.target_type "TARGET_TYPE",
         NVL(rtd.type_label,j.target_type) "TARGET_NLS_TYPE", j.owner "ADMINISTRATOR_NAME", jl.exec_num "EXEC_NUM", jl.time_stamp+jl.time_zone/86400000 "TIMESTAMP", jl.status "STATUS"
  FROM   SMP_VDJ_JOB_LOG jl, SMP_VDJ_JOB j, SMP_VDJ_JOB_PER_TARGET jpt, SMP_VBO_REPORTS_TYPE_DEFN rtd
  WHERE  j.job_id = jl.job_id
    AND  j.job_id = jpt.job_id
    AND  j.is_lib = 0
    AND  jl.exec_num != 0
    AND  jl.target_name = jpt.target_name
    AND  jl.status =
         (SELECT MAX(jl2.status)
          FROM   SMP_VDJ_JOB_LOG jl2
          WHERE  jl2.job_id = jl.job_id
            AND  jl2.target_name = jl.target_name
            AND  jl.exec_num = jl2.exec_num
         )
    AND  UPPER(j.target_type) = rtd.type (+)
/

comment on table SMP_VIEW_JOB_EXECUTIONS
is 'Last recorded status of each execution of a job'
/

