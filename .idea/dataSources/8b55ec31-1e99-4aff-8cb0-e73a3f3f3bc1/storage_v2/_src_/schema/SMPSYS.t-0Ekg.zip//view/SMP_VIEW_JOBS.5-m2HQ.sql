create view SMP_VIEW_JOBS as
  SELECT j.job_id "JOB_ID", j.job_name "JOB_NAME", j.owner "ADMINISTRATOR_NAME",
         j.description "DESCRIPTION", j.target_type "TARGET_TYPE", NVL(rtd.type_label,j.target_type) "TARGET_NLS_TYPE",
         j.is_fixit "FIXIT_JOB", j.is_lib "LIBRARY_JOB", DECODE(INSTR(j.schedule,'ImmediateSchedule'),0,1,0) "INTERVAL_JOB",
         j.last_mod_by "MODIFIED_BY", j.last_mod_time+j.time_zone/86400000 "MODIFIED_DATE"
  FROM   SMP_VDJ_JOB j, SMP_VBO_REPORTS_TYPE_DEFN rtd
  WHERE  UPPER(j.target_type) = rtd.type (+)
/

comment on table SMP_VIEW_JOBS
is 'List of all jobs known in the repository'
/

