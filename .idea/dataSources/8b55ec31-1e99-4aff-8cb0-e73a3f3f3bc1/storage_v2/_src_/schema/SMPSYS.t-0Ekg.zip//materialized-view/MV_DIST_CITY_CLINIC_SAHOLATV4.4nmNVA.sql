create materialized view MV_DIST_CITY_CLINIC_SAHOLATV4
refresh force on demand
  as
    Select DECODE(MAR_IPC_GS,'Y','GS','GL') CSFOR,
       MAR_PRD_FM CSDATE,    
       MAR_PRD_TO CS_END_DATE,    
       MAR_REG_CODE REGION, 
       GET_LEVEL_NAME('01',MAR_REG_CODE) REGION_NAME, 
       MAR_ZONE_CODE ZONE,
       GET_LEVEL_NAME('01',MAR_ZONE_CODE) ZONE_NAME, 
       MAR_BR_CODE BRANCH,
       GET_LEVEL_NAME('01',MAR_BR_CODE||'0') BRANCH_NAME, 
       MAR_TOWN_CODE TOWN,
       GET_LEVEL_NAME('01',MAR_TOWN_CODE) TOWN_NAME, 
       MAR_CITY_CODE CITY,
       GET_LEVEL_NAME('01',MAR_CITY_CODE) CITY_NAME, 
       MAR_DIST_CODE DISTRICT,
       GET_LEVEL_NAME('01',MAR_DIST_CODE) DISTRICT_NAME, 
       MAR_MLC_CODE CS_CONDUCTED,
       SUBSTR(GET_LEVEL_NAME('01',MAR_MLC_CODE),1,50) CS_CONDUCTED_NAME,
       MAR_CS_SUPERVISED_BY SUPERVISED_BY,
       GET_LEVEL_NAME('01',MAR_CS_SUPERVISED_BY) SUPERVISED_BY_NAME,
       DECODE(MAR_CS_REASON, 'GSN','GS New Trained',
                             'GSR','GS Regular',
                             'GSI','GS Inactive',
                             'GLS','GL Silver',
                             'GLG','GL Gold',
                             'GSA','GS Active',
                             'GLN','GL New',
                             'GLC','GL Conversion',
                             'GSP','RSPN',
                             'GSU','MSU','') CS_REASON,
       DECODE(NVL(OTL_LOC_TYPE,'NA'),'R','RURAL','U','URBAN','NA','INFO MISSING') OTLLOCATION,
       MAR_OTL_CODE OTL_CODE, 
       OTL_DESC OTL_NAME,
       MAR_MPV_CODE MPV_CODE, 
       GET_MPV_OTL_DESC(MAR_MPV_CODE,'01','P','W') MPV_NAME,
       MAR_PRJ_CODE PROJECT,
       DAR_MAR_ID,
       sum(decode(ipcd.dar_mac_id,112,ipcd.dar_ac_val)) Women_New_to_Clinic,
       sum(decode(ipcd.dar_mac_id,113,ipcd.dar_ac_val)) CS_Client_Women,
       sum(decode(ipcd.dar_mac_id,114,NVL(ipcd.dar_ac_val,0))) CS_Client_Child,
       sum(decode(ipcd.dar_mac_id,113,NVL(ipcd.dar_ac_val,0)))+
       sum(decode(ipcd.dar_mac_id,114,ipcd.dar_ac_val)) TOTAL_CS_Clients,
       sum(decode(ipcd.dar_mac_id,115,ipcd.dar_ac_val)) Cur_FP_Client,
       sum(decode(ipcd.dar_mac_id,116,ipcd.dar_ac_val)) Cur_FP_Condums,
       sum(decode(ipcd.dar_mac_id,117,ipcd.dar_ac_val)) Cur_FP_Pills,
       sum(decode(ipcd.dar_mac_id,118,ipcd.dar_ac_val)) Cur_FP_Inj,
       sum(decode(ipcd.dar_mac_id,119,ipcd.dar_ac_val)) Cur_FP_IUD,
       sum(decode(ipcd.dar_mac_id,120,ipcd.dar_ac_val)) Cur_FP_VSC_Performed,
       sum(decode(ipcd.dar_mac_id,121,ipcd.dar_ac_val)) Cur_FP_VSC_Refered,
       sum(decode(ipcd.dar_mac_id,122,ipcd.dar_ac_val)) Cur_FP_Counseling,
       sum(decode(ipcd.dar_mac_id,123,ipcd.dar_ac_val)) New_FP_Client,
       sum(decode(ipcd.dar_mac_id,124,ipcd.dar_ac_val)) New_FP_Condums,
       sum(decode(ipcd.dar_mac_id,125,ipcd.dar_ac_val)) New_FP_Pills,
       sum(decode(ipcd.dar_mac_id,126,ipcd.dar_ac_val)) New_FP_Inj,
       sum(decode(ipcd.dar_mac_id,127,ipcd.dar_ac_val)) New_FP_IUD,
       sum(decode(ipcd.dar_mac_id,128,ipcd.dar_ac_val)) New_FP_VSC_performed,
       sum(decode(ipcd.dar_mac_id,129,ipcd.dar_ac_val)) New_FP_VSC_refered,
       sum(decode(ipcd.dar_mac_id,130,ipcd.dar_ac_val)) New_FP_counseling,
       sum(decode(ipcd.dar_mac_id,131,ipcd.dar_ac_val)) Other_rh_ser_anc,
       sum(decode(ipcd.dar_mac_id,132,ipcd.dar_ac_val)) Other_rh_ser_pnc,
       sum(decode(ipcd.dar_mac_id,133,ipcd.dar_ac_val)) Other_rh_ser_neonates,
       sum(decode(ipcd.dar_mac_id,134,ipcd.dar_ac_val)) Other_rh_ser_children,
       sum(decode(ipcd.dar_mac_id,135,ipcd.dar_ac_val)) Other_rh_ser_sti,
       sum(decode(ipcd.dar_mac_id,136,ipcd.dar_ac_val)) Other_rh_ser_pacc,
       sum(decode(ipcd.dar_mac_id,137,ipcd.dar_ac_val)) VSC_medicine_given_CLIENTS,
       sum(decode(ipcd.dar_mac_id,138,ipcd.dar_ac_val)) FP_Product_Cons_touch,
       sum(decode(ipcd.dar_mac_id,139,ipcd.dar_ac_val)) FP_Product_Cons_sathi,
       sum(decode(ipcd.dar_mac_id,140,ipcd.dar_ac_val)) FP_Product_Cons_nova,
       sum(decode(ipcd.dar_mac_id,141,ipcd.dar_ac_val)) FP_Product_Cons_novadol,
       sum(decode(ipcd.dar_mac_id,142,ipcd.dar_ac_val)) FP_Product_Cons_femiject,
       sum(decode(ipcd.dar_mac_id,143,ipcd.dar_ac_val)) FP_Product_Cons_novaject,
       sum(decode(ipcd.dar_mac_id,144,ipcd.dar_ac_val)) FP_Product_Cons_megistron,
       sum(decode(ipcd.dar_mac_id,145,ipcd.dar_ac_val)) FP_Product_Cons_multiload,
       sum(decode(ipcd.dar_mac_id,146,ipcd.dar_ac_val)) FP_Product_Cons_safeload
from ipc_tm_ar ipcm, ipc_td_ar ipcd, SAL_SO_OUTLET
Where ipcd.dar_mar_id   = ipcm.mar_id
  and ipcm.mar_otl_code = Otl_code
  and ipcm.mar_cp_code  = Otl_cp_code
  and ipcm.mar_tr_type  = 'CS4'
  and ipcd.dar_ac_val is not null
---  and trunc(ipcm.mar_prd_fm) 
GROUP BY MAR_IPC_GS, MAR_PRD_FM, MAR_PRD_TO, MAR_REG_CODE, 
         MAR_ZONE_CODE, MAR_BR_CODE, MAR_TOWN_CODE, MAR_CITY_CODE,
         MAR_DIST_CODE, MAR_MLC_CODE, MAR_CS_SUPERVISED_BY,
         MAR_CS_REASON, MAR_TOWN_CODE, OTL_LOC_TYPE,
         MAR_OTL_CODE, OTL_DESC, MAR_MPV_CODE, MAR_PRJ_CODE, DAR_MAR_ID












/

