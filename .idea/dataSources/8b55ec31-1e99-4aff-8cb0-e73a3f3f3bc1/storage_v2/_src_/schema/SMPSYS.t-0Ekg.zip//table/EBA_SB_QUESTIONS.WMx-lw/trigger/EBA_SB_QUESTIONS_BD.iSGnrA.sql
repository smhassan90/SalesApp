create trigger EBA_SB_QUESTIONS_BD
  before delete
  on EBA_SB_QUESTIONS
  for each row
  begin
    eba_sb_fw.tag_sync(
        p_new_tags      => null,
        p_old_tags      => :old.tags,
        p_content_type  => 'QUESTIIONS',
        p_content_id    => :old.id );
end;
/

