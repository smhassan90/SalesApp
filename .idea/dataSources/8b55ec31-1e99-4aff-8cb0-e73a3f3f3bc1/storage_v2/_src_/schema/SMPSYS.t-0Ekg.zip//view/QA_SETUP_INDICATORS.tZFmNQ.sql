create view QA_SETUP_INDICATORS as
  select QST_ID,
       QST_CODE,
       'Q' Q_Type,
       QST_DESCRIPTION,
       QST_IS_ACTIVE,
       QST_EFFECTIVE_DATE,
       RSP_ID,
       RSP_CODE,
       'R' R_Type,
       RSP_DESCRIPTION,
       RSP_IS_ACTIVE,
       RSP_QST_CODE,
       RSP_EFFECTIVE_DATE,
       RSP_CH_ID,
       RSP_CH_CODE,
       'C' C_Type,
       RSP_CH_DESCRIPTION,
       RSP_CH_IS_ACTIVE,
       RSP_CH_RSP_CODE,
       RSP_CH_EFFECTIVE_DATE
  from qa_qst_info_st qst, qa_rsp_info_st rsp, qa_rsp_child_info_st ch
 where rsp.rsp_qst_code(+) = qst.qst_code
   and rsp.rsp_code = ch.rsp_ch_rsp_code(+)
 order by rsp.rsp_code, ch.rsp_ch_code
/

