create trigger BI_CATEGORIES
  before insert
  on CATEGORIES
  for each row
  begin  
   if inserting then 
      if :NEW."CAT_ID" is null then 
         select INDICATORS_SEQ.nextval into :NEW."CAT_ID" from dual; 
      end if; 
   end if; 
end;
/

