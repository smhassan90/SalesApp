create trigger TRG_PRE_INS_SAL_TD_SALES
  before insert
  on SAL_TD_SALES
  for each row
  begin
IF :NEW.DSL_ID IS NULL THEN
   :NEW.DSL_ID := :NEW.DSL_MSL_NUM||'-'||LPAD(:NEW.DSL_SEQ_NUM,3,000);
END IF;
end;
/

