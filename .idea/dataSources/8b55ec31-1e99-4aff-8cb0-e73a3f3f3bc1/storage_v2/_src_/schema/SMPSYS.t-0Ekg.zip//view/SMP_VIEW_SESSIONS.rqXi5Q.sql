create view SMP_VIEW_SESSIONS as
  SELECT st.principal_name "ADMINISTRATOR_NAME", st.oms "OMS_MACHINE",
         st.login_time "LOGIN_TIME"
  FROM   smp_vds_sessions_table st
  WHERE  st.principal_type = 'OEM_USER'
/

comment on table SMP_VIEW_SESSIONS
is 'List of all administrators currently logged on to the repository'
/

