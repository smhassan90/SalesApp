create trigger PHOTOS_TRGR
  before insert
  on PHOTOS
  for each row
  BEGIN
    SELECT mass_scimg_upload_seq.NEXTVAL INTO :NEW.PHOTO_ID
    FROM DUAL;
END;
/

