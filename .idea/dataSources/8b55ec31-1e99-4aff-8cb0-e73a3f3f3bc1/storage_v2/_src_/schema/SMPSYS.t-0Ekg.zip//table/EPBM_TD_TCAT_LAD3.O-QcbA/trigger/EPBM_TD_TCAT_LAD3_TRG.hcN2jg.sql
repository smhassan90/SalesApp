create trigger EPBM_TD_TCAT_LAD3_TRG
  before insert
  on EPBM_TD_TCAT_LAD3
  for each row
  begin
  SELECT EPBM_TD_TCAT_LAD3_SEQ.NEXTVAL INTO :NEW.ETD_ID FROM DUAL;
end;
/

