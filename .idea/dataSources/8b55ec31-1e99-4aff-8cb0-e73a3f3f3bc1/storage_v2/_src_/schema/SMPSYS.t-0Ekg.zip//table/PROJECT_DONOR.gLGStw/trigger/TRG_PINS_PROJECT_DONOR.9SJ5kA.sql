create trigger TRG_PINS_PROJECT_DONOR
  before insert
  on PROJECT_DONOR
  for each row
  declare
  V_CODE number(10);
begin
SELECT SQ_prg_dnr_dist.NEXTVAL INTO V_CODE FROM DUAL;
  :NEW.PDD_id := lpad(V_CODE,8,0);
end;
/

