create trigger TRG_PRE_INS_MCQUIZ_TD_POSITION
  before insert
  on MCQUIZ_TD_POSITION
  for each row
  begin
 SELECT SQ_MCQUIZ_TD_POSITION.NEXTVAL INTO :NEW.MTP_ID FROM DUAL;
 end;
/

