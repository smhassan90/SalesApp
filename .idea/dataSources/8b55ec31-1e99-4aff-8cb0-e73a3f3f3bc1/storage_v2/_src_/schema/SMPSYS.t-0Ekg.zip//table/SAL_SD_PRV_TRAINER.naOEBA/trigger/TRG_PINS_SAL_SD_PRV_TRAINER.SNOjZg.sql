create trigger TRG_PINS_SAL_SD_PRV_TRAINER
  before insert
  on SAL_SD_PRV_TRAINER
  for each row
  begin
IF :NEW.DTR_ID IS NULL THEN
   :NEW.DTR_ID := :NEW.DTR_MPV_CODE||'-'||:NEW.DTR_TRN_CODE||'-'||:NEW.DTR_EFF_DATE;
END IF;
END;
/

