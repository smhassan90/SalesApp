create trigger TRG_PRE_INS_SAL_TD_CT
  before insert
  on SAL_TD_CT
  for each row
  begin
IF :NEW.DCT_ID IS NULL THEN
   :NEW.DCT_ID := :NEW.DCT_MCT_NUM||'-'||:NEW.DCT_SEQ_NUM;
END IF;
END;
/

