create view SMP_VIEW_ADMIN_CREDENTIALS as
  SELECT u.user_name "ADMINISTRATOR_NAME", pc.service_name "SERVICE_NAME", pc.service_type "SERVICE_TYPE"
  FROM   smp_vdv_user u, smp_vdv_preferred_credentials pc
  WHERE  u.user_id = pc.user_id
/

comment on table SMP_VIEW_ADMIN_CREDENTIALS
is 'Credentials defined for services per administrator'
/

