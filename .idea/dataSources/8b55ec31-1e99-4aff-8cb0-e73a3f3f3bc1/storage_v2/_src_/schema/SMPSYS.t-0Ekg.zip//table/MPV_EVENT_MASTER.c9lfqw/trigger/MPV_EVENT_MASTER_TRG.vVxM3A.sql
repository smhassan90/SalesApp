create trigger MPV_EVENT_MASTER_TRG
  before insert
  on MPV_EVENT_MASTER
  for each row
  begin
  SELECT MPV_EVENT_MASTER_SEQ.NEXTVAL INTO :NEW.EV_ID FROM DUAL;
end;
/

