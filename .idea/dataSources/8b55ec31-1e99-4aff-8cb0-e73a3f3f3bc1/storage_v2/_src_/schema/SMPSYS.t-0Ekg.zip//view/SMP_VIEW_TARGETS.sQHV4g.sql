create view SMP_VIEW_TARGETS as
  SELECT tl.name "TARGET_NAME", ttd.name "TARGET_TYPE", NVL(rtd.type_label,ttd.name) "TARGET_NLS_TYPE", nl.name "NODE_NAME", tl.tnsaddr "USERDATA", NVL(es.sev,0) "SEVERITY"
  FROM   SMP_VDN_TARGET_LIST tl, SMP_VDN_TARGET_TYPE_DEFN ttd, SMP_VDN_NODE_LIST nl, SMP_VBO_REPORTS_TYPE_DEFN rtd,
         (SELECT ts.target_name, td.id, (MAX(ts.node_state)-302)*100+MAX(ts.agent_severity) sev FROM SMP_VDE_EVENT_TARGET_STATE ts, SMP_VDE_EVENT_TARGET_INFO ti, SMP_VDN_TARGET_TYPE_DEFN td WHERE ts.target_type = td.name AND ts.event_id = ti.event_id AND ts.target_name = ti.target_name AND ti.agent_status = 205 GROUP BY ts.target_name, td.id) es
  WHERE  tl.typeid = ttd.id
    AND  tl.nodeid = nl.id
    AND  UPPER(ttd.name) = rtd.type (+)
    AND  tl.withagent = 1
    AND  tl.name = es.target_name (+)
    AND  tl.typeid = es.id (+)
/

comment on table SMP_VIEW_TARGETS
is 'List of all potential targets for jobs and events'
/

