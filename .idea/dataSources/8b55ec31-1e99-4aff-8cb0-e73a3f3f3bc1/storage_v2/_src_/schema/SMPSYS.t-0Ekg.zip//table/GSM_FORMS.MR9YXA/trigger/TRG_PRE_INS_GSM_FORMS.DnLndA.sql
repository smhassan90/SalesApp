create trigger TRG_PRE_INS_GSM_FORMS
  before insert
  on GSM_FORMS
  for each row
  begin
 SELECT SQ_GSM_FORMS.NEXTVAL INTO :NEW.GF_ID FROM DUAL;
 end;
/

