create trigger TRG_PRE_INS_ITEM_AC
  before insert
  on ITEM_AVAILABILITY_CHECK
  for each row
  declare
  V_mac_CODE number(12);
begin
SELECT SQ_Item_avail_check.NEXTVAL INTO V_mac_CODE FROM DUAL;
:NEW.mac_id := lpad(V_mac_CODE,10,0);
end;
/

