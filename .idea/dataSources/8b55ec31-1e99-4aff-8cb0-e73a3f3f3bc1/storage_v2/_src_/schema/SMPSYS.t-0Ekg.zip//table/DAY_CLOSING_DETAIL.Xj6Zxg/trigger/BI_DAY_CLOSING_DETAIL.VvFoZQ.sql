create trigger BI_DAY_CLOSING_DETAIL
  before insert
  on DAY_CLOSING_DETAIL
  for each row
  begin
    select SQ_DAY_CLOSING_DETAIL.nextval INTO :new.DCD_ID
    from dual;
end;
/

