create trigger BI_FR_OPD_SLIP
  before insert
  on FR_OPD_SLIP
  for each row
  begin
SELECT SQ_FR_OPD_SLIP.NEXTVAL INTO :NEW.OPS_ID FROM DUAL;
end;
/

