create view GSM_HS_DT03_VU as
  select NVL(G1.RC_STAFF_CODE, G2.RC_STAFF_CODE) STAFF,
       get_level_name('01', NVL(G1.RC_STAFF_CODE, G2.RC_STAFF_CODE)) STAFF_NAME,
       NVL(G1.RC_DATE, G2.RC_DATE) VISIT_DATE,
       get_location_desc(get_staff_loc(NVL(G1.RC_STAFF_CODE,
                                           G2.RC_STAFF_CODE)),
                         '01') LOC,
       NVL(G1.RC_SMS_TEXT, G2.RC_SMS_TEXT) SMS_TEXT,
       NVL(get_od_desc(G1.RC_SMS_TEXT),get_od_desc(G2.RC_SMS_TEXT)) ACT_TYPE,
       NVL(G1.MSISDN_FROM, G2.MSISDN_FROM) MSISDN,
       NVL(G1.RC_STATUS, G2.RC_STATUS) STATUS,
       NVL(G1.RC_REMARKS, G2.RC_REMARKS) REMARKS,

       g1.rc_date rc1,
       g2.rc_date rc2,
       extract(hour from
               to_timestamp(g2.rc_date) - to_timestamp(g1.rc_date)) hr,
       extract(minute from
               to_timestamp(g2.rc_date) - to_timestamp(g1.rc_date)) mn,
       extract(second from
               to_timestamp(g2.rc_date) - to_timestamp(g1.rc_date)) sec
  from gsm_posted_hs_dt03 d
  left outer join gsm_recieving_data g1
    on d.dt_rc_id = g1.rc_id
  left outer join gsm_recieving_data g2
    on d.dt_rc_id_2 = g2.rc_id
/

