create trigger BI_EBA_PROJ_STATUS
  before insert or update
  on EBA_PROJ_STATUS
  for each row
  begin
    if :new.tags is not null then
        :new.tags := eba_proj_fw.tags_cleaner(:new.tags);
    end if;
   if :new."ID" is null then
     select to_number(sys_guid(),'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX') into :new.id from dual;
   end if;
   if inserting then
       :new.created := localtimestamp;
       :new.created_by := nvl(wwv_flow.g_user,user);
       :new.row_version_number := 1;
   elsif updating then
       :new.row_version_number := nvl(:old.row_version_number,1) + 1;
   end if;
   if inserting or updating then
       :new.updated := localtimestamp;
       :new.updated_by := nvl(wwv_flow.g_user,user);
   end if;
   if :new.row_key is null then
       select eba_proj_fw.COMPRESS_INT(eba_proj_seq.nextval) into :new.row_key from dual;
   end if;
   :new.project_owner := lower(:new.project_owner);
   eba_proj_fw.tag_sync(
       p_new_tags      => :new.tags,
       p_old_tags      => :old.tags,
       p_content_type  => 'STATUS',
       p_content_id    => :new.id );
  -- shuffle
   for i in 1..5 loop
   if :new.PROJECT_OWNER is null and :new.PROJECT_OWNER2 is not null then
      :new.project_owner := :new.project_owner2;
      :new.project_owner2 := null;
   end if;
   if :new.PROJECT_OWNER2 is null and :new.PROJECT_OWNER3 is not null then
      :new.project_owner2 := :new.project_owner3;
      :new.project_owner3 := null;
   end if;
   if :new.PROJECT_OWNER3 is null and :new.PROJECT_OWNER4 is not null then
      :new.project_owner3 := :new.project_owner4;
      :new.project_owner4 := null;
   end if;
   if :new.PROJECT_OWNER4 is null and :new.PROJECT_OWNER5 is not null then
      :new.project_owner4 := :new.project_owner5;
      :new.project_owner5 := null;
   end if;
   if :new.PROJECT_OWNER5 is null and :new.PROJECT_OWNER6 is not null then
      :new.project_owner5 := :new.project_owner6;
      :new.project_owner6 := null;
   end if;
   if :new.PROJECT_OWNER6 is null and :new.PROJECT_OWNER7 is not null then
      :new.project_owner6 := :new.project_owner7;
      :new.project_owner7 := null;
   end if;
   if :new.PROJECT_OWNER7 is null and :new.PROJECT_OWNER8 is not null then
      :new.project_owner7 := :new.project_owner8;
      :new.project_owner8 := null;
   end if;
   if :new.PROJECT_OWNER8 is null and :new.PROJECT_OWNER9 is not null then
      :new.project_owner8 := :new.project_owner9;
      :new.project_owner9 := null;
   end if;
   if :new.PROJECT_OWNER9 is null and :new.PROJECT_OWNER10 is not null then
      :new.project_owner9 := :new.project_owner10;
      :new.project_owner10 := null;
   end if;
   if :new.PROJECT_OWNER10 is null and :new.PROJECT_OWNER11 is not null then
      :new.project_owner10 := :new.project_owner11;
      :new.project_owner11 := null;
   end if;
   if :new.PROJECT_OWNER11 is null and :new.PROJECT_OWNER12 is not null then
      :new.project_owner11 := :new.project_owner12;
      :new.project_owner12 := null;
   end if;
   end loop;
end;
/

