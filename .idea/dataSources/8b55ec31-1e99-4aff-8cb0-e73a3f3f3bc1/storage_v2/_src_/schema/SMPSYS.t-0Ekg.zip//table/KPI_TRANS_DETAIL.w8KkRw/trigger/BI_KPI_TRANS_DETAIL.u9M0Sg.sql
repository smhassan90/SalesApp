create trigger BI_KPI_TRANS_DETAIL
  before insert
  on KPI_TRANS_DETAIL
  for each row
  begin
    select "KPI_TRANS_DETAIL_SEQ".nextval into :NEW.KTD_ID from dual;
end;
/

