create trigger TRG_PRE_INS_INV_TD_PORDER
  before insert
  on INV_TD_PORDER
  for each row
  begin
IF :NEW.DPO_ID IS NULL THEN
   :NEW.DPO_ID := :NEW.DPO_MPO_NUM||'-'||LPAD(:NEW.DPO_SEQ_NUM,3,000);
END IF;
end;
/

