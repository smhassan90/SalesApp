create trigger SFM_PHARMA_VISITP_TRANSD
  before insert or update
  on SFM_PHARMA_VISIT_PRODUCTS
  for each row
  BEGIN
  
  :NEW.TRANSACTION_DATE := TO_DATE(SYSDATE);
  
END;
/

