create trigger BI_CLASSROOM_TRAINING_MASTER
  before insert
  on CLASSROOM_TRAINING_MASTER
  for each row
  begin
  if :new.CRT_ID is null then
    select SQ_CLASSROOM_TRAINING_MASTER.nextval INTO :new.CRT_ID
    from dual;
  end if;
end;
/

