create view DS_INV_MONTHLY_TEST as
  select to_char(m.msl_date,'YYYY-MM'), t.dsl_dit_code, 'C', sum(t.dsl_qty)
from   sal_tm_sales m , sal_td_sales t
where  m.msl_num = t.dsl_msl_num
and    m.msl_type = 'DS'
and    m.msl_status = 'P'
group by to_char(m.msl_date,'YYYY-MM'), t.dsl_dit_code
union
select to_char(m.msl_date,'YYYY-MM'), t.dsl_dit_bns, 'B', sum(t.dsl_bns_qty)
from   sal_tm_sales m , sal_td_sales t
where  m.msl_num = t.dsl_msl_num
and    m.msl_type = 'DS'
and    m.msl_status = 'P'
group by to_char(m.msl_date,'YYYY-MM'), t.dsl_dit_bns
union
select to_char(m.msl_date,'YYYY-MM'), t.dsl_dit_code, 'I', sum(t.dsl_qty)
from   sal_tm_sales m , sal_td_sales t
where  m.msl_num = t.dsl_msl_num
and    m.msl_type = 'SI'
group by to_char(m.msl_date,'YYYY-MM'), t.dsl_dit_code
/

