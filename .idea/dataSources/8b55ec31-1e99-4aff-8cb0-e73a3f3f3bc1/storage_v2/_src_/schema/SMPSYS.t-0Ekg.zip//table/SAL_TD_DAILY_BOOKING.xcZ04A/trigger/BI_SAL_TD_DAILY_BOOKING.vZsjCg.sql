create trigger BI_SAL_TD_DAILY_BOOKING
  before insert
  on SAL_TD_DAILY_BOOKING
  for each row
  BEGIN
    SELECT sal_td_daily_booking_seq.NEXTVAL INTO :NEW.sdt_id
    FROM DUAL;
END;
/

