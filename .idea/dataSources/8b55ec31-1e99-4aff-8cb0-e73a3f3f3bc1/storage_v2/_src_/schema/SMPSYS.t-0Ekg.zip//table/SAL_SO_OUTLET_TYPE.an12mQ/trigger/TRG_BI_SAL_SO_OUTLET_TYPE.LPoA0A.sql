create trigger TRG_BI_SAL_SO_OUTLET_TYPE
  before insert
  on SAL_SO_OUTLET_TYPE
  for each row
  begin
  SELECT SQ_SAL_SO_OUTLET_TYPE.NEXTVAL INTO :NEW.OTY_ID FROM DUAL;
end;
/

