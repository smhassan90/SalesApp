create trigger BI_IPC_TD_SP
  before insert
  on IPC_TD_STAFF_PRESENCE
  for each row
  begin
    if :new.dsp_id is null then 
      select IPC_TD_SP_SEQ.nextval INTO :new.DSP_ID
      from dual;
    end if;
end;
/

