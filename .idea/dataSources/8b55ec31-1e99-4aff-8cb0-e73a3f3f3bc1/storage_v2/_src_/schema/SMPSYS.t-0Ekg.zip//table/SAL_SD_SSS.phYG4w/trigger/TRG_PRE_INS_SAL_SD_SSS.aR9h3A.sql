create trigger TRG_PRE_INS_SAL_SD_SSS
  before insert
  on SAL_SD_SSS
  for each row
  begin
SELECT SQ_SAL_SD_SSS.NEXTVAL INTO :NEW.DSS_CODE FROM DUAL;
end;
/

