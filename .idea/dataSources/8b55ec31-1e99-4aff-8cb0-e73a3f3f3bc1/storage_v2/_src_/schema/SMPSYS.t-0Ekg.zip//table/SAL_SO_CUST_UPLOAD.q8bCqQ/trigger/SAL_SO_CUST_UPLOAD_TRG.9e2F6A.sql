create trigger SAL_SO_CUST_UPLOAD_TRG
  before insert
  on SAL_SO_CUST_UPLOAD
  for each row
  begin
  SELECT SAL_SO_CUST_UPLOAD_SEQ.NEXTVAL INTO :NEW.UP_NUM FROM DUAL;
END;
/

