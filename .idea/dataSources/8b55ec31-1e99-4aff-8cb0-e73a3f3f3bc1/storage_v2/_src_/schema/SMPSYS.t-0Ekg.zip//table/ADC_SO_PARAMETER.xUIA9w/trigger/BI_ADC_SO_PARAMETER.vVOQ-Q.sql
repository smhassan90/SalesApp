create trigger BI_ADC_SO_PARAMETER
  before insert
  on ADC_SO_PARAMETER
  for each row
  begin
 SELECT SQ_ADC_SO_PARAMTERS.NEXTVAL INTO :NEW.ASP_ID FROM DUAL;
 end;
/

