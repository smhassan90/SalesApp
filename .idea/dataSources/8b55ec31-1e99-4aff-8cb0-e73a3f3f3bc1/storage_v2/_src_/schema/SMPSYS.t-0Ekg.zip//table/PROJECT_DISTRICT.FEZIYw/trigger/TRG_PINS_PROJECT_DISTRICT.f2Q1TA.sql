create trigger TRG_PINS_PROJECT_DISTRICT
  before insert
  on PROJECT_DISTRICT
  for each row
  declare
  V_CODE number(10);
begin
SELECT SQ_prg_dist.NEXTVAL INTO V_CODE FROM DUAL;
  :NEW.PDT_id := lpad(V_CODE,8,0);
end;
/

