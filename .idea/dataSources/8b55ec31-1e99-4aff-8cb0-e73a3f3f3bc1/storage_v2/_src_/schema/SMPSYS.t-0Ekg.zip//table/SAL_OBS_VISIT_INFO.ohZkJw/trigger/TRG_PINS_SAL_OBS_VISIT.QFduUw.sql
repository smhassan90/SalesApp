create trigger TRG_PINS_SAL_OBS_VISIT
  before insert
  on SAL_OBS_VISIT_INFO
  for each row
  begin
  SELECT SQ_SAL_OBS_VISIT_INFO.NEXTVAL INTO :NEW.OBS_VI_CODE FROM DUAL;
end;
/

