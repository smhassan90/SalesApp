create view VW_QA_QUSTION_AND_RESPONSE as
  select qst.qst_code,
       qst.qst_description,
       rsp.rsp_code,
       rsp.rsp_description,
       ch.rsp_ch_code,
       ch.rsp_ch_description
  from qa_qst_info_st qst, qa_rsp_info_st rsp, qa_rsp_child_info_st ch
 where rsp.rsp_qst_code(+) = qst.qst_code
   and rsp.rsp_code = ch.rsp_ch_rsp_code(+)
 order by rsp.rsp_code
/

