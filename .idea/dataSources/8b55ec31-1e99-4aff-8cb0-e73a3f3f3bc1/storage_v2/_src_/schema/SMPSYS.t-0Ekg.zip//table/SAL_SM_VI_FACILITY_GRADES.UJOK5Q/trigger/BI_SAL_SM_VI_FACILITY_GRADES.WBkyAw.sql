create trigger BI_SAL_SM_VI_FACILITY_GRADES
  before insert
  on SAL_SM_VI_FACILITY_GRADES
  for each row
  begin
    select SQ_SAL_SM_VI_FACILITY_GRADES.nextval INTO :new.MFG_ID
    from dual;
end;
/

