create view OUTLET_OPEN_GSTYPE_DATE as
  select po.dpo_otl_code,decode(max(tr.mpt_rank),'60','GS PLUS','59','FHC','55','MOBILE UNIT',
       '50','GS1','45','ASS','40','GS2','30','GS3','20','GS4','NGS'),
 so.otl_reg_date,so.otl_add1,so.otl_add2,so.otl_desc
from   sal_sd_prv_training pt, sal_sd_prv_outlet po, sal_sm_prv_type tr,
       sal_so_outlet so, sal_sm_provider pm
where  pt.dpt_mpv_code = po.dpo_mpv_code
and    tr.mpt_code = pt.dpt_mpt_code
and    so.otl_code = po.dpo_otl_code
and    pm.mpv_code = po.dpo_mpv_code
and    so.otl_flag = 'Y'
and    pm.mpv_flag = 'Y'
and    po.dpo_lft_date is null
and    pt.dpt_eff_date = (select max(prvt.dpt_eff_date) from sal_sd_prv_training prvt
     where prvt.dpt_mpv_code = po.dpo_mpv_code)
group by po.dpo_otl_code,so.otl_reg_date,so.otl_add1,so.otl_add2,so.otl_desc
/

