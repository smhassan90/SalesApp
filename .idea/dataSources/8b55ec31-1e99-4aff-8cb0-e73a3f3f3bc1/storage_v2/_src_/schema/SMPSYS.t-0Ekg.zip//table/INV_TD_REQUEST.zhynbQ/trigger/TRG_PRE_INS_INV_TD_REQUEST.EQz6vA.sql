create trigger TRG_PRE_INS_INV_TD_REQUEST
  before insert
  on INV_TD_REQUEST
  for each row
  begin
IF :NEW.DRQ_ID IS NULL THEN
   :NEW.DRQ_ID := :NEW.DRQ_MRQ_NUM||'-'||LPAD(:NEW.DRQ_SEQ_NUM,3,000);
END IF;
end;
/

