create trigger EBA_SB_ANSWERS_BD
  before delete
  on EBA_SB_ANSWERS
  for each row
  begin
    eba_sb_fw.tag_sync(
        p_new_tags      => null,
        p_old_tags      => :old.tags,
        p_content_type  => 'ANSWERS',
        p_content_id    => :old.id );
end;
/

