create trigger MPV_ALIAS_TRG
  before insert
  on SAL_SM_PROVIDER
  for each row
  begin
  select MPV_ALIAS_SEQ.nextval INTO :new.MPV_ALIAS from dual;
end;
/

