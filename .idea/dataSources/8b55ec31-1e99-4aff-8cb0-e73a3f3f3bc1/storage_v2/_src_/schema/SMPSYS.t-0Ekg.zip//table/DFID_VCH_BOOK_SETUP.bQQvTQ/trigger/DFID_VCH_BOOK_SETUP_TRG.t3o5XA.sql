create trigger DFID_VCH_BOOK_SETUP_TRG
  before insert
  on DFID_VCH_BOOK_SETUP
  for each row
  begin
  SELECT DFID_VCH_BOOK_SETUP_SEQ.NEXTVAL INTO :NEW.VCH_ID FROM DUAL;
end;
/

