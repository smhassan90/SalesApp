create view SMP_VIEW_EVENT_STATUS as
  SELECT eti.event_id "EVENT_ID", e.name "EVENT_NAME", eti.node_name "NODE_NAME", eti.target_name "TARGET_NAME", eti.target_type "TARGET_TYPE", NVL(rtd.type_label,eti.target_type) "TARGET_NLS_TYPE",
         e.owner "ADMINISTRATOR_NAME", eti.timestamp+eti.timezone/86400000 "TIMESTAMP", eti.agent_status "EVENT_STATUS",
         303-ets.node_state "AGENT_STATUS", NVL(ets.agent_severity,15) severity
  FROM   SMP_VDE_EVENT e, SMP_VDE_EVENT_TARGET_INFO eti, SMP_VDE_EVENT_TARGET_STATE ets, SMP_VDG_NODE_LIST nl, SMP_VBO_REPORTS_TYPE_DEFN rtd
  WHERE  e.id = eti.event_id
    AND  eti.event_id = ets.event_id (+)
    AND  eti.target_name = ets.target_name (+)
    AND  eti.target_type = ets.target_type (+)
    AND  eti.node_name = nl.nodename (+)
    AND  UPPER(eti.target_type) = rtd.type (+)
/

comment on table SMP_VIEW_EVENT_STATUS
is 'List of all events known in the repository'
/

