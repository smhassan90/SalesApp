create trigger SAL_DAILY_DATA_TRG_INS
  before insert
  on SAL_DAILY_DATA
  for each row
  begin
  IF :NEW.SUID IS NULL THEN
    SELECT SEQ_SAL_DAILY_DATA.NEXTVAL INTO :NEW.SUID FROM DUAL;
  END IF;
end;
/

