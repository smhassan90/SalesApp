create materialized view MV_GL_CLASSIFICATION_DATA
refresh force on demand
  as
    select DPC_CP_CODE, 
        GET_LEVEL(DPC_CP_CODE,'R',SYSDATE,(
        'Z0'||SUBSTR(GET_LEVEL(DPC_CP_CODE,'A',SYSDATE,SUBSTR(OTL_CODE,1,5),'T'),2,2)),'Z') REGION,
       'Z0'||SUBSTR(GET_LEVEL(DPC_CP_CODE,'A',SYSDATE,SUBSTR(OTL_CODE,1,5),'T'),2,2) ZONE,
        DPC_MPV_CODE, MPV_DESC, otl_code, OTL_DESC,
        DPC_EFF_DATE,
        DECODE(NVL(OTL_LOC_TYPE,'N'),'U','Urban','R','Rural',
                                     'N','No Info') LOCATION,
        decode(DPC_PRV_CLASS,'GSS','Sabz Sitara','GLS','GoodLife Silver',
         'GLG','GoodLife Gold','GLN','GoodLife New','GLC',
         'GoodLife Conversion','Not Mention') Classification,
         "001 - GS1", "009 - AN_PN", "ANPN-DOC-CLR",
         "ANPN-DOC-T03", "ANPN-PAR-CLR", "ANPN-PAR-T03" ,
         "CC-DOC-CLR", "CC-PAR-CLR", "EC-DOC-CLR", 
         "EC-PAR-CLR", "EMOCA-DOC-CLR", "EMOCA-PAR-CLR", 
         "FPA-DOC-CER", "FPA-DOC-CLR", "FPA-PAR-CER", 
         "FPA-PAR-CLC", "FPA-PAR-CLR", "FPA-PAR-REF", 
         "FPB-DOC-CLR", "FPA-DOC-REF", "FPB-PAR-CLR", 
         "FPB-PAR-CER", "FPB-PAR-REF", "NNCA-DOC-CLR", 
         "NNCA-PAR-CLR", "NNCB-DOC-CLR", "NNCB-PAR-CLR", 
         "PGR-DOC-CLR", "PGR-PAR-CLR", 	"STI-DOC-CLR",
         "STI-PAR-CLR", "TB-DOC-CLR", "TFG-FPAP"
  from SAL_SD_PRV_CLASSIFICATION A, SAL_SD_PRV_OUTLET B, SAL_SM_PROVIDER C, SAL_SO_OUTLET E,
  (
      SELECT CRTD_MPV_CODE, 
                     MIN("001 - GS1")   "001 - GS1",
                     MIN("009 - AN_PN") "009 - AN_PN",
                     MIN("ANPN-DOC-CLR") "ANPN-DOC-CLR",
                     MIN("ANPN-DOC-T03") "ANPN-DOC-T03"  ,
                     MIN("ANPN-PAR-CLR") "ANPN-PAR-CLR", 
                     MIN("ANPN-PAR-T03") "ANPN-PAR-T03" ,
                     MIN("CC-DOC-CLR") "CC-DOC-CLR",	
                     MIN("CC-PAR-CLR") "CC-PAR-CLR",
                     MIN("EC-DOC-CLR") "EC-DOC-CLR",
                     MIN("EC-PAR-CLR") "EC-PAR-CLR",
                     MIN("EMOCA-DOC-CLR") "EMOCA-DOC-CLR",
                     MIN("EMOCA-PAR-CLR") "EMOCA-PAR-CLR", 
                     MIN("FPA-DOC-CER") "FPA-DOC-CER",
                     MIN("FPA-DOC-CLR") "FPA-DOC-CLR",
                     MIN("FPA-PAR-CER") "FPA-PAR-CER", 
                     MIN("FPA-PAR-CLC") "FPA-PAR-CLC", 
                     MIN("FPA-PAR-CLR") "FPA-PAR-CLR", 
                     MIN("FPA-PAR-REF") "FPA-PAR-REF", 
                     MIN("FPB-DOC-CLR") "FPB-DOC-CLR", 
                     MIN("FPA-DOC-REF") "FPA-DOC-REF", 
                     MIN("FPB-PAR-CLR") "FPB-PAR-CLR", 
                     MIN("FPB-PAR-CER") "FPB-PAR-CER", 
                     MIN("FPB-PAR-REF") "FPB-PAR-REF", 
                     MIN("NNCA-DOC-CLR") "NNCA-DOC-CLR", 
                     MIN("NNCA-PAR-CLR") "NNCA-PAR-CLR", 
                     MIN("NNCB-DOC-CLR") "NNCB-DOC-CLR", 
                     MIN("NNCB-PAR-CLR") "NNCB-PAR-CLR", 
                     MIN("PGR-DOC-CLR") "PGR-DOC-CLR", 
                     MIN("PGR-PAR-CLR") "PGR-PAR-CLR", 	
                     MIN("STI-DOC-CLR") "STI-DOC-CLR",
                     MIN("STI-PAR-CLR") "STI-PAR-CLR",
                     MIN("TB-DOC-CLR") "TB-DOC-CLR",	
                     MIN("TFG-FPAP") "TFG-FPAP"
      FROM (
              SELECT CRT_CP_CODE, CRTD_MPV_CODE, CRT_TRAINING_CODE, CRT_DATE, CRTD_COMPLETED_SUCCES, CRTD_OTL_CODE,
                     TRAINING_CODE, TRAINING_DESC, TRAINING_CATEGORY,
                     DECODE(TRAINING_CODE,'001',CRT_DATE,NULL) "001 - GS1",
                     DECODE(TRAINING_CODE,'009',CRT_DATE,NULL) "009 - AN_PN"	,
                     DECODE(TRAINING_CODE,'ANPN-DOC-CLR',CRT_DATE,NULL) "ANPN-DOC-CLR",
                     DECODE(TRAINING_CODE,'ANPN-DOC-T03',CRT_DATE,NULL) "ANPN-DOC-T03" ,
                     DECODE(TRAINING_CODE,'ANPN-PAR-CLR',CRT_DATE,NULL) "ANPN-PAR-CLR", 
                     DECODE(TRAINING_CODE,'ANPN-PAR-T03',CRT_DATE,NULL) "ANPN-PAR-T03" ,
                     DECODE(TRAINING_CODE,'CC-DOC-CLR',CRT_DATE,NULL) "CC-DOC-CLR",	
                     DECODE(TRAINING_CODE,'CC-PAR-CLR',CRT_DATE,NULL) "CC-PAR-CLR",
                     DECODE(TRAINING_CODE,'EC-DOC-CLR',CRT_DATE,NULL) "EC-DOC-CLR",
                     DECODE(TRAINING_CODE,'EC-PAR-CLR',CRT_DATE,NULL) "EC-PAR-CLR",
                     DECODE(TRAINING_CODE,'EMOCA-DOC-CLR',CRT_DATE,NULL) "EMOCA-DOC-CLR",
                     DECODE(TRAINING_CODE,'EMOCA-PAR-CLR',CRT_DATE,NULL) "EMOCA-PAR-CLR", 
                     DECODE(TRAINING_CODE,'FPA-DOC-CER',CRT_DATE,NULL) "FPA-DOC-CER",
                     DECODE(TRAINING_CODE,'FPA-DOC-CLR',CRT_DATE,NULL) "FPA-DOC-CLR",
                     DECODE(TRAINING_CODE,'FPA-PAR-CER',CRT_DATE,NULL) "FPA-PAR-CER", 
                     DECODE(TRAINING_CODE,'FPA-PAR-CLC',CRT_DATE,NULL) "FPA-PAR-CLC", 
                     DECODE(TRAINING_CODE,'FPA-PAR-CLR',CRT_DATE,NULL) "FPA-PAR-CLR", 
                     DECODE(TRAINING_CODE,'FPA-PAR-REF',CRT_DATE,NULL) "FPA-PAR-REF", 
                     DECODE(TRAINING_CODE,'FPB-DOC-CLR',CRT_DATE,NULL) "FPB-DOC-CLR", 
                     DECODE(TRAINING_CODE,'FPB-DOC-REF',CRT_DATE,NULL) "FPA-DOC-REF", 
                     DECODE(TRAINING_CODE,'FPB-PAR-CLR',CRT_DATE,NULL) "FPB-PAR-CLR", 
                     DECODE(TRAINING_CODE,'FPB-PAR-CER',CRT_DATE,NULL) "FPB-PAR-CER", 
                     DECODE(TRAINING_CODE,'FPB-PAR-REF',CRT_DATE,NULL) "FPB-PAR-REF", 
                     DECODE(TRAINING_CODE,'NNCA-DOC-CLR',CRT_DATE,NULL) "NNCA-DOC-CLR", 
                     DECODE(TRAINING_CODE,'NNCA-PAR-CLR',CRT_DATE,NULL) "NNCA-PAR-CLR", 
                     DECODE(TRAINING_CODE,'NNCB-DOC-CLR',CRT_DATE,NULL) "NNCB-DOC-CLR", 
                     DECODE(TRAINING_CODE,'NNCB-PAR-CLR',CRT_DATE,NULL) "NNCB-PAR-CLR", 
                     DECODE(TRAINING_CODE,'PGR-DOC-CLR',CRT_DATE,NULL) "PGR-DOC-CLR", 
                     DECODE(TRAINING_CODE,'PGR-PAR-CLR',CRT_DATE,NULL) "PGR-PAR-CLR", 	
                     DECODE(TRAINING_CODE,'STI-DOC-CLR',CRT_DATE,NULL) "STI-DOC-CLR",
                     DECODE(TRAINING_CODE,'STI-PAR-CLR',CRT_DATE,NULL) "STI-PAR-CLR",
                     DECODE(TRAINING_CODE,'TB-DOC-CLR',CRT_DATE,NULL) "TB-DOC-CLR",	
                     DECODE(TRAINING_CODE,'TFG-FPAP',CRT_DATE,NULL) "TFG-FPAP"
              FROM CLASSROOM_TRAINING_MASTER, CLASSROOM_TRAINING_DETAIL, TRAININGS
              WHERE CRT_ID      = CRTD_CRT_ID
                AND CRT_CP_CODE = CRTD_CP_CODE
                AND CRT_TRAINING_CODE = TRAINING_CODE
                AND CRT_CP_CODE  = COMPANY_CODE
                AND CRTD_COMPLETED_SUCCES = 'Y'
          )
      GROUP BY CRTD_MPV_CODE
) Z
 where A.DPC_MPV_CODE  = C.MPV_CODE
   AND A.dpc_cp_code   = C.MPV_CP_CODE
   AND A.DPC_MPV_CODE  = B.DPO_MPV_CODE
   AND A.dpc_cp_code   = B.DPO_CP_CODE  
   AND B.DPO_CP_CODE   = E.OTL_CP_CODE
   AND B.DPO_OTL_CODE  = E.OTL_CODE
   AND Z.CRTD_MPV_CODE = A.DPC_MPV_CODE 
   AND B.DPO_LFT_DATE  IS NULL
   AND A.DPC_CP_CODE   = '01' 
--   AND A.DPC_BR_CODE = 'Z04'


/

