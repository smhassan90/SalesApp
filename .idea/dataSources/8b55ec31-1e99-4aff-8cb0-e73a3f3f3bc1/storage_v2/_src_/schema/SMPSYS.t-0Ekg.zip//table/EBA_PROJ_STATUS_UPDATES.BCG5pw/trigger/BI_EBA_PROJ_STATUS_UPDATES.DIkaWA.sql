create trigger BI_EBA_PROJ_STATUS_UPDATES
  before insert or update
  on EBA_PROJ_STATUS_UPDATES
  for each row
  begin
   if :new."ID" is null then
     select to_number(sys_guid(),'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX') into :new.id from dual;
   end if;
    if :new.tags is not null then
        :new.tags := eba_proj_fw.tags_cleaner(:new.tags);
    end if;
   if inserting then
       :new.created := localtimestamp;
       :new.created_by := nvl(wwv_flow.g_user,user);
       :new.row_version_number := 1;
   elsif updating then
       :new.row_version_number := nvl(:old.row_version_number,1) + 1;
   end if;
   if inserting or updating then
       :new.updated := localtimestamp;
       :new.updated_by := nvl(wwv_flow.g_user,user);
   end if;
   if :new.row_key is null then
       select eba_proj_fw.COMPRESS_INT(eba_proj_seq.nextval) into :new.row_key from dual;
   end if;
   if :new.update_date is null then
       :new.update_date := localtimestamp;
   end if;
   if :new.update_owner is null then
       :new.update_owner := nvl(wwv_flow.g_user,user);
   end if;
   :new.update_owner := lower(:new.update_owner);
   eba_proj_fw.tag_sync(
       p_new_tags      => :new.tags,
       p_old_tags      => :old.tags,
       p_content_type  => 'UPDATES',
       p_content_id    => :new.id );
end;
/

