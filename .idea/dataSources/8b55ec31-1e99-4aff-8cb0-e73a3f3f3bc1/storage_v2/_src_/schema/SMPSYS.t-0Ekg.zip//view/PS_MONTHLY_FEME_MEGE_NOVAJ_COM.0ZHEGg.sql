create view PS_MONTHLY_FEME_MEGE_NOVAJ_COM as
  select   item_code,month_no,month_name Month,sum(sale_qty) Quantity
from     ps_monthly_FEM_NOV_MEG
where    item_code ='FEM001'
group by item_Code,month_name,month_no
  union
select   item_code,month_no,month_name Month,sum(sale_qty*3) Quantity
from     ps_monthly_FEM_NOV_MEG
where    item_code ='MEG001'
group by item_Code,month_name,month_no
  UNION
select   item_code,month_no,month_name Month,sum(sale_qty*2) Quantity
from     ps_monthly_FEM_NOV_MEG
where    item_code ='NOJ001'
group by item_Code,month_name,month_no
order by 2
/

