create trigger TRG_PRE_INS_INV_SO_ITM_PRICE
  before insert
  on INV_SO_ITEM_PRICE
  for each row
  begin
SELECT SQ_INV_SO_ITM_PRICE.NEXTVAL INTO :NEW.IPR_ID FROM DUAL;
end;
/

