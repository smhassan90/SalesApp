create view LAD3_DUMMY_INDICATORS as
  select 'No of MIO refresher trainings held' Devliverable, TO_NUMBER('0') Achieved,TO_CHAR(TO_DATE('01-JAN-2014'),'DD-MON-YYYY') mnth from dual
union all
select 'No of MIOs trained ' Devliverable, TO_NUMBER('0') Achieved,TO_CHAR(TO_DATE('01-JAN-2014'),'DD-MON-YYYY') mnth from dual
union all
select 'MIO detailing visits to MVA providers' Devliverable, TO_NUMBER('0') Achieved,TO_CHAR(TO_DATE('01-JAN-2014'),'DD-MON-YYYY') mnth from dual
union all
select 'No of MIOs HS IPCstaff trained on electronic provider profiles' Devliverable, TO_NUMBER('0') Achieved,TO_CHAR(TO_DATE('01-JAN-2014'),'DD-MON-YYYY') mnth from dual
union all
select 'No of quarterly review meetings conducted and provider profiles reviewed ' Devliverable, TO_NUMBER('0') Achieved,TO_CHAR(TO_DATE('01-JAN-2014'),'DD-MON-YYYY') mnth from dual
union all
select 'No of Theatre Shows conducted' Devliverable, TO_NUMBER('0') Achieved,TO_CHAR(TO_DATE('01-JAN-2014'),'DD-MON-YYYY') mnth from dual
union all
select 'No of new providers upgraded to core status' Devliverable, TO_NUMBER('0') Achieved,TO_CHAR(TO_DATE('01-JAN-2014'),'DD-MON-YYYY') mnth from dual
union all
select 'No of LAD-supported core providers offering quality IUD services' Devliverable, TO_NUMBER('0') Achieved,TO_CHAR(TO_DATE('01-JAN-2014'),'DD-MON-YYYY') mnth from dual
union all
select 'No of  providers providing PPIUD services' Devliverable, TO_NUMBER('0') Achieved,TO_CHAR(TO_DATE('01-JAN-2014'),'DD-MON-YYYY') mnth from dual
union all
select 'No of AMHS provided refresher training' Devliverable, TO_NUMBER('0') Achieved,TO_CHAR(TO_DATE('01-JAN-2014'),'DD-MON-YYYY') mnth from dual
union all
select 'No of FP seminars conducted for Core providers' Devliverable, TO_NUMBER('0') Achieved,TO_CHAR(TO_DATE('01-JAN-2014'),'DD-MON-YYYY') mnth from dual
union all
select 'No of Core providers attended FP seminars' Devliverable, TO_NUMBER('0') Achieved,TO_CHAR(TO_DATE('01-JAN-2014'),'DD-MON-YYYY') mnth from dual
union all
select 'No of PPIUD providers attended FP seminars' Devliverable, TO_NUMBER('0') Achieved,TO_CHAR(TO_DATE('01-JAN-2014'),'DD-MON-YYYY') mnth from dual
union all
select 'No of MVA providers attended FP seminars' Devliverable, TO_NUMBER('0') Achieved,TO_CHAR(TO_DATE('01-JAN-2014'),'DD-MON-YYYY') mnth from dual
union all
select 'No of provider recognition events conducted for Core providers' Devliverable, TO_NUMBER('0') Achieved,TO_CHAR(TO_DATE('01-JAN-2014'),'DD-MON-YYYY') mnth from dual
union all
select 'No of provider recognition events conducted for PPIUD  providers' Devliverable, TO_NUMBER('0') Achieved,TO_CHAR(TO_DATE('01-JAN-2014'),'DD-MON-YYYY') mnth from dual
union all
select 'No of core providers attended recognition events' Devliverable, TO_NUMBER('0') Achieved,TO_CHAR(TO_DATE('01-JAN-2014'),'DD-MON-YYYY') mnth from dual
union all
select 'No of PPIUD providers attended recognition events' Devliverable, TO_NUMBER('0') Achieved,TO_CHAR(TO_DATE('01-JAN-2014'),'DD-MON-YYYY') mnth from dual
union all
select 'No of high performing Core providers recognized' Devliverable, TO_NUMBER('0') Achieved,TO_CHAR(TO_DATE('01-JAN-2014'),'DD-MON-YYYY') mnth from dual
union all
select 'No of high performing PPIUD providerds recognized' Devliverable, TO_NUMBER('0') Achieved,TO_CHAR(TO_DATE('01-JAN-2014'),'DD-MON-YYYY') mnth from dual
union all
select 'No of LCDs distributed to Core providers' Devliverable, TO_NUMBER('0') Achieved,TO_CHAR(TO_DATE('01-JAN-2014'),'DD-MON-YYYY') mnth from dual
union all
select 'No of LCDs distributed to PPIUD providers' Devliverable, TO_NUMBER('0') Achieved,TO_CHAR(TO_DATE('01-JAN-2014'),'DD-MON-YYYY') mnth from dual
union all
select 'No of Staff given GS award' Devliverable, TO_NUMBER('0') Achieved,TO_CHAR(TO_DATE('01-JAN-2014'),'DD-MON-YYYY') mnth from dual
union all
select 'No of providers given GS award' Devliverable, TO_NUMBER('0') Achieved,TO_CHAR(TO_DATE('01-JAN-2014'),'DD-MON-YYYY') mnth from dual
union all
select 'AMHS trained on electronic provider reports analysis' Devliverable, TO_NUMBER('0') Achieved,TO_CHAR(TO_DATE('01-JAN-2014'),'DD-MON-YYYY') mnth from dual
union all
select 'No of Tertiary hospitals signed MoU for PPIUD' Devliverable, TO_NUMBER('0') Achieved,TO_CHAR(TO_DATE('01-JAN-2014'),'DD-MON-YYYY') mnth from dual
union all
select 'No of staff trained in PPIUD at tertiary hospitals' Devliverable, TO_NUMBER('0') Achieved,TO_CHAR(TO_DATE('01-JAN-2014'),'DD-MON-YYYY') mnth from dual
union all
select 'Percent of core providers meeting 100% critical quality standards' Devliverable, TO_NUMBER('0') Achieved,TO_CHAR(TO_DATE('01-JAN-2014'),'DD-MON-YYYY') mnth from dual
union all
select 'No of core providers assessed through SBMR' Devliverable, TO_NUMBER('0') Achieved,TO_CHAR(TO_DATE('01-JAN-2014'),'DD-MON-YYYY') mnth from dual
union all
select 'No of core providers assessed through exit interviews' Devliverable, TO_NUMBER('0') Achieved,TO_CHAR(TO_DATE('01-JAN-2014'),'DD-MON-YYYY') mnth from dual
union all
select 'No of providers sent quality themed smses' Devliverable, TO_NUMBER('0') Achieved,TO_CHAR(TO_DATE('01-JAN-2014'),'DD-MON-YYYY') mnth from dual
union all
select 'No of core providers selected for CE' Devliverable, TO_NUMBER('0') Achieved,TO_CHAR(TO_DATE('01-JAN-2014'),'DD-MON-YYYY') mnth from dual
union all
select 'No of CoE providers trained on Referral Strategy' Devliverable, TO_NUMBER('0') Achieved,TO_CHAR(TO_DATE('01-JAN-2014'),'DD-MON-YYYY') mnth from dual
union all
select 'No of CoE developed/ upgraded' Devliverable, TO_NUMBER('0') Achieved,TO_CHAR(TO_DATE('01-JAN-2014'),'DD-MON-YYYY') mnth from dual
union all
select 'No of ISOWs placed at CoE' Devliverable, TO_NUMBER('0') Achieved,TO_CHAR(TO_DATE('01-JAN-2014'),'DD-MON-YYYY') mnth from dual
union all
select 'No of female Community Educator (IPC workers) hired' Devliverable, TO_NUMBER('0') Achieved,TO_CHAR(TO_DATE('01-JAN-2014'),'DD-MON-YYYY') mnth from dual
union all
select 'No of male Community Educators (IPC workers) hired' Devliverable, TO_NUMBER('0') Achieved,TO_CHAR(TO_DATE('01-JAN-2014'),'DD-MON-YYYY') mnth from dual
union all
select 'No of field supervisors hired and trained' Devliverable, TO_NUMBER('0') Achieved,TO_CHAR(TO_DATE('01-JAN-2014'),'DD-MON-YYYY') mnth from dual
union all
select 'No of MWRAs contacted per IPC worker (MWRAs/No of workers)' Devliverable, TO_NUMBER('0') Achieved,TO_CHAR(TO_DATE('01-JAN-2014'),'DD-MON-YYYY') mnth from dual
union all
select 'Total no of MWRAs contacted (by all LAD workers)' Devliverable, TO_NUMBER('0') Achieved,TO_CHAR(TO_DATE('01-JAN-2014'),'DD-MON-YYYY') mnth from dual
union all
select 'Total no of neighborhood meetings conducted with MWRAs ' Devliverable, TO_NUMBER('0') Achieved,TO_CHAR(TO_DATE('01-JAN-2014'),'DD-MON-YYYY') mnth from dual
union all
select 'Total no of group meetings conducted with mothers-in-laws ' Devliverable, TO_NUMBER('0') Achieved,TO_CHAR(TO_DATE('01-JAN-2014'),'DD-MON-YYYY') mnth from dual
union all
select 'Total no of group meetings conducted with community men per worker' Devliverable, TO_NUMBER('0') Achieved,TO_CHAR(TO_DATE('01-JAN-2014'),'DD-MON-YYYY') mnth from dual
union all
select 'Total no of referrals made by CEs' Devliverable, TO_NUMBER('0') Achieved,TO_CHAR(TO_DATE('01-JAN-2014'),'DD-MON-YYYY') mnth from dual
union all
select 'No of referrals made per community educator' Devliverable, TO_NUMBER('0') Achieved,TO_CHAR(TO_DATE('01-JAN-2014'),'DD-MON-YYYY') mnth from dual
union all
select 'No of referrals made through Willows Foundation' Devliverable, TO_NUMBER('0') Achieved,TO_CHAR(TO_DATE('01-JAN-2014'),'DD-MON-YYYY') mnth from dual
union all
select 'No of STMs  adopted through Willows referrals' Devliverable, TO_NUMBER('0') Achieved,TO_CHAR(TO_DATE('01-JAN-2014'),'DD-MON-YYYY') mnth from dual
union all
select 'No of LTMs adopted through Willows referrals' Devliverable, TO_NUMBER('0') Achieved,TO_CHAR(TO_DATE('01-JAN-2014'),'DD-MON-YYYY') mnth from dual
union all
select 'No of DMSS provided refreshers on MVA' Devliverable, TO_NUMBER('0') Achieved,TO_CHAR(TO_DATE('01-JAN-2014'),'DD-MON-YYYY') mnth from dual
union all
select 'No of recognition ceremonies conducted for MVA providers' Devliverable, TO_NUMBER('0') Achieved,TO_CHAR(TO_DATE('01-JAN-2014'),'DD-MON-YYYY') mnth from dual
union all
select 'No of high performing MVA providers recognized' Devliverable, TO_NUMBER('0') Achieved,TO_CHAR(TO_DATE('01-JAN-2014'),'DD-MON-YYYY') mnth from dual
union all
select 'No of LCDS distributed to MVA providers' Devliverable, TO_NUMBER('0') Achieved,TO_CHAR(TO_DATE('01-JAN-2014'),'DD-MON-YYYY') mnth from dual
union all
select 'DMSS trained on electronc T-CAT' Devliverable, TO_NUMBER('0') Achieved,TO_CHAR(TO_DATE('01-JAN-2014'),'DD-MON-YYYY') mnth from dual
union all
select 'No of MVA providers assessed using T-CAT' Devliverable, TO_NUMBER('0') Achieved,TO_CHAR(TO_DATE('01-JAN-2014'),'DD-MON-YYYY') mnth from dual
union all
select 'Percent of MVA providers meeting 100% critical quality standards' Devliverable, TO_NUMBER('0') Achieved,TO_CHAR(TO_DATE('01-JAN-2014'),'DD-MON-YYYY') mnth from dual
/

