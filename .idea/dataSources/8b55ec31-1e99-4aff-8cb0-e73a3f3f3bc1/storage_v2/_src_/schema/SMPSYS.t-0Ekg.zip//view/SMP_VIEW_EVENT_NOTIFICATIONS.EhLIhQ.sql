create view SMP_VIEW_EVENT_NOTIFICATIONS as
  SELECT e.id "EVENT_ID", e.name "EVENT_NAME", ion.username "ADMINISTRATOR_NAME", ets.target_name "TARGET_NAME", ets.target_type "TARGET_TYPE", NVL(rtd.type_label,ets.target_type) "TARGET_NLS_TYPE"
  FROM   SMP_VDI_AOBJECT_NOTIFICATION ion, SMP_VDI_OBJECT_TABLE iot, SMP_VDE_EVENT e, SMP_VDE_EVENT_TARGET_STATE ets, SMP_VBO_REPORTS_TYPE_DEFN rtd
  WHERE  ion.notify = 1
    AND  iot.object_id = ion.object_id
    AND  iot.TYPE = 'EVENT'
    AND  iot.object_name = e.id
    AND  e.is_library = 'N'
    AND  e.id = ets.event_id
    AND  UPPER(ets.target_type) = rtd.type (+)
/

comment on table SMP_VIEW_EVENT_NOTIFICATIONS
is 'List of all administrators who will get notified about event conditions'
/

