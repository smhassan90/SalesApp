create trigger SAL_DAILY_DATA_HIS_COPY_TRG_ED
  before insert or update
  on SAL_DAILY_DATA_HIS_COPY
  for each row
  BEGIN
  
  :NEW.HIS_ENTRY_DATE := TO_DATE(SYSDATE);
  
END;
/

