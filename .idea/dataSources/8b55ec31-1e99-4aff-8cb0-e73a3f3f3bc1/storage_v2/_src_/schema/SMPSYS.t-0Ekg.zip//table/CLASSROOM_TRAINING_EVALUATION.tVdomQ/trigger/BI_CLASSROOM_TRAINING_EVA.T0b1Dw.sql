create trigger BI_CLASSROOM_TRAINING_EVA
  before insert
  on CLASSROOM_TRAINING_EVALUATION
  for each row
  begin
    select SQ_CLASSROOM_TRAINING_EVA.nextval INTO :new.CRTE_ID
    from dual;
end;
/

