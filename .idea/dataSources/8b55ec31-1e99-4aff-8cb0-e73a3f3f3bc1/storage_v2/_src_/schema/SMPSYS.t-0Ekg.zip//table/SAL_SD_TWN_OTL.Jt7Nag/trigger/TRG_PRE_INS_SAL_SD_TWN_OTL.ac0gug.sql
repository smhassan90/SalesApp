create trigger TRG_PRE_INS_SAL_SD_TWN_OTL
  before insert
  on SAL_SD_TWN_OTL
  for each row
  begin
   SELECT SQ_SAL_SD_TWN_OTL.NEXTVAL INTO :NEW.SST_ID FROM DUAL;
end;
/

