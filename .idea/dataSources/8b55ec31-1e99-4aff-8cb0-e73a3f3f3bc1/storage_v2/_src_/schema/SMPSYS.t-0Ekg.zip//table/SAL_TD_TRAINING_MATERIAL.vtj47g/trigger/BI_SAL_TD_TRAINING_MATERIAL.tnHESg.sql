create trigger BI_SAL_TD_TRAINING_MATERIAL
  before insert
  on SAL_TD_TRAINING_MATERIAL
  for each row
  begin
    select SQ_SAL_TD_TRAINING_MATERIAL.nextval INTO :new.TMD_ID
    from dual;
end;
/

