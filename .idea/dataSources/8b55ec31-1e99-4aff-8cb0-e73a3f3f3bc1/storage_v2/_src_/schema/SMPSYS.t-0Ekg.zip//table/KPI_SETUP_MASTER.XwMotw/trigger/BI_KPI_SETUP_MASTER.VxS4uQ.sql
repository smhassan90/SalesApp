create trigger BI_KPI_SETUP_MASTER
  before insert
  on KPI_SETUP_MASTER
  for each row
  begin
    select "KPI_SETUP_MASTER_SEQ".nextval into :NEW.KPI_ID from dual;
end;
/

