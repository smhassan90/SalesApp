create view VU_MV_REG_ZON_DIST_CAW as
  (
SELECT
       SUBSTR(GET_LEVEL('01','R',SYSDATE,ZONE,'Z'),1,4) REGION,
       SUBSTR(  GET_LEVEL_NAME('01',
            GET_LEVEL('01','R',SYSDATE,ZONE,'Z')),1,50) REGIONNAME,
       ZONE, ZONENAME, TERRITORY, TERRITORYNAME, 
       DISTRICT, GET_LEVEL_NAME('01',DISTRICT) DISTRICT_NAME,
       WEEKNO, IAWFOR, MAR_ID,
       DAR_MAC_ID, MAC_DESC ACTIVITY_NAME,
       SUM(ACL1) "No. of Meetings",
       SUM(ACL2) "No. of Participants",
       SUM(ACL3) "Tokens Given",
       SUM(ACL4) "Brochure Given",
       SUM(ACL5) "Gifts Given",
       SUM(ACL6) "Total",
       SUM(ACL8) "Influencers talked to",
       SUM(ACL9) "Cost",
       SUM(ACL10) "Women Ref - FP",
       SUM(ACL11) "Women Ref - Pregnant",
       SUM(ACL12) "Women Ref - Other Complain",
       SUM(ACL13) "Child Age less 1 month",
       SUM(ACL14) "Child Age 1 m and 5 yrs"
FROM MV_REG_ZON_DIST_CAW A, IPC_SO_ACTIVITY B
WHERE B.MAC_ID = A.DAR_MAC_ID
GROUP BY ZONE, ZONENAME, TERRITORY, TERRITORYNAME, DISTRICT, DAR_MAC_ID, MAC_DESC, 
         WEEKNO, MAR_ID, IAWFOR
         )

/

