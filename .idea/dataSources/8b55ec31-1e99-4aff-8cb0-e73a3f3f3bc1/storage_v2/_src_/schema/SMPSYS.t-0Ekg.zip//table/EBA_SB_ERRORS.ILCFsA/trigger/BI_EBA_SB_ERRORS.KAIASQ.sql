create trigger BI_EBA_SB_ERRORS
  before insert or update
  on EBA_SB_ERRORS
  for each row
  begin
    if :new.id is null then
        :new.id := eba_sb.gen_id();
    end if;
end;
/

