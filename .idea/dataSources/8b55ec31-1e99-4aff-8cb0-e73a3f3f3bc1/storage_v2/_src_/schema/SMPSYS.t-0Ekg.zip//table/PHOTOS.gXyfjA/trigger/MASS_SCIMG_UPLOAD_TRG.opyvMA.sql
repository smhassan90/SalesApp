create trigger MASS_SCIMG_UPLOAD_TRG
  before insert
  on PHOTOS
  for each row
  BEGIN
    SELECT mass_scimg_upload_seq.NEXTVAL INTO :NEW.PHOTO_ID
    FROM DUAL;
END;
/

