create view SMP_VIEW_JOB_HISTORY as
  SELECT jl.job_id "JOB_ID", jpt.job_name "JOB_NAME", jl.target_name "TARGET_NAME", jpt.target_type "TARGET_TYPE", NVL(rtd.type_label,jpt.target_type) "TARGET_NLS_TYPE",
		 jl.exec_num "EXEC_NUM", jl.time_stamp+jl.time_zone/86400000 "TIMESTAMP", jl.status "STATUS"
  FROM   SMP_VDJ_JOB_LOG jl, SMP_VDJ_JOB_PER_TARGET jpt, SMP_VBO_REPORTS_TYPE_DEFN rtd
  WHERE  jl.job_id = jpt.job_id
    AND  jl.target_name = jpt.target_name
    AND  UPPER(jpt.target_type) = rtd.type (+)
/

comment on table SMP_VIEW_JOB_HISTORY
is 'Status details of each job notification in the repository'
/

