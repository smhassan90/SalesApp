create trigger TRG_SAL_TM_STOCK
  before insert
  on SAL_TM_STOCK
  for each row
  DECLARE
tmpVar NUMBER;
BEGIN
   tmpVar := 0;

   SELECT SAL_STK_SEQ.NEXTVAL INTO tmpVar FROM dual;
   :NEW.STK_ID:= tmpVar;

END;
/

