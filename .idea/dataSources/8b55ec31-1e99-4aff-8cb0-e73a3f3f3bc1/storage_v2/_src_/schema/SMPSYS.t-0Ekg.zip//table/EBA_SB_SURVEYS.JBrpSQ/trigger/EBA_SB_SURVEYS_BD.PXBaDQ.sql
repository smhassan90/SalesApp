create trigger EBA_SB_SURVEYS_BD
  before delete
  on EBA_SB_SURVEYS
  for each row
  begin
    eba_sb_fw.tag_sync(
        p_new_tags      => null,
        p_old_tags      => :old.tags,
        p_content_type  => 'SURVEYS',
        p_content_id    => :old.id );
end;
/

