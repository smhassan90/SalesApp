create trigger AI_ISR_XD_SECURITY
  after insert
  on ISR_XD_SECURITY
  for each row
  DECLARE
CHK NUMBER;
BEGIN


  FOR I IN (SELECT USR_CP_CODE,USR_NAME,USR_SEC_CODE FROM ISR_XO_USERS
            WHERE  USR_STATUS = 'Y'
            AND    USR_SEC_CODE = :NEW.DSC_SEC_CODE
            AND    USR_CP_CODE  = :NEW.DSC_CP_CODE) 
  LOOP
  INSERT INTO ISR_XD_SECURITY_DTL (DDS_CP_CODE,DDS_DSC_ID,DDS_USR_NAME,DDS_FLAG,dds_ins, dds_upd, dds_del, dds_qry, dds_exe, dds_start_date)
        VALUES  (I.USR_CP_CODE,:NEW.DSC_ID,I.USR_NAME,'Y','N','N','N','N','N',sysdate);
  END LOOP;
END;
/

