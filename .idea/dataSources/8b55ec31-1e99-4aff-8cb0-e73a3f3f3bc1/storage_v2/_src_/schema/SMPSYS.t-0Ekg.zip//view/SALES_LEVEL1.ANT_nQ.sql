create view SALES_LEVEL1 as
  select d.dsl_msl_code, m.msl_desc m_desc,
       d.dsl_sub_code
from   sal_sm_sales_level m, sal_sd_sales_level d
where  m.msl_code = d.dsl_msl_code
or     m.msl_code = d.dsl_sub_code
/

