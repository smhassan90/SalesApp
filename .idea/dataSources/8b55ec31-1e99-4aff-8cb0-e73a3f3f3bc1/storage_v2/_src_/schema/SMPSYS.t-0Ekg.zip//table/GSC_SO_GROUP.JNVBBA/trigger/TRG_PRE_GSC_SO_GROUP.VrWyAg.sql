create trigger TRG_PRE_GSC_SO_GROUP
  before insert
  on GSC_SO_GROUP
  for each row
  begin
 SELECT SQ_GSC_SO_GROUP.NEXTVAL INTO :NEW.GSG_ID FROM DUAL;
 end;

/

