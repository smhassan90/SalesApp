create trigger BI_ISR_XD_SECURITY_DTL
  before insert
  on ISR_XD_SECURITY_DTL
  for each row
  BEGIN
    if :new.dds_id is null then
    select SQ_ISR_XD_SECURITY_DTL.nextval INTO :new.DDS_ID
    FROM DUAL;
    end if;
end;
/

