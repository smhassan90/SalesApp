create trigger BI_IPC_SM_CBA
  before insert
  on IPC_SM_CBA
  for each row
  begin
  for c1 in (
    select IPC_SM_CBA_SEQ.nextval next_val
    from dual
  ) loop
    :new.MCB_ID :=  c1.next_val;
  end loop;
end;
/

