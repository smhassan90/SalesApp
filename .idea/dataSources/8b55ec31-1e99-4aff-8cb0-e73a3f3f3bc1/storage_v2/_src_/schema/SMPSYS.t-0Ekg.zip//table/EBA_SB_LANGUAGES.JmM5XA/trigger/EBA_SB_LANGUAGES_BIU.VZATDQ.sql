create trigger EBA_SB_LANGUAGES_BIU
  before insert or update
  on EBA_SB_LANGUAGES
  for each row
  begin
    if inserting then
        if :new.id is null then
            :new.id := eba_sb.gen_id();
        end if;
        :new.created_by := nvl(v('APP_USER'),USER);
        :new.created := localtimestamp;
    end if;
    :new.updated_by := nvl(v('APP_USER'),USER);
    :new.updated := localtimestamp;
end;
/

