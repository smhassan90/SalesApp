create trigger AU_EBA_PROJ_STATUS_MS
  after update
  on EBA_PROJ_STATUS_MS
  for each row
  declare
    ov varchar2(4000) := null;
    nv varchar2(4000) := null;
begin
    -- PROJECT_ID (foreign key)
    if nvl(:old.project_id,-999) != nvl(:new.project_id,-999) then
        ov := null; nv := null;
        for c1 in (select row_key val from eba_proj_status t where t.id = :old.project_id) loop
            ov := c1.val;
        end loop;
        for c1 in (select row_key val from eba_proj_status t where t.id = :new.project_id) loop
            nv := c1.val;
        end loop;
        insert into eba_proj_history (table_name, component_rowkey, component_id, column_name, old_value, new_value) values
            ('STATUS_MS', :new.row_key, :new.id, 'PROJECT_ID', ov, nv);
    end if;
    -- MILESTONE_NAME (default)
    if nvl(:old.milestone_name, '0') != nvl(:new.milestone_name,'0') then 
        insert into eba_proj_history (table_name, component_rowkey, component_id, column_name, old_value, new_value) values 
            ('STATUS_MS', :new.row_key, :new.id, 'MILESTONE_NAME', substr(:old.milestone_name,0,4000), substr(:new.milestone_name,0,4000) ); 
    end if;
    -- MILESTONE_DESCRIPTION (default)
    if nvl(:old.milestone_description, '0') != nvl(:new.milestone_description,'0') then 
        insert into eba_proj_history (table_name, component_rowkey, component_id, column_name, old_value, new_value) values 
            ('STATUS_MS', :new.row_key, :new.id, 'MILESTONE_DESCRIPTION', substr(:old.milestone_description,0,4000), substr(:new.milestone_description,0,4000) ); 
    end if;
    -- MILESTONE_DATE (date/timestamp)
    if (:old.milestone_date is null and :new.milestone_date is not null) or 
        (:old.milestone_date is not null and :new.milestone_date is null) or 
        (:old.milestone_date != :new.milestone_date) then 
        insert into eba_proj_history (table_name, component_rowkey, component_id, column_name, old_value, new_value) values 
            ('STATUS_MS', :new.row_key, :new.id, 'MILESTONE_DATE', to_char(:old.milestone_date, 'DD-MON-YYYY'), to_char(:new.milestone_date, 'DD-MON-YYYY') );
    end if;
    -- MILESTONE_START_DATE (date/timestamp)
    if (:old.milestone_start_date is null and :new.milestone_start_date is not null) or 
        (:old.milestone_start_date is not null and :new.milestone_start_date is null) or 
        (:old.milestone_start_date != :new.milestone_start_date) then 
        insert into eba_proj_history (table_name, component_rowkey, component_id, column_name, old_value, new_value) values 
            ('STATUS_MS', :new.row_key, :new.id, 'MILESTONE_START_DATE', to_char(:old.milestone_start_date, 'DD-MON-YYYY'), to_char(:new.milestone_start_date, 'DD-MON-YYYY') );
    end if;
    -- MILESTONE_STATUS (default)
    if nvl(:old.milestone_status, '0') != nvl(:new.milestone_status,'0') then 
        insert into eba_proj_history (table_name, component_rowkey, component_id, column_name, old_value, new_value) values 
            ('STATUS_MS', :new.row_key, :new.id, 'MILESTONE_STATUS', substr(:old.milestone_status,0,4000), substr(:new.milestone_status,0,4000) ); 
    end if;
    -- MILESTONE_OWNER (default)
    if nvl(:old.milestone_owner, '0') != nvl(:new.milestone_owner,'0') then 
        insert into eba_proj_history (table_name, component_rowkey, component_id, column_name, old_value, new_value) values 
            ('STATUS_MS', :new.row_key, :new.id, 'MILESTONE_OWNER', substr(:old.milestone_owner,0,4000), substr(:new.milestone_owner,0,4000) ); 
    end if;
    -- IS_MAJOR_YN (default)
    if nvl(:old.is_major_yn, '0') != nvl(:new.is_major_yn,'0') then 
        insert into eba_proj_history (table_name, component_rowkey, component_id, column_name, old_value, new_value) values 
            ('STATUS_MS', :new.row_key, :new.id, 'IS_MAJOR_YN', substr(:old.is_major_yn,0,4000), substr(:new.is_major_yn,0,4000) ); 
    end if;
end au_eba_proj_status_ms;
/

