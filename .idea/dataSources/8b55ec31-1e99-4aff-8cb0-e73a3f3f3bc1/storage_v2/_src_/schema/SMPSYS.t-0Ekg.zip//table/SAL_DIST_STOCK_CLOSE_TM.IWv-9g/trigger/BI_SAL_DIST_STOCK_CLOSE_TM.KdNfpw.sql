create trigger BI_SAL_DIST_STOCK_CLOSE_TM
  before insert
  on SAL_DIST_STOCK_CLOSE_TM
  for each row
  begin
 SELECT SQ_SAL_DIST_STOCK_CLOSE_TM.NEXTVAL INTO :NEW.SDS_ID FROM DUAL;
 end;
/

