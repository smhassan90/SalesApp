create trigger TRG_PRE_INS_DMA_POLICY
  before insert
  on DMA_SO_POLICY
  for each row
  begin
 SELECT SQ_DMA_POLICY.NEXTVAL INTO :NEW.DSP_ID FROM DUAL;
 end;
/

