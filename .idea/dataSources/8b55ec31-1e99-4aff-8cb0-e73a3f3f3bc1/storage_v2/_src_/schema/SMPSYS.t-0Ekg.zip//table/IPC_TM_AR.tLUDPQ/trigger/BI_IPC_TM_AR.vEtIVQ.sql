create trigger BI_IPC_TM_AR
  before insert
  on IPC_TM_AR
  for each row
  begin
  for c1 in (
    select IPC_TM_AR_SEQ.nextval next_val
    from dual
  ) loop
   if :new.mar_id is null then
    :new.MAR_ID :=  c1.next_val;
  end if;
  end loop;
end;
/

