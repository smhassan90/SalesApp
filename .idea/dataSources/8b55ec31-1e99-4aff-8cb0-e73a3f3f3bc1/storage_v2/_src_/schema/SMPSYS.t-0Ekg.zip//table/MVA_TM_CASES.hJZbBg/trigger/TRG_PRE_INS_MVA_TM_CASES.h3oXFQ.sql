create trigger TRG_PRE_INS_MVA_TM_CASES
  before insert
  on MVA_TM_CASES
  for each row
  begin
SELECT SQ_MVA_TM_CASES.NEXTVAL INTO :NEW.MTC_ID FROM DUAL;
end;
/

