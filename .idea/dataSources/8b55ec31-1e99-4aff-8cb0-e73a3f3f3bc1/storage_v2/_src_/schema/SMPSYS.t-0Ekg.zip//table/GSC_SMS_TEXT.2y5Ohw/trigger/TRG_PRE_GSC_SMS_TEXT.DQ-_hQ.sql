create trigger TRG_PRE_GSC_SMS_TEXT
  before insert
  on GSC_SMS_TEXT
  for each row
  begin
 SELECT SQ_GSC_SMS_TEXT.NEXTVAL INTO :NEW.GST_ID FROM DUAL;
 end;
/

