create view VU_TBP_PAT_SPM_RES_SUM as
  select spm_pat_id, max(month1) M0, max(month2) M1, max(month3) M2,
                   max(month4) M3, max(month5) M4, max(month6) M5
from (
SELECT SPM_PAT_ID, SPM_COL_DATE, SPM_ID_CODE, RES_SMEAR,
       spm_pat_seq,
  case when spm_pat_seq = 0
       then 'Result:'||RES_SMEAR || '/ Lab No.:'
                                     ||SPM_ID_CODE
             || '/ Result Date:' || TO_CHAR(RES_DATE,'DD-MON-YYYY')
  end month1,
  case when spm_pat_seq = 1
       then 'Result:'||RES_SMEAR || '/ Lab No.:'
                                     ||SPM_ID_CODE
             || '/ Result Date:' || TO_CHAR(RES_DATE,'DD-MON-YYYY')
  end month2,
  case when spm_pat_seq = 2
       then 'Result:'||RES_SMEAR || '/ Lab No.:'
                                     ||SPM_ID_CODE
             || '/ Result Date:' || TO_CHAR(RES_DATE,'DD-MON-YYYY')
  end month3,
  case when spm_pat_seq = 3
       then 'Result:'||RES_SMEAR || '/ Lab No.:'
                                     ||SPM_ID_CODE
             || '/ Result Date:' || TO_CHAR(RES_DATE,'DD-MON-YYYY')
  end month4,
  case when spm_pat_seq = 4
       then 'Result:'||RES_SMEAR || '/ Lab No.:'
                                     ||SPM_ID_CODE
             || '/ Result Date:' || TO_CHAR(RES_DATE,'DD-MON-YYYY')
  end month5,
  case when spm_pat_seq = 5
       then 'Result:'||RES_SMEAR || '/ Lab No.:'
                                     ||SPM_ID_CODE
             || '/ Result Date:' || TO_CHAR(RES_DATE,'DD-MON-YYYY')
  end month6

from (
--- new query with row_number function
SELECT DISTINCT A.SPM_PAT_ID, A.SPM_COL_DATE, A.SPM_ID_CODE, 
       B.RES_DATE, B.RES_SMEAR, 0 SPM_PAT_SEQ
FROM TBP_TM_SPMREQ A, TBP_TD_SPMRES B 
WHERE SPM_ID = RES_SPM_ID (+)
and   A.SPM_EXM_REASON = 'Diagnosis'
and   A.SPM_COL_DATE = ( 
                        SELECT MAX(Z.SPM_COL_DATE) 
                        FROM TBP_TM_SPMREQ z
                        WHERE Z.SPM_PAT_ID = A.SPM_PAT_ID
                          AND Z.SPM_EXM_REASON = 'Diagnosis'
                        )
-- 
UNION
SELECT A.SPM_PAT_ID, A.SPM_COL_DATE, A.SPM_ID_CODE, 
       B.RES_DATE, B.RES_SMEAR,
       row_number()
          over ( partition by a.spm_pat_id order by spm_col_date ) spm_pat_seq
FROM TBP_TM_SPMREQ A, TBP_TD_SPMRES B
WHERE SPM_ID = RES_SPM_ID (+)
and   A.SPM_EXM_REASON != 'Diagnosis'
order by SPM_PAT_ID, spm_col_date

))
group by spm_pat_id
/

