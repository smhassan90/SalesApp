create trigger BI_KPI_SD_INCENTIVE
  before insert
  on KPI_SD_INCENTIVE
  for each row
  begin
  if :NEW."KID_ID" is null then
    select "KP_INC_MASTER_SEQ".nextval into :NEW."KID_ID" from dual;
  end if;
end;
/

