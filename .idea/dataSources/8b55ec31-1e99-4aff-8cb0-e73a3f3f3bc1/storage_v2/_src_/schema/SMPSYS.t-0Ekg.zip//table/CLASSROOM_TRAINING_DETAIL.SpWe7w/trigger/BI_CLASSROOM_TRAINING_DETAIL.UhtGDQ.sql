create trigger BI_CLASSROOM_TRAINING_DETAIL
  before insert
  on CLASSROOM_TRAINING_DETAIL
  for each row
  begin
  if :new.CRTD_ID is null then
    select SQ_CLASSROOM_TRAINING_DETAIL.nextval INTO :new.CRTD_ID
    from dual;
  end if;
    select crt_cp_code into :new.crtd_cp_code
    from classroom_training_master
    where crt_id = :new.crtd_crt_id;

end;
/

