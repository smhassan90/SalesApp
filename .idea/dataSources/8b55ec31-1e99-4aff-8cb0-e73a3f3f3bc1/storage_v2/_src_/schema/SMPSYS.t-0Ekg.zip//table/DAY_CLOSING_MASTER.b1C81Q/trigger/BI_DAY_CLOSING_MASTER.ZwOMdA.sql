create trigger BI_DAY_CLOSING_MASTER
  before insert
  on DAY_CLOSING_MASTER
  for each row
  begin
    select SQ_DAY_CLOSING_MASTER.nextval INTO :new.DCM_ID
    from dual;
end;
/

