create trigger TRG_PINS_SAL_ITMPR
  before insert
  on SAL_ITMPR_VISIT_INFO
  for each row
  begin
  SELECT SAL_ITMPR_VISIT_INFO_SEQ.NEXTVAL INTO :NEW.ITM_VI_CODE FROM DUAL;
end;
/

