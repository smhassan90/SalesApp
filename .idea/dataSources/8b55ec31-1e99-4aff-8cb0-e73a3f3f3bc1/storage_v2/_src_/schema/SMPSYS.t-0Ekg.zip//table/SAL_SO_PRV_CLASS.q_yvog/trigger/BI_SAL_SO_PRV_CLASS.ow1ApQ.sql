create trigger BI_SAL_SO_PRV_CLASS
  before insert
  on SAL_SO_PRV_CLASS
  for each row
  begin
    select SQ_SAL_SO_PRV_CLASS.nextval INTO :new.SPC_ID
    from dual;
end;
/

