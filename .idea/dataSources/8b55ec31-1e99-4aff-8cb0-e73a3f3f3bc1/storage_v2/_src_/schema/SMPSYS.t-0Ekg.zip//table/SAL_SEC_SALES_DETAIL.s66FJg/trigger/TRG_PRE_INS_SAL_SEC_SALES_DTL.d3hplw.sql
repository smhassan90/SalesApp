create trigger TRG_PRE_INS_SAL_SEC_SALES_DTL
  before insert
  on SAL_SEC_SALES_DETAIL
  for each row
  begin
  SELECT SQ_SAL_SEC_SALES_DETAIL.NEXTVAL INTO :NEW.DSS_ID FROM DUAL;
end;
/

