create trigger TRG_BI_SAL_SM_TRAINING_PACKAGE
  before insert
  on SAL_SM_TRAINING_PACKAGE
  for each row
  begin
 SELECT SQ_sal_sm_training_package.NEXTVAL INTO :NEW.TPM_ID FROM DUAL;
 end;

/

