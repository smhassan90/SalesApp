create trigger TRG_PREINS_SAL_SD_PRVTRAING
  before insert
  on SAL_SD_PRV_TRAINING
  for each row
  begin
IF :NEW.DPT_ID IS NULL THEN
   :NEW.DPT_ID := :NEW.DPT_MPV_CODE||'-'||:NEW.DPT_MPT_CODE||'-'||:NEW.DPT_EFF_DATE;
END IF;
END;
/

