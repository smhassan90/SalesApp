create trigger IPC_ARC_ACTIVITY_TRG
  before insert
  on IPC_ARC_ACTIVITY
  for each row
  begin
  SELECT IPC_ARC_DETAIL_SEQ.NEXTVAL INTO :NEW.IPC_ARC_ID FROM DUAL;
end;
/

