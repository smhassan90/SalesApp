create trigger BI_IPC_SO_ACTIVITY
  before insert
  on IPC_SO_ACTIVITY
  for each row
  begin
  for c1 in (
    select IPC_SO_ACTIVITY_SEQ.nextval next_val
    from dual
  ) loop
    :new.MAC_ID :=  c1.next_val;
  end loop;
end;
/

