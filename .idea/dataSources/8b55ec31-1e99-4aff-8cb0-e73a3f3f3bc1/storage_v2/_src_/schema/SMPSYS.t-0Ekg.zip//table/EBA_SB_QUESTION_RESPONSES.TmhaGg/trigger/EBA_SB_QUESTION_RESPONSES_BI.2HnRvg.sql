create trigger EBA_SB_QUESTION_RESPONSES_BI
  before insert
  on EBA_SB_QUESTION_RESPONSES
  for each row
  begin
    if inserting then
        if :new.id is null then
            :new.id := eba_sb.gen_id();
        end if;
    end if;
end;
/

