create trigger QA_CLIENT_DETAIL_TR_TRG
  before insert
  on QA_CLIENT_DETAIL_TR
  for each row
  begin
  SELECT QA_CLIENT_DETAIL_TR_SEQ.NEXTVAL INTO :NEW.TR_DTL_ID FROM DUAL;
end;
/

