create trigger MPV_STS_DATE
  before update of MPV_TYPE
  on SAL_SM_PROVIDER
  for each row
  DECLARE
MSG VARCHAR2(100);
BEGIN
  IF ( :OLD.MPV_FLAG <> :NEW.MPV_FLAG  ) THEN
       :NEW.MPV_STS_DATE := SYSDATE;
  end if;
END;
/

