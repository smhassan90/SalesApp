create trigger TRG_BI_FNCL_MONTH
  before insert
  on FINANCIAL_MONTH
  for each row
  begin
  SELECT SQ_FINANCIAL_MONTH.NEXTVAL INTO :NEW.REC_ID FROM DUAL;
end;
/

