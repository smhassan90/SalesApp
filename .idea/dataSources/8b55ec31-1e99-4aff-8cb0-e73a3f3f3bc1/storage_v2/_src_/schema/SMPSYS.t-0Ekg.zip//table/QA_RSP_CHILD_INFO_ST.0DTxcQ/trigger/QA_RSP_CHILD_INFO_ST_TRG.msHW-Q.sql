create trigger QA_RSP_CHILD_INFO_ST_TRG
  before insert
  on QA_RSP_CHILD_INFO_ST
  for each row
  begin
  IF :NEW.RSP_CH_ID IS NULL THEN
    SELECT QA_QST_INFO_ST_SEQ.NEXTVAL INTO :NEW.RSP_CH_ID FROM DUAL;
  END IF;
end;

/

