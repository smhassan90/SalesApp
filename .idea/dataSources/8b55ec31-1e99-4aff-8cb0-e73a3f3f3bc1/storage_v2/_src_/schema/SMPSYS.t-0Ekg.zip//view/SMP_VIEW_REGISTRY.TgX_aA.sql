create view SMP_VIEW_REGISTRY as
  SELECT           LPAD(' ',3*(level-1)) "FILLER", key "KEY", value "VALUE"
  FROM             smp_vdr_registry
  START WITH       id = 100
  CONNECT BY PRIOR id = parent
/

comment on table SMP_VIEW_REGISTRY
is 'Internal list of all objects known in the framework'
/

