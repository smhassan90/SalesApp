create trigger TRG_PRE_INS_ISR_XO_COL_TYPE
  before insert
  on ISR_XO_COL_TYPE
  for each row
  begin
SELECT SQ_ISR_XO_COL_TYPE.NEXTVAL INTO :NEW.CT_CODE FROM DUAL;
end;
/

