create trigger TRG_PRE_INS_SAL_SD_POLICY
  before insert
  on SAL_SD_POLICY
  for each row
  begin
SELECT SQ_SAL_SD_POLICY.NEXTVAL INTO :NEW.DPY_ID FROM DUAL;
end;
/

