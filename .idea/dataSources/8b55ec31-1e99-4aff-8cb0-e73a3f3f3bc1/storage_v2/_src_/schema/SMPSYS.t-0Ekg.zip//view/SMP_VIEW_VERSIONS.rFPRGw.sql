create view SMP_VIEW_VERSIONS as
  SELECT DECODE(v1.app_name,'/com/oracle/Sysman/EM/EMSystem','EM Framework',v1.app_name) "COMPONENT", DECODE(v2.version,2,'2.1.0.0.0',3,'2.1.0.1.0',4,'2.2.0.0.0',5,'9.0.0.0.0','*error:'||v2.version||'*') "VERSION", v1.upd_in_progress "LOCKED"
  FROM   smp_vds_repos_version v1, smp_vds_repos_version v2
  WHERE  v2.app_name = '/com/oracle/Sysman/EM/EMSystem'
/

comment on table SMP_VIEW_VERSIONS
is 'All repository components currenty created in the repository'
/

