create materialized view VU_HIERARCHY_12232014
refresh force on demand
  as
    SELECT DISTINCT
       RZCOMPANY company_code,
       REGION region_code,     GET_LEVEL_NAME_BKP('01',REGION)         region_name,
       ZONE ZONE_CODE,         GET_LEVEL_NAME_BKP('01',zone)           ZONE_NAME,
       ZONE OFFICE_CODE,       GET_LEVEL_NAME_BKP('01',zone)           OFFICE_NAME,
       AREA territory_code,    GET_LEVEL_NAME_BKP('01',area)           territory_name,
       TOWN town_code,         GET_LEVEL_NAME_BKP('01',town)           town_name,
       CITYCODE CITY_CODE,     GET_LEVEL_NAME_BKP('01',cityCODE)       city_name,
       TEHSILCODE TEHSIL_CODE, GET_LEVEL_NAME_BKP('01',TEHSILCODE)     TEHSIL_NAME,
       ATYPE      AREA_code, DECODE(ATYPE,'U','Urban','Rural')     Area_type,
       DISTRICT_CODE DIST_CODE, DISTRICT_NAME                      DIST_NAME,
       PROVINCE_CODE PROV_CODE, GET_LEVEL_NAME_BKP('01',PROVINCE_CODE) PROV_NAME

FROM
 ( SELECT DISTINCT DSL_CP_CODE RZCOMPANY,
         DSL_MSL_CODE REGION, DSL_SUB_CODE ZONE
  FROM SAL_SD_SALES_LEVEL_BKP RR
  WHERE DSL_MSL_CODE LIKE 'R%'
    AND DSL_SUB_CODE LIKE 'Z%'
    AND dsl_eff_date  = (select max(dsl_eff_date)
                         from SAL_SD_SALES_LEVEL_BKP R
                         where R.Dsl_cp_code = RR.dsl_cp_code
                         AND   R.DSL_MSL_CODE LIKE 'R%'
                         AND   R.DSL_SUB_CODE = RR.DSL_SUB_CODE)
 ) A,
 ( SELECT DISTINCT DSL_CP_CODE ACOMPANY,
         DSL_MSL_CODE AREA_ZONE, DSL_SUB_CODE AREA
  FROM SAL_SD_SALES_LEVEL_BKP ZZ
  WHERE DSL_MSL_CODE LIKE 'Z%'
    AND DSL_SUB_CODE LIKE 'A%'
    AND dsl_eff_date  = (select max(dsl_eff_date)
                         from SAL_SD_SALES_LEVEL_BKP S
                         where S.Dsl_cp_code = ZZ.dsl_cp_code
                         AND   S.DSL_MSL_CODE LIKE 'Z%'
                         AND   S.DSL_SUB_CODE = ZZ.DSL_SUB_CODE)
 ) B,
 ( SELECT DISTINCT DSL_CP_CODE TCOMPANY,
         DSL_MSL_CODE TOWN_AREA, DSL_SUB_CODE TOWN
  FROM SAL_SD_SALES_LEVEL_BKP C
  WHERE DSL_MSL_CODE LIKE 'A%'
    AND DSL_SUB_CODE LIKE 'T%'
    AND dsl_eff_date  = (select max(dsl_eff_date)
                         from SAL_SD_SALES_LEVEL_BKP B
                         where B.Dsl_cp_code = C.dsl_cp_code
                         AND   B.DSL_MSL_CODE LIKE 'A%'
                         AND   B.DSL_SUB_CODE = C.DSL_SUB_CODE)
 ) C,
 ( SELECT DISTINCT DSL_CP_CODE CTCOMPANY,
         DSL_MSL_CODE CITYCODE, DSL_SUB_CODE TOWNCODE
  FROM SAL_SD_SALES_LEVEL_BKP D
  WHERE DSL_MSL_CODE LIKE 'C%'
  AND   DSL_SUB_CODE LIKE 'T%'
  AND dsl_eff_date  = (select max(dsl_eff_date)
                         from SAL_SD_SALES_LEVEL_BKP B
                         where B.Dsl_cp_code = D.dsl_cp_code
                         AND   B.DSL_MSL_CODE LIKE 'C%'
                         AND   B.DSL_SUB_CODE = D.DSL_SUB_CODE)
 ) D,
 ( SELECT DISTINCT DSL_CP_CODE TCCOMPANY,
         DSL_MSL_CODE TEHSILCODE, DSL_SUB_CODE  TCCODE
  FROM SAL_SD_SALES_LEVEL_BKP E
  WHERE DSL_MSL_CODE LIKE 'L%'
  AND   DSL_SUB_CODE LIKE 'C%'
  AND   dsl_eff_date  = (select max(dsl_eff_date)
                         from SAL_SD_SALES_LEVEL_BKP B
                         where B.Dsl_cp_code = E.dsl_cp_code
                         AND   B.DSL_MSL_CODE LIKE 'L%'
                         AND   B.DSL_SUB_CODE = E.DSL_SUB_CODE)
 ) E,
( SELECT DISTINCT DSL_CP_CODE DTCOMPANY,
         DSL_MSL_CODE DISTCODE, DSL_SUB_CODE THCODE
  FROM SAL_SD_SALES_LEVEL_BKP F
  WHERE DSL_MSL_CODE LIKE 'D%'
  AND   DSL_SUB_CODE LIKE 'L%'
  AND   dsl_eff_date  = (select max(dsl_eff_date)
                         from SAL_SD_SALES_LEVEL_BKP B
                         where B.Dsl_cp_code = F.dsl_cp_code
                         AND   B.DSL_MSL_CODE LIKE 'D%'
                         AND   B.DSL_SUB_CODE = F.DSL_SUB_CODE)
 ) F,
 ( SELECT DISTINCT DSL_CP_CODE DTCOMPANY,
         DSL_MSL_CODE ATYPE, DSL_SUB_CODE THCODE
  FROM SAL_SD_SALES_LEVEL_BKP F
  WHERE DSL_MSL_CODE IN ('R','U')
  AND   DSL_SUB_CODE LIKE 'L%'
  AND   dsl_eff_date  = (select max(dsl_eff_date)
                         from SAL_SD_SALES_LEVEL_BKP B
                         where B.Dsl_cp_code = F.dsl_cp_code
                         AND   B.DSL_MSL_CODE IN ('R','U')
                         AND   B.DSL_SUB_CODE = F.DSL_SUB_CODE)
 ) H,DISTRICT_MASTER G
WHERE A.RZCOMPANY  = B.ACOMPANY
  AND A.ZONE       = B.AREA_ZONE
  AND B.ACOMPANY   = C.TCOMPANY
  AND B.AREA       = C.TOWN_AREA
  AND C.TCOMPANY   = D.CTCOMPANY
  AND C.TOWN       = D.TOWNCODE
  AND D.CTCOMPANY  = E.TCCOMPANY
  AND D.CITYCODE   = E.TCCODE
  AND E.TCCOMPANY  = F.DTCOMPANY
  AND E.TEHSILCODE = F.THCODE
  AND F.DISTCODE   = G.DISTRICT_CODE
  AND H.THCODE  (+)= F.THCODE







/

