create materialized view TB_REGISTER_TB03
refresh force on demand
  as
    SELECT tc_id,
  TC_ZON_CODE ZONE,
  tc_str_date,
  tc_reg_date,
  tc_pat_id,
  pat_code,
  pat_name,
  pat_gender,
  pat_age,
  PAT_REF_SOURCE,
  pat_add,
  pat_nic,
  pat_contact,
  tc_otl_code,
  GET_MPV_OTL_DESC(tc_otl_code, tc_cp_code, 'O','WO') otl_desc,
  tc_MPV_code,
  GET_MPV_OTL_DESC(TC_MPV_CODE, tc_cp_code, 'P','WO') PRV_desc,
  tc_str_date TRT_STRT_DT,
  CASE
    WHEN TC_PH1_CAT = 'New Case'
    THEN 'CAT-1'
    ELSE 'CAT-2'
  END REGINMEN,
  tc_pat_class,
  tc_pat_type,
  M0,
  M1,
  M2,
  M3,
  M4,
  M5,
  TC_OTC_CODE,
  TC_OTC_DATE,
  TC_CHO_ID CHO,
  TC_CHO_ID
  || ' - '
  || GET_LEVEL_NAME('01',TC_CHO_ID) CHONAME,
  TC_TX_NAME
FROM TBP_TD_TC,
  TBP_SO_PATIENT,
  VU_TBP_PAT_SPM_RES_SUM
WHERE TC_PAT_ID = PAT_ID (+)
AND TC_PAT_ID   = SPM_PAT_ID (+)








/

