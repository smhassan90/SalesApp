create trigger TRG_BI_FNCL_CALENDAR
  before insert
  on FINANCIAL_CALENDAR
  for each row
  begin
     SELECT SQ_FINANCIAL_CALENDAR.NEXTVAL INTO :NEW.CAL_ID FROM DUAL;
  end;
/

