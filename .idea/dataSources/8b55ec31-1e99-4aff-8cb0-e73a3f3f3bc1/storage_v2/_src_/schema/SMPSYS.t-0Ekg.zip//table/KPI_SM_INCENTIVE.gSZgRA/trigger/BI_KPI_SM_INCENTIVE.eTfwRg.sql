create trigger BI_KPI_SM_INCENTIVE
  before insert
  on KPI_SM_INCENTIVE
  for each row
  begin
  if :NEW."KIM_ID" is null then
    select "KPI_SM_INCENTIVE_SEQ".nextval into :NEW."KIM_ID" from dual;
  end if;
end;
/

