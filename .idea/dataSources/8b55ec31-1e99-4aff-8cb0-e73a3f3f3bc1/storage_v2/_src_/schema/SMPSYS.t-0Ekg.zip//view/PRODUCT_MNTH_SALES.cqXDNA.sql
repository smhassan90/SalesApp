create view PRODUCT_MNTH_SALES as
  SELECT /*+ USE_HASH(PCM,ISIM,ISIC,SSCS,ISI,STDSH) */
DISTINCT DSL_CUS_CODE,
         DSL_smp_twn,
          SUM((STDSH.dsl_sale_qty * ISI.DIT_UNIT)) SALES,

         CASE

           WHEN SUM((STDSH.dsl_sale_qty * ISI.DIT_UNIT)) <= 0 THEN
            '0-LESS'
           WHEN SUM((STDSH.dsl_sale_qty * ISI.DIT_UNIT)) BETWEEN '1' AND '50' THEN
            '1-50'
           WHEN SUM((STDSH.dsl_sale_qty * ISI.DIT_UNIT)) BETWEEN '51' AND
                '100' THEN
            '51-100'
           WHEN SUM((STDSH.dsl_sale_qty * ISI.DIT_UNIT)) BETWEEN '101' AND
                '150' THEN
            '101-150'
           WHEN SUM((STDSH.dsl_sale_qty * ISI.DIT_UNIT)) BETWEEN '151' AND
                '200' THEN
            '151-200'

           WHEN SUM((STDSH.dsl_sale_qty * ISI.DIT_UNIT)) BETWEEN '201' AND
                '250' THEN
            '201-250'
           WHEN SUM((STDSH.dsl_sale_qty * ISI.DIT_UNIT)) BETWEEN '251' AND
                '300' THEN
            '251-300'

           WHEN SUM((STDSH.dsl_sale_qty * ISI.DIT_UNIT)) BETWEEN '301' AND
                '350' THEN
            '301-350'
           WHEN SUM((STDSH.dsl_sale_qty * ISI.DIT_UNIT)) BETWEEN '351' AND
                '400' THEN
            '351-400'

           WHEN SUM((STDSH.dsl_sale_qty * ISI.DIT_UNIT)) BETWEEN '401' AND
                '450' THEN
            '401-450'
           WHEN SUM((STDSH.dsl_sale_qty * ISI.DIT_UNIT)) BETWEEN '451' AND
                '500' THEN
            '451-500'

           WHEN SUM((STDSH.dsl_sale_qty * ISI.DIT_UNIT)) BETWEEN '501' AND
                '550' THEN
            '501-550'
           WHEN SUM((STDSH.dsl_sale_qty * ISI.DIT_UNIT)) BETWEEN '551' AND
                '600' THEN
            '551-600'

           ELSE
            '>600'
         END BANDS,

         TO_CHAR(STDSH.DSL_DATE, 'MON-RRRR') MNTH
  FROM SAL_TO_DIS_SALES_HISTORY STDSH,
       INV_SD_ITEM              ISI,
       SAL_SO_CYP_SETUP         SSCS,
       INV_SO_ITEM_CATEGORY     ISIC,
       INV_SM_ITEM              ISIM,
       PZL_CUSTOMER_MAP         PCM
 WHERE ISI.DIT_CODE = STDSH.DSL_DIT_CODE
   AND STDSH.DSL_CP_CODE = '01'
   AND isim.mit_cp_code = isi.dit_cp_code
   AND isim.mit_code = isi.dit_mit_code
   AND sscs.cyp_cp_code = isi.dit_cp_code
   AND isic.ctg_cp_code = ISI.DIT_CP_CODE
   AND PCM.PZL_CUST_CAT = STDSH.DSL_CUS_CAT
   AND pcm.pzl_cust_type = STDSH.Dsl_Cus_Type
   AND pcm.pzl_cust_map = 'Retail Chemist'
   AND ISIC.CTG_CODE = ISI.DIT_CTG_CODE
   AND sscs.cyp_dit_code = isi.dit_code
   AND isi.dit_code LIKE 'STH%'
   AND ISI.DIT_CP_CODE = STDSH.DSL_CP_CODE
   --AND STDSH.DSL_DATE >= '01-JAN-2012'
   AND STDSH.DSL_DATE BETWEEN '01-JAN-2011' AND '31-MAR-2013'
 GROUP BY DSL_CUS_CODE,
          DSL_smp_twn,
           TO_CHAR(STDSH.DSL_DATE, 'MON-RRRR')
/

