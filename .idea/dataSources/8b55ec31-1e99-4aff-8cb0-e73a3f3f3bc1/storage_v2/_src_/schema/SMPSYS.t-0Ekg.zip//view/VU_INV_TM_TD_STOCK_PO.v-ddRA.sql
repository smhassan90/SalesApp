create view VU_INV_TM_TD_STOCK_PO as
  select MST_CP_CODE, MST_NUM, MST_DATE, MST_TYPE, MST_REF_NUM,
       DST_DIT_CODE, DST_REF_NUM, DST_QTY, DST_RATE, DST_AMT
from inv_tm_stock,  inv_td_stock
WHERE (inv_tm_stock.mst_num = inv_td_stock.dst_mst_num
  and  inv_tm_stock.mst_cp_code = inv_td_stock.dst_cp_code )
  and  MST_TYPE = 'SP'
/

