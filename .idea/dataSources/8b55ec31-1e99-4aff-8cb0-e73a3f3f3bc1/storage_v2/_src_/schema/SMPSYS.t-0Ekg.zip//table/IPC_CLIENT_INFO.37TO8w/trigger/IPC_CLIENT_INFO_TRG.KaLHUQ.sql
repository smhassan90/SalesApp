create trigger IPC_CLIENT_INFO_TRG
  before insert
  on IPC_CLIENT_INFO
  for each row
  begin
  IF :NEW.ID IS NULL THEN
    SELECT IPC_CLIENT_INFO_SEQ.NEXTVAL INTO :NEW.ID FROM DUAL;
  END IF;
end;

/

