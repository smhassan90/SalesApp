create view OUTLET_OPEN_GSTYPE_QUALIF as
  select po.dpo_otl_code,decode(max(tr.mpt_rank),'60','GS PLUS','59','FHC','55','MOBILE UNIT',
       '50','GS1','45','ASS','40','GS2','30','GS3','20','GS4','NGS'), pm.mpv_qualif,
       pm.mpv_gender,so.otl_cp_code
from   sal_sd_prv_training pt, sal_sd_prv_outlet po, sal_sm_prv_type tr,
       sal_so_outlet so, sal_sm_provider pm
where  (pt.dpt_mpv_code = po.dpo_mpv_code
and    pt.dpt_cp_code = po.dpo_cp_code)
and    (tr.mpt_code = pt.dpt_mpt_code
and    tr.mpt_cp_code = pt.dpt_cp_code)
and    (so.otl_code = po.dpo_otl_code
and    so.otl_cp_code = po.dpo_cp_code)
and    (pm.mpv_code = po.dpo_mpv_code
and    pm.mpv_cp_code = po.dpo_cp_code)
and    so.otl_flag = 'Y'
and    pm.mpv_flag = 'Y'
and    so.otl_type in ('CL','HP','MH')
and    po.dpo_lft_date is null
and    pt.dpt_eff_date = (select max(prvt.dpt_eff_date) from sal_sd_prv_training prvt
     where prvt.dpt_mpv_code = po.dpo_mpv_code
     and   prvt.dpt_cp_code  = po.dpo_cp_code)
group by po.dpo_otl_code,pm.mpv_qualif,pm.mpv_gender,so.otl_cp_code
/

