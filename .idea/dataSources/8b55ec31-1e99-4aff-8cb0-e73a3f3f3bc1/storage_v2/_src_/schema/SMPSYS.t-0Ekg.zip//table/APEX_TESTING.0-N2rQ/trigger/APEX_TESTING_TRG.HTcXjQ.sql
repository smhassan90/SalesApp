create trigger APEX_TESTING_TRG
  before insert
  on APEX_TESTING
  for each row
  begin
  IF :NEW.ID IS NULL THEN
    SELECT APEX_TESTING_SEQ.NEXTVAL INTO :NEW.ID FROM DUAL;
  END IF;
end;
/

