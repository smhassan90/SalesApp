create trigger BI_ADC_TM_PRIZE
  before insert
  on ADC_TM_PRIZE
  for each row
  begin
 SELECT SQ_ADC_TM_PRIZE.NEXTVAL INTO :NEW.ATP_ID FROM DUAL;
 end;
/

