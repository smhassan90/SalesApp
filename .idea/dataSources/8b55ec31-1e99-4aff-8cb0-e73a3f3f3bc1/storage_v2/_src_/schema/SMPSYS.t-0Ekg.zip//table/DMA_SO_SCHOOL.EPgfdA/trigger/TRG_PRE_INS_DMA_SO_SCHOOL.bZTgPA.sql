create trigger TRG_PRE_INS_DMA_SO_SCHOOL
  before insert
  on DMA_SO_SCHOOL
  for each row
  begin
 SELECT SQ_DMA_SO_SCHOOL.NEXTVAL INTO :NEW.DSS_ID FROM DUAL;
 end;
/

