create trigger ARC_MASTER_MID_TRG
  before insert
  on ARC_MASTER
  for each row
  BEGIN
  IF  :NEW.MID IS NULL THEN
      SELECT ARC_SEQ_ID.NEXTVAL INTO :NEW.MID FROM DUAL;
  END IF;  
END;
/

