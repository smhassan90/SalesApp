create trigger EBA_SB_SECTIONS_BIU
  before insert or update
  on EBA_SB_SECTIONS
  for each row
  begin
    if :new.tags is not null then
        :new.tags := eba_sb_fw.tags_cleaner(:new.tags);
    end if;
    if inserting then
        if :new.id is null then
            :new.id := eba_sb.gen_id();
        end if;
        :new.created_by := nvl(v('APP_USER'),user);
        :new.created := localtimestamp;
        :new.row_version_number := 1;
    elsif updating then
        :new.row_version_number := nvl(:old.row_version_number,1) + 1;
    end if;
    :new.updated_by := nvl(v('APP_USER'),user);
    :new.updated := localtimestamp;
    eba_sb_fw.tag_sync(
        p_new_tags      => :new.tags,
        p_old_tags      => :old.tags,
        p_content_type  => 'SECTIONS',
        p_content_id    => :new.id );
end;
/

