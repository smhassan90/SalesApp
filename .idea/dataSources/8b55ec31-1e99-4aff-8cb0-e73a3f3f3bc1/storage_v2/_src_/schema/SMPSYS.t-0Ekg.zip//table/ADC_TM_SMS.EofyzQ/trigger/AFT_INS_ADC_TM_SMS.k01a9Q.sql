create trigger AFT_INS_ADC_TM_SMS
  after insert
  on ADC_TM_SMS
  for each row
  DECLARE
  VSQLCODE VARCHAR2(2000);
  VSQLERRM VARCHAR2(2000);
  V_ATS_ID NUMBER;
  V_A NUMBER;
  V_B NUMBER;
  V_C NUMBER;
  V_D NUMBER;
  V_E NUMBER;  
  V_F NUMBER;
  V_G NUMBER;
  V_H NUMBER;
  V_I NUMBER;
  V_J NUMBER;
  V_K NUMBER;
BEGIN
-- FIND VALUES RECEIVED FROM PROVIDER IN SMS TABLE
    SELECT A, B, C, D, E, F, G, H, I, J, K  INTO V_A, V_B, V_C, V_D, V_E, V_F, V_G, V_H, V_I, V_J, V_K
    FROM ADC.WEEKLYINFOSMS
    WHERE (OTL, PRV) = (SELECT ASC_OTL_CODE, ASC_MPV_CODE
                        FROM ADC_SM_CLIENT
                        WHERE ASC_ID = :NEW.ATS_ASC_ID)
      AND WK = :NEW.ATS_WEEK_NO;

      FOR A IN ( SELECT ASP_ID, ASP_CODE, ASP_DESC
                  FROM  ADC_SO_PARAMETER, ADC_SO_LINK
                  WHERE ASP_ID     = ASL_ASP_ID
                  AND   ASP_FLAG   = 'Y'
                  AND   ASL_PRJ_ID = ( SELECT  ASC_PRJ_ID 
                                       FROM    ADC_SM_CLIENT
                                       WHERE   ASC_ID = :NEW.ATS_ASC_ID )
                 ) 
       LOOP        
         BEGIN
          INSERT INTO ADC_TD_SMS ( ADS_ATS_ID, ADS_ASP_ID, ADS_INS_USR, ADS_INS_DT, ADS_VALUES )
          VALUES (:NEW.ATS_ID, A.ASP_ID, :NEW.ATS_INS_USR, :NEW.ATS_INS_DT,
               DECODE(A.ASP_CODE,'A', V_A, 'B', V_B, 'C', V_C, 'D', V_D, 'E', V_E, 
                                 'F', V_F, 'G', V_G, 'H', V_H, 'I', V_I, 'J', V_J,'K', V_K, null)
          );
         EXCEPTION WHEN OTHERS THEN VSQLERRM := SQLERRM; VSQLCODE := SQLCODE;
                  INSERT INTO APPLICATION_ERRORS (TABLE_NAME, TEXT, ERROR_TEXT, ERROR_NUM)
                  VALUES ('ADC_TM_SMS', 'AFTER INSERT TRIGGER FAILED AT INSERT', VSQLERRM, VSQLCODE);
         END;
       END LOOP;
  EXCEPTION  WHEN OTHERS THEN VSQLERRM := SQLERRM; VSQLCODE := SQLCODE;
      INSERT INTO APPLICATION_ERRORS (TABLE_NAME, TEXT, ERROR_TEXT, ERROR_NUM)
      VALUES ('ADC_TM_SMS', 'SELECT ADC.WEEKLYINFOSYS ' || :NEW.ATS_ASC_ID, VSQLERRM, VSQLCODE);
END;
/

