create trigger FN_SUBWARD_DB_TRG
  before insert
  on FN_SUBWARD_DB
  for each row
  BEGIN
    SELECT FN_SUBWARD_DB_SEQ.NEXTVAL INTO :NEW.FN_ID
    FROM DUAL;
END;
/

