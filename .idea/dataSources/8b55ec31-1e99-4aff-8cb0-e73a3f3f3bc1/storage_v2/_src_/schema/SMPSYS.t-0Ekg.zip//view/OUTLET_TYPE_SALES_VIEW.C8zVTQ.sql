create view OUTLET_TYPE_SALES_VIEW as
  (SELECT m.msl_cp_code, m.msl_date, t.dsl_dit_code, og.gs_type, og.provider_qualif,
         sum(t.dsl_qty) qty
  from   sal_tm_sales m , sal_td_sales t ,outlet_gstype_qualif og
  where  m.msl_num          = t.dsl_msl_num
  and    m.msl_cp_code      = t.dsl_cp_code
  and    m.msl_type         = 'DS'
  and    m.msl_status       = 'P'
  and    msl_otl_code       = og.outlet_code
  group by m.msl_cp_code, m.msl_date, t.dsl_dit_code, og.gs_type, og.provider_qualif)
/

