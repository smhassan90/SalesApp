create trigger BI_SAL_TM_TRAINING_MATERIAL
  before insert
  on SAL_TM_TRAINING_MATERIAL
  for each row
  begin
    select SQ_SAL_TM_TRAINING_MATERIAL.nextval INTO :new.TMM_ID
    from dual;
end;
/

