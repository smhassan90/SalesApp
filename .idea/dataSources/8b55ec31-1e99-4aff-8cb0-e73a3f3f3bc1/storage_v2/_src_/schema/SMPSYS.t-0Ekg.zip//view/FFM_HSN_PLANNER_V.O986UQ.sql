create view FFM_HSN_PLANNER_V as
  select 
hsp.HS_ID,
DECODE(get_staff_loc(hsp.HS_STAFF_CODE),
                     'R001','R001-Karachi',
                     'R002','R002-Sukkur',
                     'R003','R003-Bahawalpur',
                     'R004','R004-Multan',
                     'R005','R005-Faislabad',
                     'R006','R006-Lahore',
                     'R007','R007-Gujranwala',
                     'R008','R008-Islamabad',
                     'R009','R009-Peshawar',
                     get_staff_loc(hsp.HS_STAFF_CODE)) Region,
hsp.HS_STAFF_CODE,
GET_STAFF_NAME('01',hsp.HS_STAFF_CODE) Staff,
hsp.hs_activity Activity,
hsp.hs_act_date Activity_date,
hsp.hs_act_time Activity_time,
hsp.HS_MPV_CODE,
mpv.mpv_alias,
hsp.hs_time_day  Time_Of_Day,
hsp.hs_area Area,
hsp.HS_WORKER,
GET_STAFF_NAME('01',hsp.HS_WORKER) WorkerName 
from 
hs_workplan hsp
left join sal_sm_provider mpv on (hsp.hs_mpv_code = mpv.mpv_code and mpv.mpv_cp_code = '01')
where 
upper(hsp.HS_DEPT_TYPE) = 'NETWORK'
order by region, HS_STAFF_CODE, Activity_date
/

