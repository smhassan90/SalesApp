create trigger DEPENDENTS_T
  before insert or update
  on DEPENDENTS
  for each row
  begin 
    -- 
    -- maintain pk and timestamps 
    -- 
    if inserting and :new.id is null then 
        select to_number(sys_guid(),'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX') into :new.id from dual; 
    end if; 
end;

/

