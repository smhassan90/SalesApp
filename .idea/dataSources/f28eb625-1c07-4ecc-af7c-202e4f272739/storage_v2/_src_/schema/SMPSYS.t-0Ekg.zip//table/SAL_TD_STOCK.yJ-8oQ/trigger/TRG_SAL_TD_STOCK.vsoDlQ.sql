create trigger TRG_SAL_TD_STOCK
  before insert
  on SAL_TD_STOCK
  for each row
  DECLARE
tmpVar NUMBER;
BEGIN
   tmpVar := 0;

   SELECT SAL_STK_TD_SEQ.NEXTVAL INTO tmpVar FROM dual;
   :NEW.TD_ID:= tmpVar;

END;
/

