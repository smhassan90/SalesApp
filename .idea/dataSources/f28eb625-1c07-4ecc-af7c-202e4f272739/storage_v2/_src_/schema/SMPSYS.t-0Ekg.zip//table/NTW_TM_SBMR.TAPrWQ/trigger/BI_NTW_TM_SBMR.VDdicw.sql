create trigger BI_NTW_TM_SBMR
  before insert
  on NTW_TM_SBMR
  for each row
  begin
  SELECT SQ_NTW_TM_SBMR.NEXTVAL INTO :NEW.SBMRM_ID FROM DUAL;
end;
/

