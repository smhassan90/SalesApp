create view PS_MONTHLY_NOVA3S_NOVAPILLS as
  select  item_code,month_no,month_name Month,sum(sale_qty*3) Quantity from ps_monthly_nova3s
 where  item_code ='NOP002'
 group by item_Code,month_name,month_no
union
select  item_code,month_no,month_name Month,sum(sale_qty) Quantity from ps_monthly_novapills
 where  item_code ='NOP001'
 group by item_Code,month_name,month_no
 order by 2
/

