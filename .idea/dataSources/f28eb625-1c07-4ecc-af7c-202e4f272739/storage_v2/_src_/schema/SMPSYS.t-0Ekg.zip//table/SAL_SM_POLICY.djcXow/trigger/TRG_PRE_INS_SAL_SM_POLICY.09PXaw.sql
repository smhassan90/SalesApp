create trigger TRG_PRE_INS_SAL_SM_POLICY
  before insert
  on SAL_SM_POLICY
  for each row
  begin
SELECT SQ_SAL_SM_POLICY.NEXTVAL INTO :NEW.MPY_ID FROM DUAL;
end;
/

