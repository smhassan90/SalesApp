create materialized view MV_STAFF_VISITS
refresh force on demand
  as
    SELECT CP_CODE, REGION_CODE, REGION_NAME,
       OFFICE_CODE, OFFICE_NAME,
       ZONE_CODE, ZONE_NAME,
       LOC_CODE, get_level_name(cp_code, loc_code) loc_name,
       VISIT_MONTH,
       SUM(DECODE(TYPE,'VI',TOT_VI,0)) VI_VISIT,
       SUM(DECODE(TYPE,'DS',TOT_VI,0)) DS_VISIT
FROM (
    --- query to count visit information

     select mvi_cp_code CP_CODE, mvi_mlc_code LOC_CODE, office_code, office_name, 
             ZONE_CODE, zone_name, REGION_CODE, REGION_NAME,
             Visit_Month, 'VI' "TYPE", count(*) TOT_VI
      from (
            select distinct 
                   mvi_cp_code, office_code, office_name, zone_code, zone_name,  region_code, region_name,
                   mvi_mlc_code, mvi_otl_code, mvi_mpv_code, mvi_date,
                   CAL_MONTH visit_MONTH
            from sal_sm_visit_info, FINANCIAL_CALENDAR, sal_sd_twn_otl, vu_hierarchy
            where MVI_CP_CODE = CAL_CP_CODE
            AND   MVI_DATE BETWEEN CAL_DATE_FM AND CAL_DATE_TO
            AND   MVI_OTL_CODE = SST_OTL_CODE
            AND   MVI_CP_CODE  = SST_CP_CODE
            AND   SST_TWN_CODE = TOWN_CODE
            AND   SST_CP_CODE  = COMPANY_CODE
            AND   SST_EFF_DATE = (SELECT MAX(SST_EFF_DATE) 
                                  FROM SAL_SD_TWN_OTL B
                                  WHERE B.SST_OTL_CODE = sal_sd_twn_otl.SST_OTL_CODE 
                                  AND   B.SST_CP_CODE  = sal_sd_twn_otl.SST_CP_CODE
                                 )
            UNION
            select distinct
                   msl_cp_code, office_code, office_name, zone_code, zone_name,  region_code, region_name,
                   msl_inv_loc, msl_otl_code, msl_mpv_code, msl_date,
                   CAL_MONTH visit_MONTH
            from sal_tm_sales, FINANCIAL_CALENDAR, sal_sd_twn_otl, vu_hierarchy
            where msl_cp_code = '01'
            and   msl_type    = 'DS'
            AND   MSL_CP_CODE = CAL_CP_CODE
            AND   MSL_DATE BETWEEN CAL_DATE_FM AND CAL_DATE_TO
            AND   MSL_OTL_CODE = SST_OTL_CODE
            AND   MSL_CP_CODE  = SST_CP_CODE
            AND   SST_TWN_CODE = TOWN_CODE
            AND   SST_CP_CODE  = COMPANY_CODE
            AND   SST_EFF_DATE = (SELECT MAX(SST_EFF_DATE) 
                                  FROM SAL_SD_TWN_OTL B
                                  WHERE B.SST_OTL_CODE = sal_sd_twn_otl.SST_OTL_CODE 
                                  AND   B.SST_CP_CODE  = sal_sd_twn_otl.SST_CP_CODE
                                 )
          )
      group by mvi_cp_code, mvi_mlc_code, office_code, office_name, 
               ZONE_CODE, zone_name, REGION_CODE, REGION_NAME,Visit_Month
      union
    --- query to count sales_visit
      select msl_cp_code,  msl_inv_loc, office_code, office_name, zone_code, zone_name, region_code, region_name,
             CAL_MONTH Sales_Month,'DS', count(*) TOT_DS
      from (
            select distinct
                   msl_cp_code, office_code, office_name, zone_code, zone_name,  region_code, region_name,
                   msl_inv_loc, msl_otl_code, msl_mpv_code, msl_date,
                   CAL_MONTH
            from sal_tm_sales, sal_td_sales, FINANCIAL_CALENDAR, sal_sd_twn_otl, vu_hierarchy
            where msl_num = dsl_msl_num
            and   msl_cp_code = dsl_cp_code
            and   msl_cp_code = '01'
            and   msl_type    = 'DS'
            AND   MSL_CP_CODE = CAL_CP_CODE
            AND   MSL_DATE BETWEEN CAL_DATE_FM AND CAL_DATE_TO
            AND   MSL_OTL_CODE = SST_OTL_CODE
            AND   MSL_CP_CODE  = SST_CP_CODE
            AND   SST_TWN_CODE = TOWN_CODE
            AND   SST_CP_CODE  = COMPANY_CODE
            AND   SST_EFF_DATE = (SELECT MAX(SST_EFF_DATE) 
                                  FROM SAL_SD_TWN_OTL B
                                  WHERE B.SST_OTL_CODE = sal_sd_twn_otl.SST_OTL_CODE 
                                  AND   B.SST_CP_CODE  = sal_sd_twn_otl.SST_CP_CODE
                                 )
           )
      group by msl_cp_code,  msl_inv_loc, office_code, office_name, zone_code, zone_name, region_code, region_name, CAL_MONTH

    ) GROUP BY CP_CODE, REGION_CODE, REGION_NAME,
       OFFICE_CODE, OFFICE_NAME,
       ZONE_CODE, ZONE_NAME, LOC_CODE, VISIT_MONTH






/

