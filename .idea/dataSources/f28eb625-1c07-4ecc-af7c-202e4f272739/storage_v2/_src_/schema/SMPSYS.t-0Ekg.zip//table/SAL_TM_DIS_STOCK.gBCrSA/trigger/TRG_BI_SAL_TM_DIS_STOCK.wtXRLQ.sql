create trigger TRG_BI_SAL_TM_DIS_STOCK
  before insert
  on SAL_TM_DIS_STOCK
  for each row
  begin
  SELECT SQ_SAL_TM_DIS_STOCK.NEXTVAL INTO :NEW.MDS_ID FROM DUAL;
end;
/

