create materialized view GS_REG_ZON_ITEM_SEC_SALES_PRV
refresh force on demand
  as
    SELECT DSL_CP_CODE COMPANY,
       MSL_REG_CODE REGIONCODE,
       MSL_ZON_CODE ZONECODE,
       MSL_BR_CODE BRANCH,
       DSL_DIT_CODE ITEMCODE,
       DIT_DESC ITEMNAME,
       MONTH,
       STOCKTYPE,
       SUM(DECODE(SALETYPE, 'DS', SEC_SALES, 0)) DS,
       SUM(DECODE(SALETYPE, 'SD', SEC_SALES, 0)) SD,
       SUM(DECODE(SALETYPE, 'SEC', SEC_SALES, 0)) SEC,
       SUM(DECODE(SALETYPE, 'DS', SEC_SALES, 0)) +
       SUM(DECODE(SALETYPE, 'SD', SEC_SALES, 0)) +
       SUM(DECODE(SALETYPE, 'SEC', SEC_SALES, 0)) SEC_SALES,
       MSL_MPV_CODE
  FROM (SELECT DSL_CP_CODE,
               MSL_REG_CODE,
               MSL_ZON_CODE,
               MSL_BR_CODE,
               DSL_DIT_CODE,
               DIT_DESC,
               MONTH,
               SALETYPE,
               STOCKTYPE,
               ROUND(SUM((SUM_DSL_QTY + SUM_DSL_BNS_QTY) * DIT_UNIT), 0) SEC_SALES,
               MSL_MPV_CODE
          FROM


          (SELECT DSL_CP_CODE,
                       MSL_REG_CODE,
                       MSL_ZON_CODE,
                       MSL_BR_CODE,
                       DSL_DIT_CODE,
                       DIT_DESC,
                       CAL_MONTH MONTH,
                       DIT_UNIT,
                       MSL_MPV_CODE,
                       'DS' SaleType,
                       DSL_MSY_CODE STOCKTYPE,
                       SUM(DSL_QTY) SUM_DSL_QTY,
                       NVL(SUM(DSL_BNS_QTY), 0) SUM_DSL_BNS_QTY
                  FROM SAL_TD_SALES,
                       SAL_TM_SALES,
                       INV_SD_ITEM,
                       FINANCIAL_CALENDAR
                 WHERE MSL_NUM = DSL_MSL_NUM
                   AND MSL_CP_CODE = DSL_CP_CODE
                   AND DIT_CODE = DSL_DIT_CODE
                   AND DIT_CP_CODE = DSL_CP_CODE
                   AND CAL_CP_CODE = MSL_CP_CODE
                   AND MSL_DATE BETWEEN CAL_DATE_FM AND CAL_DATE_TO
                   AND MSL_CP_CODE = '01'
                   AND MSL_TYPE = 'DS'
                 GROUP BY DSL_CP_CODE,
                          CAL_MONTH,
                          MSL_REG_CODE,
                          MSL_ZON_CODE,
                          MSL_BR_CODE,
                          DSL_DIT_CODE,
                          DIT_DESC,
                          MSL_TYPE,
                          MSL_MPV_CODE,
                          DIT_UNIT,
                          DSL_MSY_CODE,
                          MSL_MPV_CODE)
         GROUP BY DSL_CP_CODE,
                  MSL_REG_CODE,
                  MSL_ZON_CODE,
                  MSL_BR_CODE,
                  DSL_DIT_CODE,
                  DIT_DESC,
                  MONTH,
                  MSL_MPV_CODE,
                  SALETYPE,
                  STOCKTYPE
        -- Self Distribution SALES
        UNION
        SELECT DSL_CP_CODE,
               MSL_REG_CODE,
               MSL_ZON_CODE,
               MSL_BR_CODE,
               DSL_DIT_CODE,
               DIT_DESC,
               MONTH,
               SALETYPE,
               STOCKTYPE,
               ROUND(SUM((SUM_DSL_QTY + SUM_DSL_BNS_QTY) * DIT_UNIT), 0) SEC_SALES,
               MSL_MPV_CODE
          FROM (SELECT DSL_CP_CODE,
                       MSL_REG_CODE,
                       MSL_ZON_CODE,
                       MSL_BR_CODE,
                       DSL_DIT_CODE,
                       DIT_DESC,
                       CAL_MONTH MONTH,
                       DIT_UNIT,
                       MSL_MPV_CODE,
                       'SD' SaleType,
                       DSL_MSY_CODE STOCKTYPE,
                       SUM(DSL_QTY) SUM_DSL_QTY,
                       NVL(SUM(DSL_BNS_QTY), 0) SUM_DSL_BNS_QTY
                  FROM SAL_TD_SALES,
                       SAL_TM_SALES,
                       INV_SD_ITEM,
                       FINANCIAL_CALENDAR
                 WHERE MSL_NUM = DSL_MSL_NUM
                   AND MSL_CP_CODE = DSL_CP_CODE
                   AND DIT_CODE = DSL_DIT_CODE
                   AND DIT_CP_CODE = DSL_CP_CODE
                   AND CAL_CP_CODE = MSL_CP_CODE
                   AND MSL_DATE BETWEEN CAL_DATE_FM AND CAL_DATE_TO
                   AND MSL_CP_CODE = '01'
                   AND MSL_TYPE = 'SD'
                 GROUP BY DSL_CP_CODE,
                          CAL_MONTH,
                          MSL_REG_CODE,
                          MSL_ZON_CODE,
                          MSL_BR_CODE,
                          DSL_DIT_CODE,
                          DIT_DESC,
                          MSL_MPV_CODE,
                          MSL_TYPE,
                          DIT_UNIT,
                          DSL_MSY_CODE)
         GROUP BY DSL_CP_CODE,
                  MSL_REG_CODE,
                  MSL_ZON_CODE,
                  MSL_BR_CODE,
                  DSL_DIT_CODE,
                  DIT_DESC,
                  MONTH,
                  SALETYPE,
                  STOCKTYPE,
                  MSL_MPV_CODE
        -- DISTRIBUTOR SALES
        UNION
        SELECT MSS_CP_CODE,
               MSS_REG_CODE,
               MSS_ZON_CODE,
               MSS_BR_CODE,
               DSS_DIT_CODE,
               DIT_DESC,
               CAL_MONTH MONTH,
               SALETYPE,
               STOCKTYPE,
               ROUND(SUM((SUM_DSS_QTY + SUM_DSS_BNS_QTY) * DIT_UNIT), 0) SEC_SALES,
               MSL_MPV_CODE
          FROM (SELECT MSS_CP_CODE,
                       MSS_REG_CODE,
                       MSS_ZON_CODE,
                       MSS_BR_CODE,
                       MSS_DATE,
                       DSS_DIT_CODE,
                       DIT_DESC,
                       DIT_UNIT,
                       NULL MSL_MPV_CODE,
                       'SEC' SaleType,
                       'C' STOCKTYPE,
                       SUM(DSS_QTY) SUM_DSS_QTY,
                       NVL(SUM(DSS_BNS_QTY), 0) SUM_DSS_BNS_QTY
                  FROM SAL_SEC_SALES_MASTER,
                       SAL_SEC_SALES_DETAIL,
                       INV_SD_ITEM
                 WHERE MSS_ID = DSS_MSS_ID
                   AND MSS_CP_CODE = DSS_CP_CODE
                   AND DIT_CODE = DSS_DIT_CODE
                   AND DIT_CP_CODE = DSS_CP_CODE
                   AND MSS_CP_CODE = '01'
                   AND DSS_OTL_TYPE IN ('RT', 'WT', 'PR')
                 GROUP BY MSS_CP_CODE,
                          MSS_REG_CODE,
                          MSS_ZON_CODE,
                          MSS_BR_CODE,
                          MSS_DATE,
                          DSS_DIT_CODE,
                          DIT_DESC,
                          DIT_UNIT) A,
               FINANCIAL_CALENDAR
         WHERE CAL_CP_CODE = MSS_CP_CODE
           AND MSS_DATE BETWEEN CAL_DATE_FM AND CAL_DATE_TO
         GROUP BY MSS_CP_CODE,
                  MSS_REG_CODE,
                  MSS_ZON_CODE,
                  MSS_BR_CODE,
                  DSS_DIT_CODE,
                  DIT_DESC,
                  CAL_MONTH,
                  SALETYPE,
                  STOCKTYPE,
                  MSL_MPV_CODE

        )
 GROUP BY DSL_CP_CODE,
          MSl_REG_CODE,
          MSL_ZON_CODE,
          MSL_BR_CODE,
          DSL_DIT_CODE,
          DIT_DESC,
          MONTH,
          STOCKTYPE,
          MSL_MPV_CODE







/

