create trigger BI_SAL_VI_FACILITY_GRADING
  before insert
  on SAL_VI_FACILITY_GRADING
  for each row
  begin
    select SQ_SAL_VI_FACILITY_GRADING.nextval INTO :new.VFG_ID
    from dual;
end;
/

