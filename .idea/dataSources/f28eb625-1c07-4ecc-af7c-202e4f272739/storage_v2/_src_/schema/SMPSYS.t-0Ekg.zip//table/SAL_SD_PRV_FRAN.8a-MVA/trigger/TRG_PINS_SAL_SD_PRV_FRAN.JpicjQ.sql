create trigger TRG_PINS_SAL_SD_PRV_FRAN
  before insert
  on SAL_SD_PRV_FRAN
  for each row
  begin
IF :NEW.DPF_ID IS NULL THEN
   :NEW.DPF_ID := :NEW.DPF_MPV_CODE||'-'||:NEW.DPF_OTL_CODE||'-'||:NEW.DPF_START_DATE;
END IF;
END;
/

