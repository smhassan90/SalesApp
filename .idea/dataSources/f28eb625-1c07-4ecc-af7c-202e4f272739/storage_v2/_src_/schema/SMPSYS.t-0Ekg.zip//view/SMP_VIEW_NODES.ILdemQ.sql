create view SMP_VIEW_NODES as
  SELECT nl.name "NODE_NAME", DECODE(nl.agent,NULL,0,1) "DISCOVERY", ni.last_checked "LAST_CHECKED",
         DECODE(UPPER(nl2.status),'UP',1,0) "AGENT_STATUS", om.oms "OMS_MACHINE", nd.region_name "REGION"
  FROM   SMP_VDN_NODE_LIST nl, SMP_VDP_NODES nd, SMP_VDP_NODE_INFO ni, SMP_VDP_NODE_OMS_MAP om, SMP_VDG_NODE_LIST nl2
  WHERE  nl.name = ni.node (+)
    AND  nl.name = om.node (+)
    AND  nl.name = nl2.nodename (+)
	AND  ni.node = nd.node
/

comment on table SMP_VIEW_NODES
is 'List of all the services known in Enterprise Manager'
/

