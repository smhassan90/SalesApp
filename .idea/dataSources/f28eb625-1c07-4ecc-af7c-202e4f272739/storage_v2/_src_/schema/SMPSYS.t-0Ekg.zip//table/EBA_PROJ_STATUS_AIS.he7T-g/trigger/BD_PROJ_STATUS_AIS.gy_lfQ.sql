create trigger BD_PROJ_STATUS_AIS
  before delete
  on EBA_PROJ_STATUS_AIS
  for each row
  begin
    eba_proj_fw.tag_sync(
        p_new_tags      => null,
        p_old_tags      => :old.tags,
        p_content_type  => 'AI',
        p_content_id    => :old.id );
end;
/

