create trigger BI_SAL_LOCATION_CLOSE_TD
  before insert
  on SAL_LOCATION_CLOSE_TD
  for each row
  begin
 SELECT SQ_SAL_LOCATION_CLOSE_TD.NEXTVAL INTO :NEW.SLT_ID FROM DUAL;
 end;

/

