create view SMP_VIEW_VDJ_PRIV_JOB as
  select job_id, job_name, Job.owner, description, target_type,
           is_fixit, is_lib, number_tasks, incomplete, principal_name, 
           privilege_string FROM
      SMP_VDJ_JOB Job, SMP_VDU_PRINCIPALS_TABLE Users,
        SMP_VDU_OBJECTS_TABLE Objects,
        SMP_VDU_PRIVILEGE_TABLE Privilege where
      Objects.type='JOB' AND 
      to_char(Job.job_id)=to_char(Objects.object_name) AND 
      Objects.object_id=Privilege.object_oid AND 
      Privilege.principal_oid=Users.principal_id
/

