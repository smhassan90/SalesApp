create trigger BI_INDICATORS
  before insert
  on INDICATORS
  for each row
  begin  
   if inserting then 
      if :NEW."IND_ID" is null then 
         select INDICATORS_SEQ.nextval into :NEW."IND_ID" from dual; 
      end if; 
   end if; 
end;
/

