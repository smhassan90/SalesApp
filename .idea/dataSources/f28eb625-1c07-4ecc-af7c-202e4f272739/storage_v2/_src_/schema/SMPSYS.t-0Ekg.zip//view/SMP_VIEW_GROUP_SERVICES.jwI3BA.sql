create view SMP_VIEW_GROUP_SERVICES as
  SELECT gl.name "GROUP_NAME", tl.name "TARGET_NAME", ttd.name "TARGET_TYPE", NVL(rtd.type_label,ttd.name) "TARGET_NLS_TYPE"
  FROM   SMP_VDN_GROUP_LIST gl, SMP_VDN_GROUP_TARGET gt, SMP_VDN_TARGET_LIST tl, SMP_VDN_TARGET_TYPE_DEFN ttd, SMP_VBO_REPORTS_TYPE_DEFN rtd
  WHERE  gl.id = gt.groupid
    AND  gt.targetid = tl.id
    AND  tl.typeid = ttd.id
    AND  UPPER(ttd.name) = rtd.type (+)
 UNION ALL
  SELECT gl.name "GROUP_NAME", gl2.name "TARGET_NAME", 'oracle_sysman_group' "TARGET_TYPE", rtd.type_label "TARGET_NLS_TYPE"
  FROM   SMP_VDN_GROUP_LIST gl, SMP_VDN_GROUP_GROUP gg, SMP_VDN_GROUP_LIST gl2, SMP_VBO_REPORTS_TYPE_DEFN rtd
  WHERE  gl.id = gg.groupid
    AND  gg.membergroupid = gl2.id
    AND  rtd.type = 'ORACLE_SYSMAN_GROUP'
/

comment on table SMP_VIEW_GROUP_SERVICES
is 'List of all services put in a group'
/

