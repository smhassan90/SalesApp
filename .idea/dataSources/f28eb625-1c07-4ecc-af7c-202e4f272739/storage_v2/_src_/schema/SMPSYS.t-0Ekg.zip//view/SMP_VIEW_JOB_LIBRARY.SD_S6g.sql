create view SMP_VIEW_JOB_LIBRARY as
  SELECT j.job_id "JOB_ID", j.job_name "JOB_NAME", jt.target_name "TARGET_NAME", jt.target_type "TARGET_TYPE", NVL(rtd.type_label,jt.target_type) "TARGET_NLS_TYPE", j.owner "ADMINISTRATOR_NAME", j.last_mod_time+j.time_zone/86400000 "TIMESTAMP"
  FROM   SMP_VDJ_JOB j, SMP_VDJ_JOB_TARGET jt, SMP_VBO_REPORTS_TYPE_DEFN rtd
  WHERE  j.job_id = jt.job_id
    AND  j.is_lib = 1
    AND  UPPER(jt.target_type) = rtd.type (+)
/

comment on table SMP_VIEW_JOB_LIBRARY
is 'Overview of all the jobs in the library'
/

