create trigger BI_SAL_SO_TRAINING_MATERIAL
  before insert
  on SAL_SO_TRAINING_MATERIAL
  for each row
  begin
IF :NEW.STM_ID IS NULL then
    select SQ_SAL_SO_TRAINING_MATERIAL.nextval INTO :new.STM_ID
    from dual;
END IF;
end;
/

