create trigger TRG_PRE_INS_INV_SO_CUST
  before insert
  on INV_SO_CUSTOMERS
  for each row
  begin
SELECT SQ_INV_SO_CUSTOMERS.NEXTVAL INTO :NEW.CUS_ID FROM DUAL;
end;
/

