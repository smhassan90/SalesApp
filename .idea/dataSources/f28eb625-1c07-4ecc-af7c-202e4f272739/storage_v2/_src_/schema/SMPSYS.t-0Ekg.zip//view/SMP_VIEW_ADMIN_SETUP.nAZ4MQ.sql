create view SMP_VIEW_ADMIN_SETUP as
  SELECT u.user_name "ADMINISTRATOR_NAME", se.email_address "EMAIL_ADDRESS", se.subject_prefix "EMAIL_TITLE", p.carrier "PAGING_SERVICE", p.pin "PAGING_PIN"
  FROM   SMP_VDV_USER u, SMP_VDV_SMTP_EMAIL se, SMP_VDV_PAGE p
  WHERE  u.user_id = se.user_id (+)
    AND  u.user_id = p.user_id (+)
/

comment on table SMP_VIEW_ADMIN_SETUP
is 'Notification setup per administrator'
/

