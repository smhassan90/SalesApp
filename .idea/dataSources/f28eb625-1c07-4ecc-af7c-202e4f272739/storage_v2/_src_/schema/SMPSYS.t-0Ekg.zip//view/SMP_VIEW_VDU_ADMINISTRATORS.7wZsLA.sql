create view SMP_VIEW_VDU_ADMINISTRATORS as
  SELECT pt.principal_name "PRINCIPAL_NAME", 
         pt.principal_id "PRINCIPAL_ID",
         DECODE(pr1.privilege_string,'IS',1,0) "SUPERUSER",
         DECODE(pr2.privilege_string,'ALL',1,0) "JOB_SYSTEM", 
         DECODE(pr3.privilege_string,'ALL',1,0) "EVENT_SYSTEM"
  FROM   smp_vdu_principals_table pt,
         ( SELECT principal_oid, privilege_string FROM smp_vdu_privilege_table WHERE object_oid = 1) pr1,
         ( SELECT principal_oid, privilege_string FROM smp_vdu_privilege_table WHERE object_oid = 2) pr2,
         ( SELECT principal_oid, privilege_string FROM smp_vdu_privilege_table WHERE object_oid = 3) pr3
  WHERE  pt.principal_id = pr1.principal_oid (+)
    AND  pt.principal_id = pr2.principal_oid (+)
    AND  pt.principal_id = pr3.principal_oid (+)
/

