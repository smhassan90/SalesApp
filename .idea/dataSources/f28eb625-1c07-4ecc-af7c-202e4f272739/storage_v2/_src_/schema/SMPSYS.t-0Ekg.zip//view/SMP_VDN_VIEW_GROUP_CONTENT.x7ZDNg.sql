create view SMP_VDN_VIEW_GROUP_CONTENT as
  SELECT 
    ParentGrp.Owner || ':' || ParentGrp.Name,
    MemberGrp.Owner || ':' || MemberGrp.Name,
    'oracle_sysman_group' "childType",
    gg.x, 
    gg.y
   FROM
    smp_vdn_group_group gg,
    smp_vdn_group_list MemberGrp,
    smp_vdn_group_list ParentGrp
   WHERE 
    ParentGrp.Id = gg.GroupId AND
    MemberGrp.Id = gg.memberGroupId
UNION
SELECT
    ParentGrp.Owner || ':' || ParentGrp.Name,
    Target.Name,
    Type.Name,
    gt.x, 
    gt.y
   FROM
    smp_vdn_group_Target gt,
    smp_vdn_group_list ParentGrp,
    smp_vdn_Target_list Target,
    smp_vdn_Target_Type_defn Type
   WHERE
    Target.Id = gt.TargetId AND
    ParentGrp.Id = gt.GroupId AND
    Type.Id = Target.TypeId
/

