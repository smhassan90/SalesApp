create trigger BI_ADC_SO_LINK
  before insert
  on ADC_SO_LINK
  for each row
  begin
 SELECT SQ_ADC_SO_LINK.NEXTVAL INTO :NEW.ASL_ID FROM DUAL;
 end;
/

