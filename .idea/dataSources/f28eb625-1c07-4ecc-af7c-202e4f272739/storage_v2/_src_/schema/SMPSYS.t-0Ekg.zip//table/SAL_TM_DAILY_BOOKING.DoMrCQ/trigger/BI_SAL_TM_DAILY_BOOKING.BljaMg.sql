create trigger BI_SAL_TM_DAILY_BOOKING
  before insert
  on SAL_TM_DAILY_BOOKING
  for each row
  BEGIN
    SELECT sal_tm_daily_booking_seq.NEXTVAL INTO :NEW.sdl_id
    FROM DUAL;
END;
/

