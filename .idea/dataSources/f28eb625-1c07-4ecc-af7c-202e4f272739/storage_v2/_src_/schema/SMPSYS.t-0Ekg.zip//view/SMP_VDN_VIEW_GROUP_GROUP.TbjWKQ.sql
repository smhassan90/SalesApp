create view SMP_VDN_VIEW_GROUP_GROUP as
  SELECT 
    ParentGrp.Owner,
    ParentGrp.Name,
    MemberGrp.Owner,
    MemberGrp.Name,
    gg.MemberGroupId,
    gg.x, 
    gg.y
   FROM
    smp_vdn_group_group gg,
    smp_vdn_group_list MemberGrp,
    smp_vdn_group_list ParentGrp
   WHERE 
    Parentgrp.Id = gg.GroupId AND
    MemberGrp.Id = gg.MemberGroupId
/

