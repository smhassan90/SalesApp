create trigger BI_SAL_LOCATION_CLOSE_TM
  before insert
  on SAL_LOCATION_CLOSE_TM
  for each row
  begin
 SELECT SQ_SAL_LOCATION_CLOSE_TM.NEXTVAL INTO :NEW.SLC_ID FROM DUAL;
 end;
/

