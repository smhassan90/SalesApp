create view OUTLET_REPORT_VIEW_NEW as
  (select o.otl_cp_code cp_code,
o.otl_twn_code Town_Code,
o.otl_code Outlet_code, o.otl_desc Outlet_name,
o.otl_add1||' '||o.otl_add2 outlet_addr,
o.otl_tel_no outlet_telno, o.otl_reg_date outlet_reg_date,
DECODE(o.OTL_TYPE, 'CH','Chemist','CL','Clinic','HP','Hospital',
       'IS','Institution','MH','Maternity Home','NG','NGO')as   Outlet_TYPE,
o.otl_flag Outlet_Status, o.otl_br_code Outlet_Branch_Code,
p.mpv_code Provider_Code, p.mpv_desc Provider_Name,
p.mpv_flag Status,p.mpv_qualif Qualif, p.mpv_new_nic Provider_NIC_NO,pt.dpt_mpt_code Provider_Type,
pt.dpt_eff_date provider_train_date,trainer.dtr_trn_code Trainer_code,
trnname.mlc_desc Trainer_Name,prvout.dpo_lft_date Provider_Left_date,
getstfcode('01',sysdate,substr(o.otl_code,1,5),'S') SPO_code,
getstfcode('01',sysdate,substr(o.otl_code,1,5),'U') MR_code,
getstfcode('01',sysdate,substr(o.otl_code,1,5),'V') AAM_code
from   sal_so_outlet o,sal_sd_prv_outlet prvout,sal_sm_provider p,
       sal_sd_prv_training pt,sal_sd_prv_trainer trainer,inv_sm_location trnname
where    o.otl_cp_code = '01'
and      prvout.dpo_otl_code = o.otl_code
and      prvout.dpo_cp_code  = o.otl_cp_code
and      prvout.dpo_mpv_code = p.mpv_code
and      prvout.dpo_cp_code  = p.mpv_cp_code
and      prvout.dpo_lft_date is null
and      pt.dpt_mpv_code = p.mpv_code
and      pt.dpt_cp_code  = p.mpv_cp_code
and      pt.dpt_eff_date = (select max(prvt.dpt_eff_date)
                            from sal_sd_prv_training prvt
			    where prvt.dpt_mpv_code = p.mpv_code
                            and   prvt.dpt_cp_code  = p.mpv_cp_code)
and      trainer.dtr_mpv_code = p.mpv_code
and      trainer.dtr_cp_code  = p.mpv_cp_code
and      trainer.dtr_trn_code = trnname.mlc_code
and      trainer.dtr_cp_code  = trnname.mlc_cp_Code
and      trainer.dtr_eff_date = (select max(prvtrner.dtr_eff_date)
                         from sal_sd_prv_trainer prvtrner
		         where prvtrner.dtr_mpv_code = p.mpv_code
                         and   prvtrner.dtr_cp_Code  = p.mpv_cp_code))
/

