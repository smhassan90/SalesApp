create trigger TRG_PRE_INS_SAL_SD_AS_OTL
  before insert
  on SAL_SD_AS_OTL
  for each row
  begin
IF :NEW.DAS_ID IS NULL THEN
   :NEW.DAS_ID := :NEW.DAS_OTL_CODE||'-'||LPAD(:NEW.DAS_AS_NUM,2,00);
END IF;
END;
/

