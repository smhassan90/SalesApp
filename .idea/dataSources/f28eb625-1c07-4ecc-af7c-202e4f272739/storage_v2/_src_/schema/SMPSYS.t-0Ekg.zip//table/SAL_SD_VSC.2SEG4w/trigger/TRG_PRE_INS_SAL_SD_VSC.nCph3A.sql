create trigger TRG_PRE_INS_SAL_SD_VSC
  before insert
  on SAL_SD_VSC
  for each row
  declare
 V_DVSC_ID number(12);
begin
SELECT SQ_SAL_SD_VSC.NEXTVAL INTO V_DVSC_ID FROM DUAL;
:NEW.DVSC_ID := :NEW.DVSC_BR_CODE||lpad(V_DVSC_ID,10,0);
end;
/

