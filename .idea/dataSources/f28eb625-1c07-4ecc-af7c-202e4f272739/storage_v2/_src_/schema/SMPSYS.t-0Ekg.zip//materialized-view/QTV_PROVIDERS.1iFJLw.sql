create materialized view QTV_PROVIDERS
refresh force on demand
  as
    SELECT distinct info.mvi_mpv_code R,
                get_mpv_otl_desc(info.mvi_mpv_code, '01', 'P', 'W') D
  FROM SAL_SM_VISIT_INFO INFO






/

