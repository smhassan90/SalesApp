create view VU_SMS_CLIENT_INFO as
  select TM.asc_id, TM.asc_cp_code, TM.asc_desc, TM.asc_mpv_code,PROV_CODE, PROV_NAME, ASC_OTL_CODE, OTL_DESC, DIST_CODE, DIST_NAME, TEHSIL_CODE, TEHSIL_NAME, ASC_FLAG,

       ASD_CELL_NO, ASD_EFFECT_DT, REGION_CODE, REGION_NAME, ZONE_CODE, ZONE_NAME

from   adc_sm_client TM, SAL_SO_OUTLET, VU_HIERARCHY,

      (

        SELECT DTD.ASD_ASC_ID , DTD.ASD_EFFECT_DT , DTD.ASD_CELL_NO

        FROM   ADC_SD_CLIENT DTD,

               (

                 SELECT MAX(X.ASD_EFFECT_DT) MAX_EFFECT_DT, ASD_ASC_ID

                 FROM ADC_SD_CLIENT X

                 group by asd_asc_id

               ) MMS

        WHERE  DTD.ASD_EFFECT_DT = MMS.MAX_EFFECT_DT

          AND  DTD.ASD_ASC_ID    = MMS.ASD_ASC_ID

      )  TCT

where TM.ASC_ID       = TCT.ASD_ASC_ID(+)

AND   TM.ASC_OTL_CODE = OTL_CODE

AND   TM.ASC_CP_CODE  = OTL_CP_CODE

AND   OTL_TWN_CODE    = TOWN_CODE

AND   OTL_CP_CODE     = COMPANY_CODE
/

