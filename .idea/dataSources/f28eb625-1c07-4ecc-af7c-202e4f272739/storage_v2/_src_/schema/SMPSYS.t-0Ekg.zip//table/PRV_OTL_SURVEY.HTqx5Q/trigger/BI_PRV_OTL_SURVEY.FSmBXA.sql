create trigger BI_PRV_OTL_SURVEY
  before insert
  on PRV_OTL_SURVEY
  for each row
  BEGIN
    SELECT prv_otl_survey_seq.NEXTVAL INTO :NEW.POS_id
    FROM DUAL;
END;
/

