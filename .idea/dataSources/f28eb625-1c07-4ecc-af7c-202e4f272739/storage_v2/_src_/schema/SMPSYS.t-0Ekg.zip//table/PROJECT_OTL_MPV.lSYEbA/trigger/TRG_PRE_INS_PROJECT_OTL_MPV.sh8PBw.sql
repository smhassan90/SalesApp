create trigger TRG_PRE_INS_PROJECT_OTL_MPV
  before insert
  on PROJECT_OTL_MPV
  for each row
  begin
   SELECT SQ_PROJECT_OTL_MPV.NEXTVAL INTO :NEW.POM_ID FROM DUAL;
end;
/

