create view SECONDARY_SALES_MONTHLY as
  select month_name, item_code, stock_type, sale_qty
from   direct_sales_monthly
union
select month_name, item_code, 'D', sale_qty
from   mnp_sales_monthly
/

