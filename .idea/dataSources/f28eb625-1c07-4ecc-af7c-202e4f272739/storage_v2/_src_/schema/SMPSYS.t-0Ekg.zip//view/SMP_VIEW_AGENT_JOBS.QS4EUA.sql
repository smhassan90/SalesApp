create view SMP_VIEW_AGENT_JOBS as
  SELECT j.job_id "JOB_ID", jm.agentid "AGENT_ID", j.job_name "JOB_NAME", j.owner "ADMINISTRATOR_NAME", j.description "DESCRIPTION", 
         jpt.node_name "NODE_NAME", jpt.target_name "TARGET_NAME", j.target_type "TARGET_TYPE", NVL(rtd.type_label,j.target_type) "TARGET_NLS_TYPE",
         j.is_fixit "FIXIT_JOB", DECODE(INSTR(j.schedule,'IntervalSchedule'),0,0,1) "INTERVAL_JOB", jpt.exec_num "EXEC_NUM",
         j.last_mod_by "MODIFIED_BY", j.last_mod_time+j.time_zone/86400000 "MODIFIED_DATE", jpt.status "STATUS",
         jpt.start_time+jpt.time_zone/86400000 "STARTED", jpt.finish_time+jpt.time_zone/86400000 "FINISHED", jpt.next_exec_time+jpt.time_zone/86400000 "NEXT_EXEC",
         DECODE(UPPER(nl.status),'UP',1,0) "AGENT_STATUS"
  FROM   SMP_VDJ_JOB j, SMP_VDG_JOBID_MAP jm, SMP_VDJ_JOB_PER_TARGET jpt, SMP_VDG_NODE_LIST nl, SMP_VBO_REPORTS_TYPE_DEFN rtd
  WHERE  j.job_id = jm.masid
    AND  jpt.node_name = jm.nodename
    AND  jpt.target_name = jm.targetname
    AND  j.job_id = jpt.job_id
    AND  jm.nodename = nl.nodename
    AND  UPPER(j.target_type) = rtd.type (+)
/

comment on table SMP_VIEW_AGENT_JOBS
is 'List of all jobs known in the repository'
/

