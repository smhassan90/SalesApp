create trigger GSM_RECIEVING_DATA_TRG
  before insert
  on GSM_RECIEVING_DATA
  for each row
  begin
 SELECT GSM_RECIEVING_DATA_SEQ.NEXTVAL INTO :NEW.RC_ID FROM DUAL;
 end;
/

