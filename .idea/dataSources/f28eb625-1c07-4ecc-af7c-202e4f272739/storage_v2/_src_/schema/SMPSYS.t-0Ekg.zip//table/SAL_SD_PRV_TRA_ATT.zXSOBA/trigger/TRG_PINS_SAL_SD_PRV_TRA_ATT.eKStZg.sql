create trigger TRG_PINS_SAL_SD_PRV_TRA_ATT
  before insert
  on SAL_SD_PRV_TRA_ATT
  for each row
  begin
IF :NEW.DTA_ID IS NULL THEN
   :NEW.DTA_ID := :NEW.DTA_MPV_CODE||'-'||:NEW.DTA_TRA_CODE||'-'||:NEW.DTA_YEAR||'-'||:NEW.DTA_TOPIC;
END IF;
END;
/

