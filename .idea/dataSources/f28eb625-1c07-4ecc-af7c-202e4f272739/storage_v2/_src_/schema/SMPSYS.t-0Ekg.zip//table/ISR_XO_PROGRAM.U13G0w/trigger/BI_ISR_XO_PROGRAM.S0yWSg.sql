create trigger BI_ISR_XO_PROGRAM
  before insert
  on ISR_XO_PROGRAM
  for each row
  begin
    select SQ_ISR_XO_PROGRAM.nextval INTO :new.PRG_ID
    from dual;
END;
/

