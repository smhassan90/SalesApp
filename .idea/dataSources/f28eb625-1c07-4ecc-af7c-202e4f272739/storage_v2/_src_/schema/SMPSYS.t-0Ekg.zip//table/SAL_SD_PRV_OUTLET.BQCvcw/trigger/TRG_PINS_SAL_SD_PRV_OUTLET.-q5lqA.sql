create trigger TRG_PINS_SAL_SD_PRV_OUTLET
  before insert
  on SAL_SD_PRV_OUTLET
  for each row
  begin
IF :NEW.DPO_ID IS NULL THEN
   :NEW.DPO_ID := :NEW.DPO_MPV_CODE||'-'||:NEW.DPO_OTL_CODE||'-'||:NEW.DPO_EFF_DATE;
END IF;
END;
/

