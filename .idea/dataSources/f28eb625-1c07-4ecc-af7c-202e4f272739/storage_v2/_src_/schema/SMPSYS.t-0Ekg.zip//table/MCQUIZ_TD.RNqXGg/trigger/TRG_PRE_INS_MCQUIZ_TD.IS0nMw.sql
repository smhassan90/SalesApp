create trigger TRG_PRE_INS_MCQUIZ_TD
  before insert
  on MCQUIZ_TD
  for each row
  begin
 SELECT SQ_MCQUIZ_TD.NEXTVAL INTO :NEW.MTD_ID FROM DUAL;
 end;
/

