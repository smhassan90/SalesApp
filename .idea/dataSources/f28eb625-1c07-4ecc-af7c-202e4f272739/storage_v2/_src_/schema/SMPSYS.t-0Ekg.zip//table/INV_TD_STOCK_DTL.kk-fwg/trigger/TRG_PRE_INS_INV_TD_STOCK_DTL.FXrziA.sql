create trigger TRG_PRE_INS_INV_TD_STOCK_DTL
  before insert
  on INV_TD_STOCK_DTL
  for each row
  begin
  SELECT SQ_INV_TD_STOCK_DTL.NEXTVAL INTO :NEW.DST_ID FROM DUAL;
end;
/

