create view PZ_SALE_CHECK as
  (
 SELECT DISTINCT dsl_dist_code, dsl_dis_spo_code ,DSL_DIS_DPO_CODE, DSL_DIS_DPO_NAME, dsl_CUS_code, DSL_CUS_NAME,vh.town_code,VH.TOWN_NAME,VH.CITY_NAME,VH.DIST_NAME
    FROM sal_to_dis_sales_history,inv_sd_item b, inv_so_item_category c,VU_HIERARCHY VH
    WHERE dsl_date BETWEEN '01-feb-13' AND '30-apr-13'
    AND dsl_cus_cat != 'PR'
    and b.dit_code=sal_to_dis_sales_history.dsl_dit_code
    and b.dit_cp_code=sal_to_dis_sales_history.dsl_cp_code
    AND VH.TOWN_CODE=sal_to_dis_sales_history.Dsl_Smp_Twn
    AND VH.COMPANY_CODE=sal_to_dis_sales_history.Dsl_Cp_Code
    and b.dit_ctg_code=c.ctg_code
    and b.dit_cp_code=c.ctg_cp_code
    and b.dit_cp_code = '01'
    and c.ctg_desc in ('Pills','Injectables','Barriers Methods')
    AND VH.dist_NAME LIKE 'Karachi%'
    GROUP BY dsl_dist_code, DSL_DIS_DPO_CODE, dsl_dis_spo_code ,DSL_DIS_DPO_NAME, dsl_CUS_code,DSL_CUS_NAME,VH.TOWN_NAME,VH.DIST_NAME,VH.CITY_NAME,vh.town_code
    HAVING COUNT(distinct c.ctg_desc) = 3)
/

