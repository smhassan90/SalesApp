create trigger BI_SAL_SO_PRV_SURGICAL_INFO
  before insert
  on SAL_SO_PRV_SURGICAL_INFO
  for each row
  begin
    select SQ_SAL_SO_PRV_SURGICAL_INFO.nextval INTO :new.SSI_ID
    from dual;
end;
/

