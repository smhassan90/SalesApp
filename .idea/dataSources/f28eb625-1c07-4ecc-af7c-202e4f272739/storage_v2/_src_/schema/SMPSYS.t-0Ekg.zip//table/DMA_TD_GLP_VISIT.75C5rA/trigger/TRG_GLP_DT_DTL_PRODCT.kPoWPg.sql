create trigger TRG_GLP_DT_DTL_PRODCT
  before insert
  on DMA_TD_GLP_VISIT
  for each row
  begin
 SELECT SQ_DMA_TD_VISIT_GLP.NEXTVAL INTO :NEW.DDV_ID FROM DUAL;
 end;
/

