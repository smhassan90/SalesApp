create view TEMP as
  select QGD_OTL_CODE from qul_to_grading
where  qgd_prd_to = '30-JUN-04'
and    qgd_grade = 'A'
and    qgd_mpt_code = 'GS1'
and    qgd_otl_code not in (select pgd_pot_code from sal_to_grading
                            where  substr(pgd_pot_code,1,1) = 'T'
                            and    pgd_prd_to = '30-JUN-04')
order by 1
/

