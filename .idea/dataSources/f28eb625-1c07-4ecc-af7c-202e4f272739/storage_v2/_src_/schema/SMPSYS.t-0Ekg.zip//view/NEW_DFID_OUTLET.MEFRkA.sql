create view NEW_DFID_OUTLET as
  (
SELECT DISTINCT dsl_dist_code District_Code, dm.district_name District_name, DSL_DIS_DPO_CODE PZ_Depo_Code, DSL_DIS_DPO_NAME PZ_Depo_Name, dsl_CUS_code PZ_Customer_Code, DSL_CUS_NAME PZ_Customer_Name
FROM
  ( SELECT DISTINCT dsl_dist_code, DSL_DIS_DPO_CODE, DSL_DIS_DPO_NAME, dsl_CUS_code, DSL_CUS_NAME
    FROM sal_to_dis_sales_history
    WHERE dsl_date BETWEEN '01-JAN-13' AND '31-MAR-13'
    AND dsl_cus_cat != 'PR'
    GROUP BY dsl_dist_code, DSL_DIS_DPO_CODE, DSL_DIS_DPO_NAME, dsl_CUS_code, DSL_CUS_NAME
   -- HAVING COUNT( distinct TRUNC(DSL_DATE,'month')) = 3
    MINUS
    SELECT DISTINCT dsl_dist_code, DSL_DIS_DPO_CODE, DSL_DIS_DPO_NAME, dsl_CUS_code, DSL_CUS_NAME
    FROM sal_to_dis_sales_history
    WHERE dsl_date BETWEEN '01-JAN-12' AND '31-DEC-12'
    AND dsl_cus_cat != 'PR'
  ), district_master dm
WHERE dsl_dist_code = dm.district_code
and dsl_dist_code IN
  ( SELECT dst_code
    FROM project_districts,
      isr_xo_projects
    WHERE prg_code = isr_xo_projects.prj_id
    AND prg_code   = '38'
  ))
/

