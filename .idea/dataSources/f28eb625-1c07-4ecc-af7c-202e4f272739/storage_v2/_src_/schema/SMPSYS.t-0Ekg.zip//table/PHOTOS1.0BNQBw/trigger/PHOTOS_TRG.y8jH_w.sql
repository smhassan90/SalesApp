create trigger PHOTOS_TRG
  before insert
  on PHOTOS1
  for each row
  begin
  select photo_seq.nextval into :new.photo_id from dual;
end;
/

