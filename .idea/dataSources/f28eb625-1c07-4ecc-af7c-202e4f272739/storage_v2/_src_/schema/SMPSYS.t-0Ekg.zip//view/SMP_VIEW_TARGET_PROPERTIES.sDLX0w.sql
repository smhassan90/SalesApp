create view SMP_VIEW_TARGET_PROPERTIES as
  SELECT tl.name "TARGET_NAME", ttd.name "TARGET_TYPE", NVL(rtd.type_label,ttd.name) "TARGET_NLS_TYPE", tp.name "NAME", tp.value "VALUE"
  FROM   SMP_VDN_TARGET_LIST tl, SMP_VDN_TARGET_TYPE_DEFN ttd, SMP_VDN_TARGET_PROPERTIES tp, SMP_VBO_REPORTS_TYPE_DEFN rtd
  WHERE  tl.id = tp.targetid
    AND  tl.typeid = ttd.id
    AND  UPPER(ttd.name) = rtd.type (+)
/

comment on table SMP_VIEW_TARGET_PROPERTIES
is 'List of all properties of a managed target'
/

