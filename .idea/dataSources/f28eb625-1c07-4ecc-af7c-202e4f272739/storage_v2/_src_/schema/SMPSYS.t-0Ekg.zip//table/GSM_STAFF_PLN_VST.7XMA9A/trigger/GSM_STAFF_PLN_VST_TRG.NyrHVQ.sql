create trigger GSM_STAFF_PLN_VST_TRG
  before insert
  on GSM_STAFF_PLN_VST
  for each row
  begin
    select GSM_STAFF_PLN_VST_SEQ.nextval INTO :NEW.VST_ID
    from dual;
end;
/

