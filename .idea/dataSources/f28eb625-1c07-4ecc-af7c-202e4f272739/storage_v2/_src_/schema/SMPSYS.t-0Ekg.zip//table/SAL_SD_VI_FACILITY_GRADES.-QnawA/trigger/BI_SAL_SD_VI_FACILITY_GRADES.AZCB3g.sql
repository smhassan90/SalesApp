create trigger BI_SAL_SD_VI_FACILITY_GRADES
  before insert
  on SAL_SD_VI_FACILITY_GRADES
  for each row
  begin
    select SQ_SAL_SD_VI_FACILITY_GRADES.nextval INTO :new.DFG_ID
    from dual;
end;
/

