create trigger BI_MOBILE_TEST
  before insert
  on MOBILE_TEST
  for each row
  begin   
  if :NEW."ID" is null then 
    select "MOBILE_TEST_SEQ".nextval into :NEW."ID" from sys.dual; 
  end if; 
end;
/

