create trigger MIO_DCR_DETAIL_TRG
  before insert
  on MIO_DCR_DETAIL
  for each row
  begin
  SELECT MIO_DCR_DETAIL_SEQ.NEXTVAL INTO :NEW.DTL_ID FROM DUAL;
end;
/

