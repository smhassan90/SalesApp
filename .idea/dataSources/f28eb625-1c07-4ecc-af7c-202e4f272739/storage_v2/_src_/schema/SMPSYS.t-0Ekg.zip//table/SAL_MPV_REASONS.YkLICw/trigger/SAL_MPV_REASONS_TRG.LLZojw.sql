create trigger SAL_MPV_REASONS_TRG
  before insert
  on SAL_MPV_REASONS
  for each row
  begin
 SELECT SAL_MPV_REASONS_SEQ.NEXTVAL INTO :NEW.RS_ID FROM DUAL;
 end;
/

