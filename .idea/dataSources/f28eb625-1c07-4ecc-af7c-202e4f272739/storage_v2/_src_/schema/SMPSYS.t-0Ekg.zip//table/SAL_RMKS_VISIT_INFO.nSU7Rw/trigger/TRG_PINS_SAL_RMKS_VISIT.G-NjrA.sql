create trigger TRG_PINS_SAL_RMKS_VISIT
  before insert
  on SAL_RMKS_VISIT_INFO
  for each row
  begin
  SELECT SQ_SAL_RMKS_VISIT_INFO.NEXTVAL INTO :NEW.RMKS_VI_CODE FROM DUAL;
end;
/

