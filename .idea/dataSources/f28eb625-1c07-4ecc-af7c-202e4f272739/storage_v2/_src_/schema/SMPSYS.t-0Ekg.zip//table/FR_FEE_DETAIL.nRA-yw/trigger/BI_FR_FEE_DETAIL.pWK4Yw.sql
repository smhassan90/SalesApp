create trigger BI_FR_FEE_DETAIL
  before insert
  on FR_FEE_DETAIL
  for each row
  BEGIN
    SELECT FR_FEE_DETAIL_SEQ.NEXTVAL INTO :NEW.FEE_ID
    FROM DUAL;
END;
/

