create view SMP_VIEW_AGENTS as
  SELECT nl.name "NODE_NAME", nl2.agentname "AGENT_ALIAS", ni.last_checked "LAST_CHECKED", nl2.agenttz/3600000 "AGENT_TIMEZONE",
         DECODE(UPPER(nl2.status),'UP',1,0) "AGENT_STATUS", DECODE(UPPER(nl2.agentstate),'BAD',0,1) "AGENT_STATE", om.oms "OMS_MACHINE",
                 NVL(es.sev,0) "SEVERITY"
  FROM   smp_vdn_node_list nl, smp_vdp_node_info ni, smp_vdp_node_oms_map om, smp_vdg_node_list nl2,
         (SELECT node_name, (MAX(node_state)-302)*100+MAX(agent_severity) sev FROM smp_vde_event_target_state GROUP BY node_name) es
  WHERE  nl.name = ni.node
    AND  nl.name = om.node
    AND  nl.name = nl2.nodename
        AND  nl.name = es.node_name (+)
/

comment on table SMP_VIEW_AGENTS
is 'List of all the Intelligent Agents discovered in Enterprise Manager'
/

