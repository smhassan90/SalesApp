create trigger TRG_PREINS_XO_PROJECTS
  before insert
  on ISR_XO_PROJECTS
  for each row
  declare
  V_CODE number(5);
begin
 SELECT SQ_ISR_XO_PROJECTS.NEXTVAL INTO V_CODE FROM DUAL;
:NEW.Prj_id := lpad(V_CODE,4,0);
end;
/

