create view ACTIVE_GS_PROVIDERS as
  SELECT /*+ NO_CPU_COSTING */ B.REGION_CODE || ' - ' || B.REGION_NAME REGION_NAME,
       B.Zone_Code || ' - ' || B.ZONE_NAME ZONE_NAME,
       B.DIST_CODE || ' - ' || B.DIST_NAME DISTRICT,
       B.TEHSIL_CODE || ' - ' || B.Tehsil_Name TEHSIL,
       B.TOWN_CODE || ' - ' || B.TOWN_NAME TOWN,
       DPT_MPT_CODE GSTYPE,
       A.MPV_CODE PROVIDER_CODE,
       get_mpv_otl_desc(A.MPV_CODE, '01', 'P', 'W') PROVIDER ,
 dm.dis_donor
  FROM HIERARCHY_OTL_PRV_INFO A,
       vu_hierarchy B,
       district_master dm,
       SAL_SD_TWN_OTL C
 WHERE C.SST_OTL_CODE = A.OTL_CODE
   AND C.SST_CP_CODE = '01'
   and dm.district_code=b.dist_code
   AND C.SST_EFF_DATE = (SELECT MAX(SST_EFF_DATE)
                           FROM SAL_SD_TWN_OTL D
                          WHERE D.SST_CP_CODE = C.SST_CP_CODE
                            AND D.SST_OTL_CODE = C.SST_OTL_CODE)
   AND C.SST_CP_CODE = B.COMPANY_CODE
   AND C.SST_TWN_CODE = B.TOWN_CODE
   AND DPO_LFT_DATE IS NULL
   AND A.OTL_FLAG = 'Y'
   AND A.MPV_FLAG = 'Y'
   AND DPT_MPT_CODE IN ('AS+', 'ASS', 'GS+', 'GS1')
/

