create view PER_EMPLOYEE_EXT as
  SELECT DISTINCT pap.person_id emp_id,
       pap.first_name,
       paa.supervisor_id,
       pap.first_name || '-' || pap.last_name full_name,
       papf.first_name || '-' || papf.last_name Supervisor_name,
       papf.employee_number      supr_emp_id,
       pap.employee_number       employee_id,
       pap.sex                   sex,
       pg.NAME                   grade,
       pj.NAME                   job_name,
       pjd.segment3              business_unit,
       pjd.segment4              fnc,
       pjd.segment5              designation,
       pjd.segment2              job_group,
       pos.date_start            hire_date,
       hl.location_code          Loc,
       pap.full_name             emp_name,
       pj.job_information3       flsa_code,
       pap.effective_start_date  p_effective_start_date,
       pap.effective_end_date    p_effective_end_date,
       paa.effective_start_date  a_effective_start_date,
       paa.effective_end_date    a_effective_end_date,
       pap.current_employee_flag
  FROM per_all_people_f@fis       pap,
       per_all_assignments_f@fis  paa,
       per_periods_of_service@fis pos,
       per_jobs@fis               pj,
       per_job_definitions@fis    pjd,
       hr_locations@fis           hl,
       per_grades@fis             pg,
       per_all_people_f@fis       papf
 WHERE pap.person_id = paa.person_id
   AND paa.job_id = pj.job_id
   AND paa.location_id = hl.location_id
   AND paa.grade_id = pg.grade_id(+)
   AND pos.person_id = pap.person_id
   AND paa.supervisor_id = papf.person_id
   AND pj.job_definition_id = pjd.job_definition_id
   AND SYSDATE BETWEEN PAA.effective_start_date AND PAA.effective_END_date
   AND SYSDATE BETWEEN PAP.effective_start_date AND PAP.effective_END_date
/

