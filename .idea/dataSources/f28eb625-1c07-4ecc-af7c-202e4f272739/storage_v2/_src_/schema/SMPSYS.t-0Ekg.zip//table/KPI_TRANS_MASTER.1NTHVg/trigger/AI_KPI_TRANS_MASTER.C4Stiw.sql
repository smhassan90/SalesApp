create trigger AI_KPI_TRANS_MASTER
  after insert
  on KPI_TRANS_MASTER
  for each row
  BEGIN
DECLARE
 V_TGT_DAYS NUMBER :=0;
 V_TGT_TYPE CHAR := NULL;
BEGIN
 IF INSERTING THEN
    V_TGT_DAYS := :NEW.KTM_PRD_TO  - :NEW.KTM_PRD_FM + 1;
    IF V_TGT_DAYS BETWEEN 0 AND 1 THEN
       V_TGT_TYPE := 'D';
    ELSIF V_TGT_DAYS BETWEEN 6 AND 8 THEN
       V_TGT_TYPE := 'W';
    ELSIF V_TGT_DAYS BETWEEN 14 AND 16 THEN
       V_TGT_TYPE := 'F';
    ELSIF V_TGT_DAYS BETWEEN 28 AND 32 THEN
       V_TGT_TYPE := 'M';
    ELSIF V_TGT_DAYS BETWEEN 88 AND 92 THEN
       V_TGT_TYPE := 'Q';
    ELSIF V_TGT_DAYS BETWEEN 175 AND 185 THEN
       V_TGT_TYPE := 'H';
    ELSIF V_TGT_DAYS BETWEEN 363 AND 367 THEN
       V_TGT_TYPE := 'Y';
    END IF;

    FOR KPIS IN (
                SELECT KPI_ID, KPI_NO, KPI_DESC, KPI_PARENT_ID,
                       KPI_STD_PTS,
                       KPI_STD_TGT,
                       KPI_DIT_CODE,
                       KPI_TGT_UNIT,
                       KPI_MIN_ACH,
                       KPI_MAX_ACH,
                       KPI_TP
                 FROM KPI_SETUP_MASTER,INV_SM_LOCATION
                 WHERE :NEW.KTM_MST_LOC = MLC_CODE
                 AND   MLC_CP_CODE = '01'
                 AND ((KPI_LOC_TYPE = DECODE(SUBSTR(:new.KTM_MST_LOC,1,1),'W','D','N','Z',SUBSTR(:new.KTM_MST_LOC,1,1)) AND SUBSTR(:new.KTM_MST_LOC,1,1) NOT IN ('S','P','U','M','T')) OR 
                      (KPI_LOC_TYPE = 'T' AND SUBSTR(:NEW.KTM_MST_LOC,1,1) = 'T' AND UPPER(MLC_DESC) NOT LIKE '%DMSS%') OR 
                      (KPI_LOC_TYPE = 'S' AND SUBSTR(:NEW.KTM_MST_LOC,1,1) = 'S' AND MLC_DESC NOT LIKE '%Tso%') OR 
                      (KPI_LOC_TYPE = 'D' AND SUBSTR(:NEW.KTM_MST_LOC,1,1) = 'S' AND MLC_DESC LIKE '%Tso%') OR
                      (KPI_LOC_TYPE = 'B' AND SUBSTR(:NEW.KTM_MST_LOC,1,1) = 'P' AND MLC_DESC LIKE '%Thse%') OR
                      (KPI_LOC_TYPE = 'C' AND SUBSTR(:NEW.KTM_MST_LOC,1,1) = 'P' AND MLC_DESC LIKE '%Chse%') OR
                      (KPI_LOC_TYPE = 'F' AND SUBSTR(:NEW.KTM_MST_LOC,1,1) = 'P' AND MLC_DESC LIKE '%Fho%') OR
                      (KPI_LOC_TYPE = 'K' AND SUBSTR(:NEW.KTM_MST_LOC,1,1) = 'P' AND MLC_DESC LIKE '%Fow%') OR
                      (KPI_LOC_TYPE = 'L' AND SUBSTR(:NEW.KTM_MST_LOC,1,1) = 'P' AND MLC_DESC LIKE '%Mow%') OR
                      (KPI_LOC_TYPE = 'U' AND SUBSTR(:new.KTM_MST_LOC,1,1) = 'U' AND MLC_DESC NOT LIKE '%Glmr%' AND KPI_NO NOT LIKE 'Q%') OR
                      (KPI_LOC_TYPE = 'G' AND SUBSTR(:new.KTM_MST_LOC,1,1) = 'U' AND MLC_DESC LIKE '%Glmr%') OR
                      (KPI_LOC_TYPE = 'A' AND SUBSTR(:new.KTM_MST_LOC,1,1) = 'M' AND MLC_DESC LIKE '%ASMM%') OR
                      (KPI_LOC_TYPE = 'O' AND SUBSTR(:new.KTM_MST_LOC,1,1) = 'M' AND MLC_DESC LIKE '%Amo%') OR
                      (KPI_LOC_TYPE = 'H' AND SUBSTR(:new.KTM_MST_LOC,1,1) = 'M' AND UPPER(MLC_DESC) LIKE '%MHS%') OR
                      (KPI_LOC_TYPE = 'E' AND SUBSTR(:new.KTM_MST_LOC,1,1) = 'M' AND UPPER(MLC_DESC) LIKE '%MIPC%') OR
                      (KPI_LOC_TYPE = 'J' AND SUBSTR(:new.KTM_MST_LOC,1,1) = 'M' AND UPPER(MLC_DESC) LIKE '%MMR%') OR
                      (KPI_LOC_TYPE = 'Q' AND SUBSTR(:new.KTM_MST_LOC,1,1) = 'T' AND UPPER(MLC_DESC) LIKE '%DMSS%')
                     )
--                 AND KPI_TGT_TYPE = V_TGT_TYPE
                 AND KPI_TGT_TYPE = 'M'
                 AND KPI_ACTIVE    = 'Y'
                 AND KPI_NO LIKE '2.6%'
                 ORDER BY KPI_LOC_TYPE, KPI_ID ASC
                     ) LOOP
         INSERT INTO KPI_TRANS_DETAIL
           (KTD_KTM_ID,  KTD_KPI_ID,  KTD_KPI_NO,
            KTD_KPI_DESC, KTD_DIT_CODE, KTD_KPI_PARENT_ID,
            KTD_PTS_TOT, KTD_TGT_TOT, KTD_TGT_UNIT,
            KTD_MIN_ACH, KTD_MAX_ACH, KTD_TP,
            KTD_INS_USER,KTD_INS_DATE)
         VALUES
           (:NEW.KTM_ID, KPIS.KPI_ID, KPIS.KPI_NO, KPIS.KPI_DESC,
            KPIS.KPI_DIT_CODE, KPIS.KPI_PARENT_ID,
            KPIS.KPI_STD_PTS,
            KPIS.KPI_STD_TGT, KPIS.KPI_TGT_UNIT,
            KPIS.KPI_MIN_ACH, KPIS.KPI_MAX_ACH, KPIS.KPI_TP,
            :NEW.KTM_INS_USER, :NEW.KTM_INS_DATE);
    END LOOP;
 END IF;
END;
END;
/

