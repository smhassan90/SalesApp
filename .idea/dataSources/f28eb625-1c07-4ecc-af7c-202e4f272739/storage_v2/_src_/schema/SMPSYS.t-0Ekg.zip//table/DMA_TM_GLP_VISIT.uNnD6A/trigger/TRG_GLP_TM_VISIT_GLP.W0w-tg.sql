create trigger TRG_GLP_TM_VISIT_GLP
  before insert
  on DMA_TM_GLP_VISIT
  for each row
  begin
 SELECT SQ_DMA_TM_VISIT_GLP.NEXTVAL INTO :NEW.DTG_VIS_ID FROM DUAL;
 end;
/

