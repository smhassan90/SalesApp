create view PRODUCT_MNTH_SALES_16 as
  SELECT /*+ USE_HASH(PCM,ISIM,ISIC,SSCS,ISI,STDSH) */
DISTINCT DSL_CUS_CODE,
         DSL_smp_twn,
          SUM((STDSH.dsl_sale_qty * ISI.DIT_UNIT)) SALES,

         CASE

           WHEN SUM((STDSH.dsl_sale_qty * ISI.DIT_UNIT)) <= 0 THEN
            '0-LESS'
           WHEN SUM((STDSH.dsl_sale_qty * ISI.DIT_UNIT)) BETWEEN '1' AND '50' THEN
            '1-50'
           WHEN SUM((STDSH.dsl_sale_qty * ISI.DIT_UNIT)) BETWEEN '51' AND
                '100' THEN
            '51-100'
           WHEN SUM((STDSH.dsl_sale_qty * ISI.DIT_UNIT)) BETWEEN '101' AND
                '150' THEN
            '101-150'
           WHEN SUM((STDSH.dsl_sale_qty * ISI.DIT_UNIT)) BETWEEN '151' AND
                '200' THEN
            '151-200'

           WHEN SUM((STDSH.dsl_sale_qty * ISI.DIT_UNIT)) BETWEEN '201' AND
                '250' THEN
            '201-250'
           WHEN SUM((STDSH.dsl_sale_qty * ISI.DIT_UNIT)) BETWEEN '251' AND
                '300' THEN
            '251-300'

           WHEN SUM((STDSH.dsl_sale_qty * ISI.DIT_UNIT)) BETWEEN '301' AND
                '350' THEN
            '301-350'
           WHEN SUM((STDSH.dsl_sale_qty * ISI.DIT_UNIT)) BETWEEN '351' AND
                '400' THEN
            '351-400'

           WHEN SUM((STDSH.dsl_sale_qty * ISI.DIT_UNIT)) BETWEEN '401' AND
                '450' THEN
            '401-450'
           WHEN SUM((STDSH.dsl_sale_qty * ISI.DIT_UNIT)) BETWEEN '451' AND
                '500' THEN
            '451-500'

           WHEN SUM((STDSH.dsl_sale_qty * ISI.DIT_UNIT)) BETWEEN '501' AND
                '550' THEN
            '501-550'
           WHEN SUM((STDSH.dsl_sale_qty * ISI.DIT_UNIT)) BETWEEN '551' AND
                '600' THEN
            '551-600'

           ELSE
            '>600'
         END BANDS,

         TO_CHAR(STDSH.DSL_DATE, 'MON-RRRR') MNTH
  FROM SAL_TO_DIS_SALES_HISTORY STDSH,
       INV_SD_ITEM              ISI
 WHERE ISI.DIT_CODE = STDSH.DSL_DIT_CODE
   AND STDSH.DSL_CP_CODE = '01'
   AND isi.dit_code LIKE 'STH%'
   AND STDSH.DSL_CUS_CAT = 'RT'
   AND ISI.DIT_CP_CODE = STDSH.DSL_CP_CODE
   --AND STDSH.DSL_DATE >= '01-JAN-2012'
   AND STDSH.DSL_DATE BETWEEN '01-JAN-2012' AND '31-MAR-2013'
 GROUP BY DSL_CUS_CODE,
          DSL_smp_twn,
           TO_CHAR(STDSH.DSL_DATE, 'MON-RRRR')
/

