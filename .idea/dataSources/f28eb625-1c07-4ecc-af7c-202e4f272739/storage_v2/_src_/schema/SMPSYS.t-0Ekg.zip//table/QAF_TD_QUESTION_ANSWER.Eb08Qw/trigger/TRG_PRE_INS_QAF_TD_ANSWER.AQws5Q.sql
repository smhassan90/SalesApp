create trigger TRG_PRE_INS_QAF_TD_ANSWER
  before insert
  on QAF_TD_QUESTION_ANSWER
  for each row
  begin
 SELECT SQ_QAF_TD_QUESTION_ANSWER.NEXTVAL INTO :NEW.QAQ_ID FROM DUAL;
 end;
/

