create view SVS_CLIENT_REG_PKD_VU as
  SELECT /*+ CPU_COSTING */ REGION_CODE,
       ZONE_CODE,
       BR_CODE,
       DOC_DATE,
       FORM_NO,
       STAFF_CODE,
       MPV_CODE,
       OTL_CODE,
       CLIENT_NAME,
       CLIENT_ADDRESS,
       CLIENT_AGE,
       HUSB_NAME,
       CONTACT_NO,
       HUSB_NIC,
       CLIENT_EDU,
       AREA,
       DIST_CODE,
       DIST_NAME,
       TEHSIL_CODE,
       TEHSIL_NAME,
       UC,
       PREG_PERIOD,
       POVERTY_SCORE,
       VCH_NUM,
       MAX(CASE WHEN VCH_NUM = 1
   AND DCH_ID = 102 THEN VALUE
                WHEN VCH_NUM = 2
   AND DCH_ID = 113 THEN VALUE
                WHEN VCH_NUM = 3
   AND DCH_ID = 124 THEN VALUE
                WHEN VCH_NUM = 4
   AND DCH_ID = 135 THEN VALUE
                WHEN VCH_NUM = 5
   AND DCH_ID = 146 THEN VALUE
                WHEN VCH_NUM = 6
   AND DCH_ID = 157 THEN VALUE
                WHEN VCH_NUM = 7
   AND DCH_ID = 168 THEN VALUE
                WHEN VCH_NUM = 8
   AND DCH_ID = 176 THEN VALUE
                WHEN VCH_NUM = 9
   AND DCH_ID = 184 THEN VALUE
                WHEN VCH_NUM = 10
   AND DCH_ID = 194 THEN VALUE
                WHEN VCH_NUM = 11
   AND DCH_ID = 204 THEN VALUE
                WHEN VCH_NUM = 12
   AND DCH_ID = 215 THEN VALUE
                WHEN VCH_NUM = 13
   AND DCH_ID = 226 THEN VALUE END) VCH_STATUS,
       MAX(CASE WHEN VCH_NUM = 1
   AND DCH_ID = 99 THEN VALUE
                WHEN VCH_NUM = 2
   AND DCH_ID = 110 THEN VALUE
                WHEN VCH_NUM = 3
   AND DCH_ID = 121 THEN VALUE
                WHEN VCH_NUM = 4
   AND DCH_ID = 132 THEN VALUE
                WHEN VCH_NUM = 5
   AND DCH_ID = 143 THEN VALUE
                WHEN VCH_NUM = 6
   AND DCH_ID = 154 THEN VALUE
                WHEN VCH_NUM = 7
   AND DCH_ID = 165 THEN VALUE
                WHEN VCH_NUM = 8
   AND DCH_ID = 173 THEN VALUE
                WHEN VCH_NUM = 9
   AND DCH_ID = 181 THEN VALUE
                WHEN VCH_NUM = 10
   AND DCH_ID = 191 THEN VALUE
                WHEN VCH_NUM = 11
   AND DCH_ID = 201 THEN VALUE
                WHEN VCH_NUM = 12
   AND DCH_ID = 212 THEN VALUE
                WHEN VCH_NUM = 13
   AND DCH_ID = 223 THEN VALUE END) VCH_PRV,
       MAX(CASE WHEN VCH_NUM = 1
   AND DCH_ID = 100 THEN VALUE
                WHEN VCH_NUM = 2
   AND DCH_ID = 111 THEN VALUE
                WHEN VCH_NUM = 3
   AND DCH_ID = 122 THEN VALUE
                WHEN VCH_NUM = 4
   AND DCH_ID = 133 THEN VALUE
                WHEN VCH_NUM = 5
   AND DCH_ID = 144 THEN VALUE
                WHEN VCH_NUM = 6
   AND DCH_ID = 155 THEN VALUE
                WHEN VCH_NUM = 7
   AND DCH_ID = 166 THEN VALUE
                WHEN VCH_NUM = 8
   AND DCH_ID = 174 THEN VALUE
                WHEN VCH_NUM = 9
   AND DCH_ID = 182 THEN VALUE
                WHEN VCH_NUM = 10
   AND DCH_ID = 192 THEN VALUE
                WHEN VCH_NUM = 11
   AND DCH_ID = 202 THEN VALUE
                WHEN VCH_NUM = 12
   AND DCH_ID = 213 THEN VALUE
                WHEN VCH_NUM = 13
   AND DCH_ID = 224 THEN VALUE END) VCH_OTL,
       MAX(CASE WHEN VCH_NUM = 1
   AND DCH_ID = 101 THEN VALUE
                WHEN VCH_NUM = 2
   AND DCH_ID = 112 THEN VALUE
                WHEN VCH_NUM = 3
   AND DCH_ID = 123 THEN VALUE
                WHEN VCH_NUM = 4
   AND DCH_ID = 134 THEN VALUE
                WHEN VCH_NUM = 5
   AND DCH_ID = 145 THEN VALUE
                WHEN VCH_NUM = 6
   AND DCH_ID = 156 THEN VALUE
                WHEN VCH_NUM = 7
   AND DCH_ID = 167 THEN VALUE
                WHEN VCH_NUM = 8
   AND DCH_ID = 175 THEN VALUE
                WHEN VCH_NUM = 9
   AND DCH_ID = 183 THEN VALUE
                WHEN VCH_NUM = 10
   AND DCH_ID = 193 THEN VALUE
                WHEN VCH_NUM = 11
   AND DCH_ID = 203 THEN VALUE
                WHEN VCH_NUM = 12
   AND DCH_ID = 214 THEN VALUE
                WHEN VCH_NUM = 13
   AND DCH_ID = 225 THEN VALUE END) VCH_STAFF,
       MAX(CASE WHEN VCH_NUM = 1
   AND DCH_ID = 103 THEN VALUE
                WHEN VCH_NUM = 2
   AND DCH_ID = 114 THEN VALUE
                WHEN VCH_NUM = 3
   AND DCH_ID = 125 THEN VALUE
                WHEN VCH_NUM = 4
   AND DCH_ID = 136 THEN VALUE
                WHEN VCH_NUM = 5
   AND DCH_ID = 147 THEN VALUE
                WHEN VCH_NUM = 6
   AND DCH_ID = 158 THEN VALUE
                WHEN VCH_NUM = 7
   AND DCH_ID = 169 THEN VALUE
                WHEN VCH_NUM = 8
   AND DCH_ID = 177 THEN VALUE
                WHEN VCH_NUM = 9
   AND DCH_ID = 185 THEN VALUE
                WHEN VCH_NUM = 10
   AND DCH_ID = 195 THEN VALUE
                WHEN VCH_NUM = 11
   AND DCH_ID = 205 THEN VALUE
                WHEN VCH_NUM = 12
   AND DCH_ID = 216 THEN VALUE
                WHEN VCH_NUM = 13
   AND DCH_ID = 227 THEN VALUE END) VCH_VOUCHER_COST,
       TO_DATE(MAX(CASE WHEN VCH_NUM = 1
   AND DCH_ID = 93 THEN VALUE
                        WHEN VCH_NUM = 2
   AND DCH_ID = 104 THEN VALUE
                        WHEN VCH_NUM = 3
   AND DCH_ID = 115 THEN VALUE
                        WHEN VCH_NUM = 4
   AND DCH_ID = 126 THEN VALUE
                        WHEN VCH_NUM = 5
   AND DCH_ID = 137 THEN VALUE
                        WHEN VCH_NUM = 6
   AND DCH_ID = 148 THEN VALUE
                        WHEN VCH_NUM = 7
   AND DCH_ID = 159 THEN VALUE
                        WHEN VCH_NUM = 8
   AND DCH_ID = 170 THEN VALUE
                        WHEN VCH_NUM = 9
   AND DCH_ID = 178 THEN VALUE
                        WHEN VCH_NUM = 10
   AND DCH_ID = 186 THEN VALUE
                        WHEN VCH_NUM = 11
   AND DCH_ID = 196 THEN VALUE
                        WHEN VCH_NUM = 12
   AND DCH_ID = 206 THEN VALUE
                        WHEN VCH_NUM = 13
   AND DCH_ID = 217 THEN VALUE END), 'DD/MM/YYYY') VCH_RDM_DATE
  FROM (SELECT M.SIC_REG_CODE REGION_CODE,
               M.SIC_ZON_CODE ZONE_CODE,
               M.SIC_BR_CODE BR_CODE,
               M.SIC_DOC_DATE DOC_DATE,
               M.SIC_FORM_NO FORM_NO,
               M.SIC_STAFF_CODE STAFF_CODE,
               M.SIC_MPV MPV_CODE,
               M.SIC_OTL OTL_CODE,
               M.SIC_CLIENT_NAME CLIENT_NAME,
               M.SIC_CLIENT_ADDRESS CLIENT_ADDRESS,
               M.SIC_CLIENT_AGE CLIENT_AGE,
               M.SIC_HUSB_NAME HUSB_NAME,
               M.SIC_CONTACT_NO CONTACT_NO,
               M.SIC_HUSB_NIC HUSB_NIC,
               M.SIC_CLIENT_EDU CLIENT_EDU,
               M.SIC_AREA AREA,
               S.TUC_DIST_CODE DIST_CODE,
               S.TUC_DIST DIST_NAME,
               S.TUC_TEHSIL_CODE TEHSIL_CODE,
               S.TUC_TEHSIL TEHSIL_NAME,
               S.TUC_UC UC,
               M.SIC_PREG_PERIOD PREG_PERIOD,
               M.SIC_POVERTY_SCORE POVERTY_SCORE,
               M.SIC_VOUCHER_DIST_DATE VOUCHER_DIST_DATE,
               V.VCH_NUM,
               T.DCH_ID,
               T.DCH_IND_DESC IND_DESC,
               D.ICD_COL_VALUE VALUE
          FROM SVS_INTERVIEW_CLIENT M,
               SVS_INTERVIEW_CLIENT_DETAIL D,
               SVS_VOUCHERS V,
               SVC_TD_VOUCHERS T,
               SVS_TEHSIL_UC_SETUP S
         WHERE M.SIC_CP_CODE = '01'
           AND M.SIC_ID = D.ICD_SIC_ID
           AND D.ICD_DCH_ID = T.DCH_ID
           AND T.DCH_VCH_CODE = V.VCH_CODE
           AND M.SIC_UC_NO = S.TUC_UC
           AND M.SIC_PROJECT = 'PACKARD'
           AND S.TUC_TEHSIL_CODE = M.SIC_TEHSIL)
 GROUP BY REGION_CODE, ZONE_CODE, BR_CODE, DOC_DATE, FORM_NO, STAFF_CODE, MPV_CODE, OTL_CODE, CLIENT_NAME, CLIENT_ADDRESS, CLIENT_AGE, HUSB_NAME, CONTACT_NO, HUSB_NIC, CLIENT_EDU, AREA, DIST_CODE, DIST_NAME, TEHSIL_CODE, TEHSIL_NAME, UC, PREG_PERIOD, POVERTY_SCORE, VOUCHER_DIST_DATE, VCH_NUM
/

