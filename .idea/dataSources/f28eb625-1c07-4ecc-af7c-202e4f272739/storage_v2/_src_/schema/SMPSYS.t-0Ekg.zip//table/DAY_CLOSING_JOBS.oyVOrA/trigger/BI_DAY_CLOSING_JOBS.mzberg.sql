create trigger BI_DAY_CLOSING_JOBS
  before insert
  on DAY_CLOSING_JOBS
  for each row
  begin
    select SQ_DAY_CLOSING_JOBS.nextval INTO :new.DCJ_ID
    from dual;
end;
/

