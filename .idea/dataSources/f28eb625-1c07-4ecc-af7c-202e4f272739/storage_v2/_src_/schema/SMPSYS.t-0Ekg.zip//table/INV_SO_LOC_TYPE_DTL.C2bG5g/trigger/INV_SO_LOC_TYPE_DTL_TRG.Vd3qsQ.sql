create trigger INV_SO_LOC_TYPE_DTL_TRG
  before insert
  on INV_SO_LOC_TYPE_DTL
  for each row
  begin
IF :NEW.DTL_ID IS NULL then
    select INV_SO_LOC_TYPE_DTL_SEQ.nextval INTO :NEW.DTL_ID
    from dual;
END IF;
end;
/

