create trigger IPC_CLIENT_REG_TR_TRG
  before insert
  on IPC_CLIENT_REG_TR
  for each row
  begin
  IF :NEW.ID IS NULL THEN
    SELECT IPC_CLIENT_REG_TR_SEQ.NEXTVAL INTO :NEW.ID FROM DUAL;
  END IF;
end;

/

