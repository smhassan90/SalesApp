create trigger BI_LMS_CM_COL
  before insert
  on LMS_CM_COL
  for each row
  begin  
    select "LMS_CM_COL_SEQ".nextval into :NEW.CM_COL_ID from dual;
end;
/

