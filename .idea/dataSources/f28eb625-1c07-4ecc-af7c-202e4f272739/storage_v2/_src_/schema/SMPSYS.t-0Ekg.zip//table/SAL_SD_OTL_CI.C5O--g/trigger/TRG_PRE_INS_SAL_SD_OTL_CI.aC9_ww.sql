create trigger TRG_PRE_INS_SAL_SD_OTL_CI
  before insert
  on SAL_SD_OTL_CI
  for each row
  begin
IF :NEW.DCI_ID IS NULL THEN
   :NEW.DCI_ID := :NEW.DCI_OTL_CODE||'-'||:NEW.DCI_DID_CODE;
END IF;
END;
/

