create trigger TRG_PINS_SAL_SD_PRV_CFTION
  before insert
  on SAL_SD_PRV_CLASSIFICATION
  for each row
  begin
IF :NEW.DPC_ID IS NULL THEN
   :NEW.DPC_ID := :NEW.DPC_MPV_CODE||'-'||:NEW.DPC_PRV_CLASS||'-'||:NEW.DPC_EFF_DATE;
END IF;
END;
/

