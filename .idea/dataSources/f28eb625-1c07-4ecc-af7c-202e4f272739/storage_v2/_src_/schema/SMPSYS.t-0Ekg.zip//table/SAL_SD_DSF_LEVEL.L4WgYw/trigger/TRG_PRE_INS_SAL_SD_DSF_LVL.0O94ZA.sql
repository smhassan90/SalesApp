create trigger TRG_PRE_INS_SAL_SD_DSF_LVL
  before insert
  on SAL_SD_DSF_LEVEL
  for each row
  begin
   SELECT SQ_SAL_SD_DSF_LEVEL.NEXTVAL INTO :NEW.DDL_ID FROM DUAL;
END;
/

