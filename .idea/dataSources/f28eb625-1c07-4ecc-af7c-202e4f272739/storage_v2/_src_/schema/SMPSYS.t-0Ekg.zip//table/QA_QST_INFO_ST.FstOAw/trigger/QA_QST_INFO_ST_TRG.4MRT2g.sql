create trigger QA_QST_INFO_ST_TRG
  before insert
  on QA_QST_INFO_ST
  for each row
  begin
  IF :NEW.QST_ID IS NULL THEN
    SELECT QA_QST_INFO_ST_SEQ.NEXTVAL INTO :NEW.QST_ID FROM DUAL;
  END IF;
end;

/

