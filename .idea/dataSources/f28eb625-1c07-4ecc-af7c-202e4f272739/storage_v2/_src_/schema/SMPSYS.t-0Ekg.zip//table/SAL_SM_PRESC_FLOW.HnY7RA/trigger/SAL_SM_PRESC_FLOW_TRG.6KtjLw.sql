create trigger SAL_SM_PRESC_FLOW_TRG
  before insert
  on SAL_SM_PRESC_FLOW
  for each row
  begin
 SELECT SAL_SM_PRESC_FLOW_SEQ.NEXTVAL INTO :NEW.PRC_ID FROM DUAL;
 end;
/

