create trigger TRG_PRE_INS_SAL_SEC_SALES_MAST
  before insert
  on SAL_SEC_SALES_MASTER
  for each row
  begin
  SELECT SQ_SAL_SEC_SALES_MASTER.NEXTVAL INTO :NEW.MSS_ID FROM DUAL;
end;
/

