create trigger TRG_BI_SAL_TD_DIS_STOCK
  before insert
  on SAL_TD_DIS_STOCK
  for each row
  begin
  SELECT SQ_SAL_TD_DIS_STOCK.NEXTVAL INTO :NEW.DDS_ID FROM DUAL;
end;
/

