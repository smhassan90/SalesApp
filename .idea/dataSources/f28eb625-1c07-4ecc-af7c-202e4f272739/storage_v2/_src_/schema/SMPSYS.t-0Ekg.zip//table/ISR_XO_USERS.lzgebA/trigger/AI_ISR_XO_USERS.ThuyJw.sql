create trigger AI_ISR_XO_USERS
  after insert
  on ISR_XO_USERS
  for each row
  DECLARE CURSOR C1 IS
SELECT   
DSC_CP_CODE, DSC_ID
FROM ISR_XD_SECURITY
WHERE DSC_SEC_CODE = :NEW.USR_SEC_CODE
AND DSC_CP_CODE = :NEW.USR_CP_CODE;
BEGIN
FOR V_C1 IN C1 LOOP
INSERT INTO ISR_XD_SECURITY_DTL (DDS_CP_CODE,DDS_DSC_ID,DDS_USR_NAME,DDS_FLAG,dds_ins, dds_upd, dds_del, dds_qry, dds_exe, dds_start_date)
                        VALUES  (V_C1.DSC_CP_CODE,V_C1.DSC_ID,:NEW.USR_NAME,'Y','N','N','N','N','N',sysdate);
END LOOP;
END;
/

