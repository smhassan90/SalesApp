create trigger GSM_SMS_POSTS_TRG
  before insert
  on GSM_SMS_POSTS
  for each row
  begin
  SELECT GSM_SMS_POSTS_SEQ.NEXTVAL INTO :NEW.ID FROM DUAL;
end;
/

