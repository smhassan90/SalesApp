create view SMP_VDN_VIEW_BLACKOUTSCHEDULES as
  SELECT 
   schedule.targetid,
   target.name,
   target.type,
   schedule.schedulename, 
   schedule.schedulestate, 
   schedule.schedule,
   schedule.start_time, 
   schedule.end_time, 
   schedule.duration_length, 
   schedule.units, 
   schedule.duration_mode, 
   target.totalblackout
FROM 
   SMP_VDN_BLACKOUTSCHEDULE schedule,
   SMP_VDN_VIEW_TARGET_LIST target
WHERE
   schedule.targetid = target.id
/

