create trigger BI_ADC_SM_CLIENT
  before insert
  on ADC_SM_CLIENT
  for each row
  begin
 SELECT SQ_ADC_SM_CLIENT.NEXTVAL INTO :NEW.ASC_ID FROM DUAL;
 end;
/

