create trigger TRG_PRE_INS_MCQUIZ_TM
  before insert
  on MCQUIZ_TM
  for each row
  begin
 SELECT SQ_MCQUIZ_TM.NEXTVAL INTO :NEW.MTM_ID FROM DUAL;
 end;
/

