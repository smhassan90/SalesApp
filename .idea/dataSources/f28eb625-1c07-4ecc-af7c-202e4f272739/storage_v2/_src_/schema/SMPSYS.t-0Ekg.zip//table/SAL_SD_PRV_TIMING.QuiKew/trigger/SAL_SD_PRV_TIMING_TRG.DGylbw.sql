create trigger SAL_SD_PRV_TIMING_TRG
  before insert
  on SAL_SD_PRV_TIMING
  for each row
  begin
 SELECT SAL_SD_PRV_TIMING_SEQ.NEXTVAL INTO :NEW.DTM_ID FROM DUAL;
 end;
/

