create trigger TRG_PRE_INS_ISR_XD_USR_BR
  before insert
  on ISR_XD_USERS_BRANCH
  for each row
  begin
  select SQ_ISR_XD_USR_BR.NEXTVAL into :NEW.DBR_ID from dual;
end;
/

