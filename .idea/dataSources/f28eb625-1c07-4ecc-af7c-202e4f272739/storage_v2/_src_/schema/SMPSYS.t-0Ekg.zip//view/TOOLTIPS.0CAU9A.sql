create view TOOLTIPS as
  SELECT     IND.IND_ID IND_ID,
           CASE       -- green --
                WHEN IND.VALUE < IND.ORANGE_ALERT
                THEN  
                   (CASE  
                       WHEN UN.GREEN_PREFIX IS NULL AND UN.GREEN_SUFFIX IS NULL 
                       THEN  
                          ': )'
                       ELSE  
                          UN.GREEN_PREFIX || ' ' || IND.VALUE || ' ' || IND.SUFFIX || ' ' || UN.GREEN_SUFFIX
                   END)  
                WHEN    IND.VALUE BETWEEN IND.ORANGE_ALERT AND IND.RED_ALERT  -- orange --
                THEN
                   (CASE  
                       WHEN UN.ORANGE_PREFIX IS NULL AND UN.ORANGE_SUFFIX IS NULL 
                       THEN  
                          'Dangerously close to ' || TO_CHAR (IND.RED_ALERT , 'FM999G999G990') || ' ' || UN.UNIT
                       ELSE  
                          UN.ORANGE_PREFIX || ' ' || IND.VALUE || ' ' || IND.SUFFIX || ' ' || UN.ORANGE_SUFFIX
                   END)  
                ELSE  -- red --
                   (CASE  
                       WHEN UN.RED_PREFIX IS NULL AND UN.RED_SUFFIX IS NULL 
                       THEN  
                           TO_CHAR (IND.VALUE, 'FM999G999G990') || ' ' || UN.UNIT || ' is unacceptable. I want a solution in 15 minutes (or less)'
                       ELSE  
                          UN.RED_PREFIX || ' ' || IND.VALUE || ' ' || IND.SUFFIX || ' ' || UN.RED_SUFFIX
                   END)  
           END TOOLTIP
FROM       INDICATORS IND
LEFT OUTER JOIN UNITS UN ON IND.UNIT = UN.UNIT_ID
/

