create view SMP_VIEW_VDM_ADDRESS as
  select sequence_num, proxy
         FROM SMP_VDM_ADDRESS 
          group by sequence_num, proxy
/

