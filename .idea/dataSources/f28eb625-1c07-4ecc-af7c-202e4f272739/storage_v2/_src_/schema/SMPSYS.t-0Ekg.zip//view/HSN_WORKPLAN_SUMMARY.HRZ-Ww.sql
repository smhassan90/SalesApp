create view HSN_WORKPLAN_SUMMARY as
  select 
hsw.hs_staff_code staff_code,
hsw.hs_act_date activity_date,
count(hsw.hs_activity) total
from HS_WORKPLAN hsw
join GSM_SMS_POSTS p on (hsw.hs_staff_code = p.staff_code and p.EFF_DATE = (select max(eff_date) from GSM_SMS_POSTS ti where ti.staff_code = p.staff_code) and p.DESIG in ('AMN','QAM','FPC','ISOW'))
group by hsw.hs_staff_code, hsw.hs_act_date
order by hsw.hs_staff_code, hsw.hs_act_date
/

