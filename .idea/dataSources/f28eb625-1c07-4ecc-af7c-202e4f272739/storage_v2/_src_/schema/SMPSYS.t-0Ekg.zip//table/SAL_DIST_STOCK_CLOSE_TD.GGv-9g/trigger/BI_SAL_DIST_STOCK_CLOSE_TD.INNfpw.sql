create trigger BI_SAL_DIST_STOCK_CLOSE_TD
  before insert
  on SAL_DIST_STOCK_CLOSE_TD
  for each row
  begin
 SELECT SQ_SAL_DIST_STOCK_CLOSE_TM.NEXTVAL INTO :NEW.SDT_ID FROM DUAL;
 end;
/

