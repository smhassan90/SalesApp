create trigger BI_KPI_TRANS_ASSESMENT_DETAIL
  before insert
  on KPI_TRANS_ASSESMENT_DETAIL
  for each row
  begin
    select KPI_TRANS_ASSESMENT_DETAIL_SEQ.nextval into :NEW.KAD_ID from dual;
end;
/

