create trigger TRG_PRE_GSC_AUTHORIZE_USER
  before insert
  on GSC_AUTHORIZE_USER
  for each row
  begin
 SELECT SQ_GSC_AUTHORIZE_USER.NEXTVAL INTO :NEW.AUTH_ID FROM DUAL;
 end;

/

