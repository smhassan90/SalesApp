create view SMP_VIEW_VDD_OPERATIONS as
  select sequence_num, owner, node, outgoing from smp_vdd_operations_table 
        group by sequence_num, owner, node, outgoing
/

