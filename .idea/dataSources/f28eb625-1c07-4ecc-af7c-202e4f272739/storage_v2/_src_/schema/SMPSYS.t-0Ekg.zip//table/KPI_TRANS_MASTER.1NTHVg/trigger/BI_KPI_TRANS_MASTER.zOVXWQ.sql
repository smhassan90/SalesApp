create trigger BI_KPI_TRANS_MASTER
  before insert
  on KPI_TRANS_MASTER
  for each row
  begin
    select "KPI_TRANS_MASTER_SEQ".nextval into :NEW.KTM_ID from dual;
end;
/

