create view SALES_LEVEL as
  select d.dsl_msl_code, m.msl_desc m_desc,
       d.dsl_sub_code, m1.msl_desc t_desc
from   sal_sm_sales_level m, sal_sm_sales_level m1, sal_sd_sales_level d
where  m.msl_code = d.dsl_msl_code
and    m1.msl_code = d.dsl_sub_code
/

