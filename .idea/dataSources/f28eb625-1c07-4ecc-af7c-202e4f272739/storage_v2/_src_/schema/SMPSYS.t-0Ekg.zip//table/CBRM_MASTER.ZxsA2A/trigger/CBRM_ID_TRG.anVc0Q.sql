create trigger CBRM_ID_TRG
  before insert
  on CBRM_MASTER
  for each row
  BEGIN
  IF  :NEW.MID IS NULL THEN
      SELECT CBRM_ID_SEQ.NEXTVAL INTO :NEW.MID FROM DUAL;
  END IF;
END;
/

