create trigger BI_IPC_TD_AR
  before insert
  on IPC_TD_AR
  for each row
  begin
  for c1 in (
    select IPC_TD_AR_SEQ.nextval next_val
    from dual
  ) loop
    :new.DAR_ID :=  c1.next_val;
  end loop;
end;
/

