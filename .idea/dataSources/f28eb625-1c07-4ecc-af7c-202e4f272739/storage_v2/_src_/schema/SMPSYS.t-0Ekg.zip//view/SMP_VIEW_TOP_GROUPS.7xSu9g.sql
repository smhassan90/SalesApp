create view SMP_VIEW_TOP_GROUPS as
  SELECT gl.name "GROUP_NAME", gl.owner "GROUP_OWNER", gl.description "DESCRIPTION",
         gl.backgroundfileurl "BACKGROUND_IMAGE",
         gl.iconsize "ICON_SIZE"
  FROM   SMP_VDN_GROUP_LIST gl 
  WHERE  NOT EXISTS ( SELECT 'x' FROM SMP_VDN_GROUP_GROUP gg WHERE gg.membergroupid = gl.id )
    AND  ( EXISTS ( SELECT 'x' FROM SMP_VDN_GROUP_TARGET gt WHERE gt.groupid = gl.id ) OR EXISTS ( SELECT 'x' FROM SMP_VDN_GROUP_GROUP gg WHERE gg.groupid = gl.id ) )

/

comment on table SMP_VIEW_TOP_GROUPS
is 'List of all toplevel non empty groups'
/

