create trigger TRG_PRE_INS_SAL_SD_POLICY_DTL
  before insert
  on SAL_SD_POLICY_DTL
  for each row
  begin
SELECT SQ_SAL_SD_POLICY_DTL.NEXTVAL INTO :NEW.DPD_ID FROM DUAL;
end;
/

