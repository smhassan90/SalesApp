create view OUTLET_PROVIDER_HIERARCHY as
  select t.dsl_sub_code "Town_Code", tn.msl_desc "Town_Name",
       o.otl_code "Outlet_code", o.otl_desc " Outlet_name",
       o.otl_add1||' '||o.otl_add2 "Outlet_address", o.otl_tel_no "Tel_No",
       p.mpv_code "Provider_Code", p.mpv_desc "Provider_Name",
       p.mpv_flag "Status", prvout.dpo_lft_date "Left_Date",
       pt.dpt_mpt_code "Provider_Type", pt.dpt_eff_date "Training_Date",
       trainer.dtr_trn_code "Trainer_code", trnname.mlc_desc "Trainer_Name",
       s.dsl_msl_code "Spo_Code", spn.mlc_desc "Spo_Name"
from   sal_sd_sales_level t, sal_sm_sales_level tn,
       sal_sd_sales_level s, inv_sm_location spn,
       sal_so_outlet o, sal_sm_provider p,
       sal_sd_prv_outlet prvout, inv_sm_location trnname,
       sal_sd_prv_training pt, sal_sd_prv_trainer trainer
where  substr(t.dsl_msl_code,1,1) = 'C'
and    t.dsl_sub_code = tn.msl_code
and    s.dsl_sub_code = t.dsl_sub_code
and    substr(s.dsl_msl_code,1,1) = 'S'
and    s.dsl_msl_code = spn.mlc_code
and    t.dsl_sub_code = substr(o.otl_code,1,5)
and    prvout.dpo_otl_code = o.otl_code
and    prvout.dpo_mpv_code = p.mpv_code
and    trainer.dtr_trn_code = trnname.mlc_code
and    pt.dpt_mpv_code = p.mpv_code
and    pt.dpt_eff_date = (select max(prvt.dpt_eff_date) from sal_sd_prv_training prvt
			  where prvt.dpt_mpv_code = p.mpv_code)
and    trainer.dtr_mpv_code = p.mpv_code
and    trainer.dtr_eff_date = (select max(prvtrner.dtr_eff_date) from sal_sd_prv_trainer prvtrner
			       where prvtrner.dtr_mpv_code = p.mpv_code)
and    s.dsl_eff_date = (select max(sd.dsl_eff_date) from sal_sd_sales_level sd
			 where sd.dsl_sub_code = s.dsl_sub_code
   			 and substr(dsl_msl_code,1,1) = 'S')
/

