create trigger TRG_PRE_INS_MCQUIZ_POSITION
  before insert
  on MCQUIZ_POSITION
  for each row
  begin
 SELECT SQ_MCQUIZ_POSITION.NEXTVAL INTO :NEW.MP_ID FROM DUAL;
 end;
/

