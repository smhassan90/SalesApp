create view VW_QA_CLIENT_RECORD as
  select "TR_DTL_ID","TR_CLIENT_ID","TR_QST_ID","TR_QST_CODE","TR_RSP_ID","TR_RSP_CODE","RSP_CH_ID","RSP_CH_CODE","DATA_VALUE","DATA_DESCRIPTION"
  from qa_client_detail_tr D
 where d.tr_client_id in (select t.client_code from qa_client_master_tr t)
/

