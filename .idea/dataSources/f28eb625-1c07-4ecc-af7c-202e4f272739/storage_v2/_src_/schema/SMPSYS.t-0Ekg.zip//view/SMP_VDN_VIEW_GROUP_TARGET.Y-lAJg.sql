create view SMP_VDN_VIEW_GROUP_TARGET as
  SELECT
    ParentGrp.Owner,
    ParentGrp.Name,
    Target.Name,
    Type.Name,
    gt.x, 
    gt.y
   FROM
    smp_vdn_group_Target gt,
    smp_vdn_group_list ParentGrp,
    smp_vdn_Target_list Target,
    smp_vdn_Target_Type_defn Type
   WHERE
    Target.Id = gt.TargetId AND
    ParentGrp.Id = gt.GroupId AND
    Type.Id = Target.TypeId
/

