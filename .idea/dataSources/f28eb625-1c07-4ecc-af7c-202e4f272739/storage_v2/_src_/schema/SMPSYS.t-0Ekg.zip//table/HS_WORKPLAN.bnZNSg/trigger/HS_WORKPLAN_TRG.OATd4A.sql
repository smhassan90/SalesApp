create trigger HS_WORKPLAN_TRG
  before insert
  on HS_WORKPLAN
  for each row
  begin
  select HS_WORKPLAN_seq.Nextval into :new.HS_id from dual;
end;
/

