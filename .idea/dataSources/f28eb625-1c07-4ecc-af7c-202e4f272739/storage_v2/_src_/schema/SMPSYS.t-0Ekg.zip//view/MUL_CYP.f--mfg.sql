create view MUL_CYP as
  select sm.msl_otl_code, (sum(st.dsl_qty) + sum(dsl_bns_qty)) * 3.5
from   sal_tm_sales sm, sal_td_sales st, outlet_gstype og
where  sm.msl_num = st.dsl_msl_num
and    sm.msl_otl_code = og.outlet_code
and    st.dsl_dit_code = 'MUL002'
and    sm.msl_type = 'DS'
and    sm.msl_date between '01-JAN-04' and '31-MAR-04'
and    og.gs_type = 'GS1'
group by sm.msl_otl_code
/

