create view FFM_HSN_ACTIVITIES_V as
  select 
sms.ID,
DECODE(get_staff_loc(sms.STAFF_CODE),
                     'R001','R001-Karachi',
                     'R002','R002-Sukkur',
                     'R003','R003-Bahawalpur',
                     'R004','R004-Multan',
                     'R005','R005-Faislabad',
                     'R006','R006-Lahore',
                     'R007','R007-Gujranwala',
                     'R008','R008-Islamabad',
                     'R009','R009-Peshawar',
                     get_staff_loc(sms.STAFF_CODE)) Region,
sms.STAFF_CODE,
GET_STAFF_NAME('01',sms.STAFF_CODE) Staff,
sms.staff_designation_code designation,
sms.ACTIVITY_ID,
gsa.activity_name,
nvl((case sms.param1 when 'null' then '-' else GET_PROVIDER_STAFF_CODE(sms.param1,'01') end),'-') Param1,
case sms.param2 when 'null' then '-' else decode (gsa.activity_type, 'HouseholdVisit',sms.param2,'ProviderPlacement', sms.param2,'-') end Param2,
case sms.param3 when 'null' then '-' else sms.param3 end Param3,
sms.start_date,
sms.SMS_DATE as end_date,
sms.tdate
from SMS_SMS_ACTIVITY_RESPONSE_HS sms
join GSM_SMS_ACTVITIES gsa on (sms.activity_id = gsa.activity_id)
where sms.staff_designation_code in ('AMN','QAM','FPC','ISOW') WITH READ ONLY
/

