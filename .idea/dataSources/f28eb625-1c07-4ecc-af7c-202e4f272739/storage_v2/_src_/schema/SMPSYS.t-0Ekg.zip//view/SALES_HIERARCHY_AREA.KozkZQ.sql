create view SALES_HIERARCHY_AREA as
  select t.dsl_sub_code "Town_Code", tn.msl_desc "Town_Name",
       s.dsl_msl_code "Spo_Code", spn.mlc_desc "Spo_Name",
       c.dsl_sub_code "City_Code", cn.msl_desc "City_Name",
       r.dsl_sub_code "Zone_Code", zn.msl_desc "Zone_Name",
       r.dsl_msl_code "Region_Code", i.mlc_desc "Region_Name"
from   sal_sd_sales_level r, inv_sm_location i, sal_sd_sales_level c,
       sal_sd_sales_level t, sal_sm_sales_level tn,
       sal_sm_sales_level zn, sal_sm_sales_level cn,
       sal_sd_sales_level s, inv_sm_location spn
       where  r.dsl_msl_code = i.mlc_code
and    r.dsl_cp_Code = i.mlc_cp_Code
and    r.dsl_sub_code = c.dsl_msl_code
and    r.dsl_cp_code  = c.dsl_cp_code
and    c.dsl_sub_code = t.dsl_msl_code
and    c.dsl_cp_code  = t.dsl_cp_code
and    substr(t.dsl_msl_code,1,1) = 'A'
and    t.dsl_sub_code = tn.msl_code
and    t.dsl_cp_code  = tn.msl_cp_code
and    r.dsl_sub_code = zn.msl_code
and    r.dsl_cp_code = zn.msl_cp_code
and    c.dsl_sub_code = cn.msl_code
and    c.dsl_cp_code  = cn.msl_cp_Code
and    s.dsl_sub_code = t.dsl_sub_code
and    s.dsl_cp_Code  = t.dsl_cp_code
and    substr(s.dsl_msl_code,1,1) = 'S'
and    s.dsl_msl_code = spn.mlc_code
and    s.dsl_cp_code  = spn.mlc_cp_code
and    s.dsl_eff_date = (select max(sd.dsl_eff_date) from sal_sd_sales_level sd
			 where sd.dsl_sub_code = s.dsl_sub_code
			 and substr(dsl_msl_code,1,1) = 'S'
			 and sd.dsl_cp_Code = s.dsl_Cp_Code)
and    r.dsl_eff_date = (select max(sdl.dsl_eff_date) from sal_sd_sales_level sdl
       where sdl.dsl_sub_code = r.dsl_sub_code
       and  substr(dsl_sub_code,1,1) = 'Z'
			 and  sdl.dsl_cp_Code = s.dsl_Cp_Code)
/

