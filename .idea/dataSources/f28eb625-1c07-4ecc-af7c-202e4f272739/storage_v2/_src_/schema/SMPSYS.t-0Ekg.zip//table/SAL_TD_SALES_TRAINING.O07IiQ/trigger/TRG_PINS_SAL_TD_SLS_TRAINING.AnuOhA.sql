create trigger TRG_PINS_SAL_TD_SLS_TRAINING
  before insert
  on SAL_TD_SALES_TRAINING
  for each row
  begin
IF :NEW.TSL_ID IS NULL THEN
   :NEW.TSL_ID := :NEW.TSL_MSL_NUM||'-'||:NEW.TSL_SEQ_NUM;
END IF;
END;
/

