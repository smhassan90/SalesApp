create view FIS_PROJECT_TRANSLATION as
  SELECT INITCAP(DESCRIPTION)||'-'||FLEX_VALUE_MEANING D, FLEX_VALUE_MEANING R
  FROM FND_FLEX_VALUES_VL@FIS
 WHERE flex_value_id IN (SELECT flex_value_id
                           FROM fnd_flex_values@FIS
                          where flex_value_set_id = '1009606'
                            and summary_flag = 'N')
/

