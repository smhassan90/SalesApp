create trigger TRG_PRE_INS_SAL_SD_SAL_LVL
  before insert
  on SAL_SD_SALES_LEVEL
  for each row
  begin
IF :NEW.DSL_ID IS NULL THEN
   :NEW.DSL_ID := :NEW.DSL_MSL_CODE||'-'||:NEW.DSL_SUB_CODE||'-'||:NEW.DSL_EFF_DATE;
END IF;
END;
/

