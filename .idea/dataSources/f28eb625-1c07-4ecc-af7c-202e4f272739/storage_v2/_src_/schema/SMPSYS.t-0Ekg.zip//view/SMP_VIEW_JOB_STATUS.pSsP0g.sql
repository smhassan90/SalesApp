create view SMP_VIEW_JOB_STATUS as
  SELECT j.job_id "JOB_ID", j.job_name "JOB_NAME", jpt.node_name "NODE_NAME", jpt.target_name "TARGET_NAME",
         jpt.target_type "TARGET_TYPE", NVL(rtd.type_label,jpt.target_type) "TARGET_NLS_TYPE", j.owner "ADMINISTRATOR_NAME", jpt.exec_num "EXEC_NUM",
         DECODE(jpt.status,2,jpt.next_exec_time,4,jpt.start_time,15,jpt.finish_time,jpt.occur_time)+jpt.time_zone/86400000 "TIMESTAMP",
         jpt.status "STATUS"
  FROM   SMP_VDJ_JOB j, SMP_VDJ_JOB_PER_TARGET jpt, SMP_VBO_REPORTS_TYPE_DEFN rtd
  WHERE  j.job_id = jpt.job_id
    AND  j.is_lib = 0
    AND  UPPER(jpt.target_type) = rtd.type (+)
/

comment on table SMP_VIEW_JOB_STATUS
is 'Current status of the job on each of the submitted targets'
/

