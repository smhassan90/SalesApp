create trigger TRG_BI_SAL_SD_TRAINING_PACKAGE
  before insert
  on SAL_SD_TRAINING_PACKAGE
  for each row
  begin
 SELECT SQ_sal_sD_training_package.NEXTVAL INTO :NEW.TPD_ID FROM DUAL;
 end;
/

