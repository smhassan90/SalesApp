create trigger IUCD_MAST_DATA_TRG
  before insert
  on IUCD_MAST_DATA
  for each row
  DECLARE
tmpVar NUMBER;
BEGIN
   tmpVar := 0;

   SELECT IUCD_MAST_DATA_SEQ.NEXTVAL INTO tmpVar FROM dual;
   :NEW.IU_MST_ID:= tmpVar;

END;
/

