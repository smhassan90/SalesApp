create view SMP_VIEW_RUNNING_OMS_MACHINES as
  SELECT mas_name "OMS_MACHINE", region_name "REGION", timestamp "LAST_CHECKED"
  FROM   SMP_VDF_MASLIST, SMP_VDP_OMS_REGION_MAP
  WHERE  mas_name = oms
/

comment on table SMP_VIEW_RUNNING_OMS_MACHINES
is 'List of all machines running an OMS towards this repository'
/

