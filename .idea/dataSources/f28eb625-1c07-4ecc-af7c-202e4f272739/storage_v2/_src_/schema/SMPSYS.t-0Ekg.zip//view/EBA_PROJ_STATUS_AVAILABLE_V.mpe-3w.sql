create view EBA_PROJ_STATUS_AVAILABLE_V as
  select
    id,
    row_version_number,
    cat_id,
    parent_project_id,
    row_key,
    project,
    project_customer,
    lockdown_to_owners_yn,
    project_owner,
    project_owner2,
    project_owner3,
    project_owner4,
    project_owner5,
    project_owner6,
    project_owner7,
    project_owner8,
    project_owner9,
    project_owner10,
    project_owner11,
    project_owner12,
    owner_1_role_id,
    owner_2_role_id,
    owner_3_role_id,
    owner_4_role_id,
    owner_5_role_id,
    owner_6_role_id,
    owner_7_role_id,
    owner_8_role_id,
    owner_9_role_id,
    owner_10_role_id,
    owner_11_role_id,
    owner_12_role_id,
    project_status,
    tags,
    next_milestone_name,
    next_milestone_date,
    goal,
    what_is_success,
    url,
    include_by_default_yn,
    created,
    created_by,
    updated,
    updated_by,
    description
from
    eba_proj_status
where
    lockdown_to_owners_yn = 'N'
or
    (
        lockdown_to_owners_yn = 'Y'
        and
        (
            nvl(upper(project_owner),'no_owner_defined') = upper(v('APP_USER'))
            or
            nvl(upper(project_owner2),'no_owner_defined') = upper(v('APP_USER'))
            or
            nvl(upper(project_owner3),'no_owner_defined') = upper(v('APP_USER'))
            or
            nvl(upper(project_owner4),'no_owner_defined') = upper(v('APP_USER'))
            or
            nvl(upper(project_owner5),'no_owner_defined') = upper(v('APP_USER'))
            or
            nvl(upper(project_owner6),'no_owner_defined') = upper(v('APP_USER'))
            or
            nvl(upper(project_owner7),'no_owner_defined') = upper(v('APP_USER'))
            or
            nvl(upper(project_owner8),'no_owner_defined') = upper(v('APP_USER'))
            or
            nvl(upper(project_owner9),'no_owner_defined') = upper(v('APP_USER'))
            or
            nvl(upper(project_owner10),'no_owner_defined') = upper(v('APP_USER'))
            or
            nvl(upper(project_owner11),'no_owner_defined') = upper(v('APP_USER'))
            or
            nvl(upper(project_owner12),'no_owner_defined') = upper(v('APP_USER'))
        )                
    )
/

