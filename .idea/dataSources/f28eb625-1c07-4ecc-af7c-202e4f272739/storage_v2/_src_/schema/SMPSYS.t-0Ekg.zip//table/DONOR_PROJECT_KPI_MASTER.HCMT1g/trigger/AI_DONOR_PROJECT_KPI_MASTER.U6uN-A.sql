create trigger AI_DONOR_PROJECT_KPI_MASTER
  after insert
  on DONOR_PROJECT_KPI_MASTER
  for each row
  BEGIN
  FOR DPMI IN (SELECT DPS_ID, DPS_DESC, DPS_DIT_CODE
                 FROM DONOR_PROJECT_KPI_SETUP
                WHERE DPS_ACTIVE = 'Y'
                  AND DPS_MODULE_NO IS NULL
                  AND DPS_IND_TYPE = DECODE(:NEW.DPM_MPV_TYPE,
                                            'LAD3MVADOC',
                                            'LAD3-EPBM',
                                            'LAD3MVALHV',
                                            'LAD3-EPBM',
                                            'LAD3CORE',
                                            'LAD3-CORE',
                                            'LAD3CORENTL',
                                            'LAD3-CORE-NTL',
                                            'GFATMTB',
                                            'GFATM-TB',
                                            'FRP',
                                            'FRP',
                                            'IPC',
                                            'IPC')
                ORDER BY DPS_ID) LOOP
    INSERT INTO DONOR_PROJECT_KPI_DETAIL
      (DPD_DPM_ID, DPD_DPS_ID, DPD_DPS_DESC, DPD_DIT_CODE)
    VALUES
      (:NEW.DPM_ID, DPMI.DPS_ID, DPMI.DPS_DESC, DPMI.DPS_DIT_CODE);
  END LOOP;
END;
/

