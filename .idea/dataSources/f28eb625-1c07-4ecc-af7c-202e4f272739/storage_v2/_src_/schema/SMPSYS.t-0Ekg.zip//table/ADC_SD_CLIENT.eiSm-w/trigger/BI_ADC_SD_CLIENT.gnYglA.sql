create trigger BI_ADC_SD_CLIENT
  before insert
  on ADC_SD_CLIENT
  for each row
  begin
 SELECT SQ_ADC_SD_CLIENT.NEXTVAL INTO :NEW.ASD_ID FROM DUAL;
 end;
/

