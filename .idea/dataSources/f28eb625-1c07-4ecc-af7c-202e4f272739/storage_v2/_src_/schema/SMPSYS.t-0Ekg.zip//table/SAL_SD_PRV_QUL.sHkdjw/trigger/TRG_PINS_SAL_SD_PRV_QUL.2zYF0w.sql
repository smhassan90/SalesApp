create trigger TRG_PINS_SAL_SD_PRV_QUL
  before insert
  on SAL_SD_PRV_QUL
  for each row
  begin
IF :NEW.DPQ_ID IS NULL THEN
   :NEW.DPQ_ID := :NEW.DPQ_MPV_CODE||'-'||:NEW.DPQ_QUL_CODE;
END IF;
END;
/

