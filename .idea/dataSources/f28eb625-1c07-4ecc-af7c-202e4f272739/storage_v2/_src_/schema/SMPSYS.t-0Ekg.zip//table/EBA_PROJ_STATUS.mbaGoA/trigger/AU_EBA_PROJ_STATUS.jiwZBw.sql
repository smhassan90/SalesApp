create trigger AU_EBA_PROJ_STATUS
  after update
  on EBA_PROJ_STATUS
  for each row
  declare
    ov          varchar2(4000);
    nv          varchar2(4000);
begin
    if :old.cat_id != :new.cat_id then
        ov := null; nv := null;
        for c1 in (select category val from eba_proj_status_cats where id = :old.cat_id) loop
            ov := c1.val;
        end loop;
        for c1 in (select category val from eba_proj_status_cats where id = :new.cat_id) loop
            nv := c1.val;
        end loop;
        insert into eba_proj_history ( component_rowkey, component_id, column_name, old_value, new_value ) values
            (:new.row_key, :new.id, 'CAT_ID', ov, nv );
    end if;
    if :old.project != :new.project then
        insert into eba_proj_history ( component_rowkey, component_id, column_name, old_value, new_value ) values
            (:new.row_key, :new.id, 'PROJECT', :old.project, :new.project );
    end if;
/*
    if :old.parent_project_id is null and :new.parent_project_id is not null then
        ov := null;
        for c1 in (select project val from eba_proj_status where id = :new.parent_project_id) loop
            nv := c1.val;
        end loop;
        insert into eba_proj_history ( component_rowkey, component_id, column_name, old_value, new_value ) values
            (:new.row_key, :new.id, 'PARENT_PROJECT_ID', ov, nv );
    elsif nvl(:old.parent_project_id,-1) != nvl(:new.parent_project_id,-1) then
        ov := null; nv := null;
        for c1 in (select project val from eba_proj_status where id = :old.parent_project_id) loop
            ov := c1.val;
        end loop;
        for c1 in (select project val from eba_proj_status where id = :new.parent_project_id) loop
            nv := c1.val;
        end loop;
        insert into eba_proj_history ( component_rowkey, component_id, column_name, old_value, new_value ) values
            (:new.row_key, :new.id, 'PARENT_PROJECT_ID', ov, nv );
    end if;
*/
    if nvl(:old.project_customer,'ZXZ') != nvl(:new.project_customer,'ZXZ') then
        insert into eba_proj_history ( component_rowkey, component_id, column_name, old_value, new_value ) values
            (:new.row_key, :new.id, 'PROJECT_CUSTOMER', :old.project_customer, :new.project_customer );
    end if;
    if nvl(:old.project_status,-1) != nvl(:new.project_status,-1) then
        ov := null; nv := null;
        for c1 in (select status_short_desc val from eba_proj_status_codes where id = :old.project_status) loop
            ov := c1.val;
        end loop;
        for c1 in (select status_short_desc val from eba_proj_status_codes where id = :new.project_status) loop
            nv := c1.val;
        end loop;
        insert into eba_proj_history ( component_rowkey, component_id, column_name, old_value, new_value ) values
            (:new.row_key, :new.id, 'PROJECT_STATUS', ov, nv );
    end if;
    if nvl(:old.next_milestone_name,'ZXZ') != nvl(:new.next_milestone_name,'ZXZ') then
        insert into eba_proj_history ( component_rowkey, component_id, column_name, old_value, new_value ) values
            (:new.row_key, :new.id, 'NEXT_MILESTONE_NAME', :old.next_milestone_name, :new.next_milestone_name );
    end if;
    if trunc(nvl(:old.next_milestone_date,current_date+5000)) != trunc(nvl(:new.next_milestone_date,current_date+5000)) then
        select nvl2(:old.next_milestone_date, to_char(:old.next_milestone_date,'DD-MON-YYYY'), '(no date)') into ov from dual;
        select nvl2(:new.next_milestone_date, to_char(:new.next_milestone_date,'DD-MON-YYYY'), '(no date)') into nv from dual;
        insert into eba_proj_history ( component_rowkey, component_id, column_name, old_value, new_value ) values
            (:new.row_key, :new.id, 'NEXT_MILESTONE_DATE', ov, nv );
    end if;
    if nvl(:old.goal,'ZXZ') != nvl(:new.goal,'ZXZ') then
        insert into eba_proj_history ( component_rowkey, component_id, column_name, old_value, new_value ) values
            (:new.row_key, :new.id, 'GOAL', :old.goal, :new.goal );
    end if;
    if nvl(:old.what_is_success,'ZXZ') != nvl(:new.what_is_success,'ZXZ') then
        insert into eba_proj_history ( component_rowkey, component_id, column_name, old_value, new_value ) values
            (:new.row_key, :new.id, 'WHAT_IS_SUCCESS', :old.what_is_success, :new.what_is_success );
    end if;
    if nvl(:old.url,'ZXZ') != nvl(:new.url,'ZXZ') then
        insert into eba_proj_history ( component_rowkey, component_id, column_name, old_value, new_value ) values
            (:new.row_key, :new.id, 'URL', :old.url, :new.url );
    end if;
    if nvl(:old.project_owner,'ZXZ') != nvl(:new.project_owner,'ZXZ') then
        insert into eba_proj_history ( component_rowkey, component_id, column_name, old_value, new_value ) values
            (:new.row_key, :new.id, 'PROJECT_OWNER', :old.project_owner, :new.project_owner );
    end if;
    if nvl(:old.project_owner2,'ZXZ') != nvl(:new.project_owner2,'ZXZ') then
        insert into eba_proj_history ( component_rowkey, component_id, column_name, old_value, new_value ) values
            (:new.row_key, :new.id, 'PROJECT_OWNER2', :old.project_owner2, :new.project_owner2 );
    end if;
    if nvl(:old.project_owner3,'ZXZ') != nvl(:new.project_owner3,'ZXZ') then
        insert into eba_proj_history ( component_rowkey, component_id, column_name, old_value, new_value ) values
            (:new.row_key, :new.id, 'PROJECT_OWNER3', :old.project_owner3, :new.project_owner3 );
    end if;
    if nvl(:old.project_owner4,'ZXZ') != nvl(:new.project_owner4,'ZXZ') then
        insert into eba_proj_history ( component_rowkey, component_id, column_name, old_value, new_value ) values
            (:new.row_key, :new.id, 'PROJECT_OWNER4', :old.project_owner4, :new.project_owner4 );
    end if;
    if nvl(:old.project_owner5,'ZXZ') != nvl(:new.project_owner5,'ZXZ') then
        insert into eba_proj_history ( component_rowkey, component_id, column_name, old_value, new_value ) values
            (:new.row_key, :new.id, 'PROJECT_OWNER5', :old.project_owner5, :new.project_owner5 );
    end if;
    if nvl(:old.project_owner6,'ZXZ') != nvl(:new.project_owner6,'ZXZ') then
        insert into eba_proj_history ( component_rowkey, component_id, column_name, old_value, new_value ) values
            (:new.row_key, :new.id, 'PROJECT_OWNER6', :old.project_owner6, :new.project_owner6 );
    end if;
    if nvl(:old.project_owner7,'ZXZ') != nvl(:new.project_owner7,'ZXZ') then
        insert into eba_proj_history ( component_rowkey, component_id, column_name, old_value, new_value ) values
            (:new.row_key, :new.id, 'PROJECT_OWNER7', :old.project_owner7, :new.project_owner7 );
    end if;
    if nvl(:old.project_owner8,'ZXZ') != nvl(:new.project_owner8,'ZXZ') then
        insert into eba_proj_history ( component_rowkey, component_id, column_name, old_value, new_value ) values
            (:new.row_key, :new.id, 'PROJECT_OWNER8', :old.project_owner8, :new.project_owner8 );
    end if;
    if nvl(:old.project_owner9,'ZXZ') != nvl(:new.project_owner9,'ZXZ') then
        insert into eba_proj_history ( component_rowkey, component_id, column_name, old_value, new_value ) values
            (:new.row_key, :new.id, 'PROJECT_OWNER9', :old.project_owner9, :new.project_owner9 );
    end if;
    if nvl(:old.project_owner10,'ZXZ') != nvl(:new.project_owner10,'ZXZ') then
        insert into eba_proj_history ( component_rowkey, component_id, column_name, old_value, new_value ) values
            (:new.row_key, :new.id, 'PROJECT_OWNER10', :old.project_owner10, :new.project_owner10 );
    end if;
    if nvl(:old.project_owner11,'ZXZ') != nvl(:new.project_owner11,'ZXZ') then
        insert into eba_proj_history ( component_rowkey, component_id, column_name, old_value, new_value ) values
            (:new.row_key, :new.id, 'PROJECT_OWNER11', :old.project_owner11, :new.project_owner11 );
    end if;
    if nvl(:old.project_owner12,'ZXZ') != nvl(:new.project_owner12,'ZXZ') then
        insert into eba_proj_history ( component_rowkey, component_id, column_name, old_value, new_value ) values
            (:new.row_key, :new.id, 'PROJECT_OWNER12', :old.project_owner12, :new.project_owner12 );
    end if;
    if nvl(:old.include_by_default_yn,'Z') != nvl(:new.include_by_default_yn,'Z') then
        insert into eba_proj_history ( component_rowkey, component_id, column_name, old_value, new_value ) values
            (:new.row_key, :new.id, 'INCLUDE_BY_DEFAULT_YN', :old.include_by_default_yn, :new.include_by_default_yn );
    end if;
    if nvl(:old.tags,'ZXZ') != nvl(:new.tags,'ZXZ') then
        insert into eba_proj_history ( component_rowkey, component_id, column_name, old_value, new_value ) values
            (:new.row_key, :new.id, 'TAGS', :old.tags, :new.tags );
    end if;
    if nvl(:old.lockdown_to_owners_yn,'Z') != nvl(:new.lockdown_to_owners_yn,'Z') then
        insert into eba_proj_history ( component_rowkey, component_id, column_name, old_value, new_value ) values
            (:new.row_key, :new.id, 'LOCKDOWN_TO_OWNERS_YN', :old.lockdown_to_owners_yn, :new.lockdown_to_owners_yn );
    end if;
end;
/

