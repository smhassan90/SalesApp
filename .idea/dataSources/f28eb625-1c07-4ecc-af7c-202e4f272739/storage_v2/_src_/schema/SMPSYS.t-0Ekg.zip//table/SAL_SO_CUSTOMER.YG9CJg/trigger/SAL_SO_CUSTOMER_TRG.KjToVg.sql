create trigger SAL_SO_CUSTOMER_TRG
  before insert
  on SAL_SO_CUSTOMER
  for each row
  begin
  IF :NEW.NUM IS NULL THEN
    SELECT SAl_SO_CUSTOMER_SEQ.NEXTVAL INTO :NEW.NUM FROM DUAL;
  END IF;
end;
/

