create trigger BI_ADC_TM_SMS
  before insert
  on ADC_TM_SMS
  for each row
  begin
 SELECT SQ_ADC_TM_SMS.NEXTVAL INTO :NEW.ATS_ID FROM DUAL;
 end;
/

