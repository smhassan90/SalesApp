create trigger PROJECT_TIMESHEET_SPLIT_TRG
  before insert
  on PROJECT_TIMESHEET_SPLIT
  for each row
  begin
 SELECT project_timesheet_split_seq.NEXTVAL INTO :NEW.PTS_ID FROM DUAL;
 end;
/

