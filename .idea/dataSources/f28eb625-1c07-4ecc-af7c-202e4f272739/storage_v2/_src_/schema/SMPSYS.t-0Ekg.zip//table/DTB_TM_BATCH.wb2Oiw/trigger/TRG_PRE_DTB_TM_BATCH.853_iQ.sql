create trigger TRG_PRE_DTB_TM_BATCH
  before insert
  on DTB_TM_BATCH
  for each row
  begin
 SELECT SQ_DTB_TM_BATCH.NEXTVAL INTO :NEW.DTB_ID FROM DUAL;
 end;
/

