create materialized view VU_PRI_SALES_DETAIL
refresh force on demand
  as
    SELECT MSL_CP_CODE COMPANY,
         MSL_NUM, MSL_DATE, MSL_TYPE,
         MSL_MPV_CODE PROVIDER,
         MSL_OTL_CODE OUTLET,
         MSL_DIS_CODE DISCODE,
         MSL_TWN_CODE TOWN,
         MSL_INV_LOC  STAFFCODE,
         MSL_ZON_CODE ZONECODE,
         MSL_REG_CODE REGIONCODE,
         MSL_STATUS, MSL_MPT_CODE,
         DSL_SEQ_NUM ,
         DSL_DIT_CODE ITEM,
         DSL_MPY_CODE,
         DSL_MSY_CODE,
         DSL_BCH_NUM,
         DSL_EXP_DATE,
         DSL_REF_NUM,
         DSL_QTY QTY,
         DSL_RATE RATE,
         DSL_GRS_AMT,
         DSL_REG_DIS,
         DSL_ADD_DIS,
         DSL_REG_GST,
         DSL_ADD_GST,
         DSL_NET_AMT
FROM SAL_TM_SALES M, SAL_TD_SALES T
where  m.msl_num      = t.dsl_msl_num
and    m.msl_cp_code  = t.dsl_cp_code
and    m.msl_type    in ('DS','SD','SI')







/

