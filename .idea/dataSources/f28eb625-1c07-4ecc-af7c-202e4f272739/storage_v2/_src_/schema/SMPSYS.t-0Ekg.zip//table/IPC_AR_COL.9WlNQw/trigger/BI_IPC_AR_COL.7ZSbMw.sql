create trigger BI_IPC_AR_COL
  before insert
  on IPC_AR_COL
  for each row
  begin
  for c1 in (
    select IPC_AR_COL_SEQ.nextval next_val
    from dual
  ) loop
    :new.ACL_ID :=  c1.next_val;
  end loop;
end;
/

