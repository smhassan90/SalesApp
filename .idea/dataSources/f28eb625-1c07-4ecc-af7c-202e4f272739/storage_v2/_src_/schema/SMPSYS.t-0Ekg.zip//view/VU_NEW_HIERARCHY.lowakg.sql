create view VU_NEW_HIERARCHY as
  select msl_cp_code, msl_code,
       get_level(msl_cp_code, 'A', sysdate, msl_code, 'T') TERR,
       get_level(msl_cp_code, 'Z', sysdate,
       get_level(msl_cp_code, 'A', sysdate, msl_code, 'T'),'A') ZONE,
       get_level(msl_cp_code, 'R', sysdate,
       get_level(msl_cp_code, 'Z', sysdate,
       get_level(msl_cp_code, 'A', sysdate, msl_code, 'T'),'A'),'Z') REG

from sal_sm_sales_level
where msl_type = 'T'
and   get_level(msl_cp_code, 'A', sysdate, msl_code, 'T') is not null
/

