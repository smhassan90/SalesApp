create trigger BI_INV_SO_ATH_LEVEL
  before insert
  on INV_SO_ATH_LEVEL
  for each row
  begin
 SELECT SQ_INV_SO_ATH_LEVEL.NEXTVAL INTO :NEW.ATL_ID FROM DUAL;
end;
/

